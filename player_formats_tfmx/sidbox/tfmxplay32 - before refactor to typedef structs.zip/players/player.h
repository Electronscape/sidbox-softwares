/***************************************************************************
 *   Copyright (C) 2004 by David Banz                                      *
 *   neko@netcologne.de                                                    *
 *   GPL'ed                                                                *
 ***************************************************************************/

#ifndef PLAYERTF_H
#define PLAYERTF_H

#include <stdint.h>


#define PATHNAME_LENGTH     256


typedef uint32_t        U32;
typedef uint16_t        U16;
typedef uint8_t         U8;
typedef int32_t         S32;
typedef int16_t         S16;
typedef int8_t          S8;



#define     BUF_SIZE        4096
#define     HALFBUFSIZE     (  (BUF_SIZE * 4) / 4)
#define     BUFSIZE         (( (BUF_SIZE * 2) * 4) / 4)
extern S32  tbuf[];




typedef union {
    U32 l;
    struct {U16 w1,w0;} w;
    struct {U8 b3,b2,b1,b0;} b;
} UNI;

struct Hdr {
    char magic[10];
    char pad[6];
    char text[6][40];
    unsigned short start[32],end[32],tempo[32];
    short mute[8];
    unsigned int trackstart,pattstart,macrostart;
    char pad2[36];
};

struct Hdb {
    U32 pos;
    U32 delta;
    U16 slen,SampleLength;
    S8 *sbeg,*SampleStart;
    U8 vol;
    U8 mode;
    int (*loop)();
    int loopcnt;
    struct Cdb *c;
};

struct Idb {
    U16 Cue[4];
};

struct Mdb {
    char	PlayerEnable;
    char	EndFlag;
    char	CurrSong;
    U16     SpeedCnt;
    U16     CIASave;
    char	SongCont,SongNum;
    U16     PlayPattFlag;
    char	MasterVol,FadeDest,FadeTime,FadeReset,FadeSlope;
    S16     TrackLoop;
    U16     DMAon, DMAoff, DMAstate, DMAAllow;
};

struct Pdb {
    U32 PAddr;
    U8 PNum;
    S8 PXpose;
    U16 PLoop,PStep;
    U8 PWait;
    U16 PRoAddr,PRoStep;
};

struct Pdblk {
    U16 FirstPos,LastPos,CurrPos;
    U16 Prescale;
    struct Pdb p[8];
};

struct Cdb {
    S8 MacroRun,EfxRun;
    U8 NewStyleMacro;
    U8 PrevNote,CurrNote;
    U8 Velocity,Finetune;
    U8 KeyUp,ReallyWait;
    U32 MacroPtr;
    U16 MacroStep,MacroWait,MacroNum;
    S16 Loop;

    U32 CurAddr,SaveAddr;
    U16 CurrLength,SaveLen;

    U16 WaitDMACount;
    U16 DMABit;

    U8 EnvReset,EnvTime,EnvRate;
    S8 EnvEndvol,CurVol;

    S16 VibOffset;
    S8 VibWidth;
    U8 VibFlag,VibReset,VibTime;

    U8 PortaReset,PortaTime;
    U16 CurPeriod,DestPeriod,PortaPer;
    S16 PortaRate;

    U8 AddBeginTime,AddBeginReset;
    U16 ReturnPtr,ReturnStep;
    S32 AddBegin;

    U8 SfxFlag,SfxPriority,SfxNum;
    S16 SfxLockTime;
    U32 SfxCode;

    struct Hdb *hw;
};




// TFMX expects these globals (they already exist in original codebase).
// Make sure they are defined EXACTLY ONCE across your build.
extern char         act[8];
extern struct Hdr   hdr;
extern struct Hdb   hdb[8];
extern struct Cdb   cdb[16];
extern struct Mdb   mdb;


extern int toOutFile;
extern int startPat, gemx, loops, dangerFreakHack , oopsUpHack, monkeyHack;
extern int jiffies;

extern char     outf[PATHNAME_LENGTH];
extern U32      editbuf[];
extern U8       *smplbuf;
extern int      *patterns,*macros;
extern int      multimode;
extern U32      eClocks, outRate, stereo;



extern U32      outRate;
extern U32      eClocks;
extern int      multimode;
extern int      over;
extern int      loops;
extern int      songnum;



void    NotePort(U32 i);
int     LoopOff(void /* struct Hdb *hw */);
int     LoopOn(struct Hdb *hw);
void    RunMacro(struct Cdb *c, U32 nChannel);
void    DoEffects(struct Cdb *c);
void    DoMacro(int cc);
void    DoAllMacros(void);
void    ChannelOff(int i);
void    DoFade(int sp,int dv);
void    GetTrackStep(void);
int     DoTrack(struct Pdb *p/* ,int pp  */);
void    DoTracks(void);
void    tfmxIrqIn(void);
void    AllOff(void);
void    TfmxInit(void);
void    StartSong(int song, int mode);

void    TfmxInit(void);
void    StartSong(int song, int mode);
void    tfmxIrqIn(void);
void    mixem(U32 nb, U32 bd);
void    filter(S32 *b, int num);
void    stereoblend(S32 *b, int num);

int     load_tfmx(char *mfn, char *sfn);







void mix_add_ov(struct Hdb *hw,int n,S32 *b);
void mix_add(struct Hdb *hw,int n,S32 *b);
void mixit(int n,int b);
void mixem(U32 nb,U32 bd);
int play_it(void);
void tfmxIrqIn(void);







#endif
