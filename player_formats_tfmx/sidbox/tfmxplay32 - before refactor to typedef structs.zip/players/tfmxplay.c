/***************************************************************************
 *   Copyright (C) 2004 by David Banz                                      *
 *   neko@netcologne.de                                                    *
 *   GPL'ed                                                                *
 ***************************************************************************/

#include "../../main.h"
#include <stdio.h>
#include <string.h>

#include "tfmxplay.h"
#include "player.h"

/* external functions */

uint8_t songmemory  [128 * 1024];         // this will be in external ram also





int dangerFreakHack=0;
int oopsUpHack=0;

int singleFile=0;
int dosExt=0;

uint32_t nTFhd_offset=0;
uint32_t nTFhd_mdatsize=0;
uint32_t nTFhd_smplsize=0;

U32 outRate=44100;



extern struct Hdb hdb[8];
extern struct Pdblk pdb;
extern int LoopOff();
extern struct Mdb mdb;

extern char act[8];

unsigned int mlen;
U32 editbuf[16384];
U8 *smplbuf;
int *macros;
int *patterns;


int num_ts,num_pat,num_mac;

int songnum=0;
int gubed=0;
int printinfo=0;
int startPat=-1;
int gemx=0;
int loops=1;
extern int blend,filt,over;


/* this one can also load a single-file TFMX :) */
int load_tfmx(char *mfn, char *sfn){
    FILE *gfd;
    unsigned int x, y, z = 0;
    U16 *sh, *lg;

    printf("MDAT: %s\nSMPL: %s\n", mfn, sfn);

    if (!mfn || !mfn[0]) return 1;

    gfd = fopen(mfn, "rb");                 // <-- BINARY
    if (!gfd) {
        perror("fopen");
        return 1;
    }

    // jump to mdat start if single-file format
    if (singleFile == 1) {
        if (fseek(gfd, (long)nTFhd_offset, SEEK_SET) != 0) {   // <-- SEEK_SET
            perror("fseek(mdat)");
            fclose(gfd);
            return 1;
        }
    }

    // Read header (packed struct must match on-disk layout)
    if (fread(&hdr, 1, sizeof(hdr), gfd) != sizeof(hdr)) {
        perror("fread(hdr)");
        fclose(gfd);
        return 1;
    }

    // Magic checks
    if (strncmp("TFMX-SONG", hdr.magic, 9) &&
        strncmp("TFMX_SONG", hdr.magic, 9) &&
        strncasecmp("TFMXSONG", hdr.magic, 8) &&
        strncmp("TFMX",      hdr.magic, 4))
    {
        fclose(gfd);
        return 2;
    }

    // Read MDAT "editbuf" as 32-bit words, not sizeof(int)
    x = (unsigned int)fread(editbuf, sizeof(U32), 16384, gfd);
    if (x == 0) {
        perror("fread(editbuf)");
        fclose(gfd);
        return 1;
    }

    // If dual-file, close MDAT now (matches original flow)
    if (singleFile == 0) {
        fclose(gfd);
        gfd = NULL;
    }

    mlen = x;

    // Safe sentinel (don’t write past end if x == 16384)
    if (x < 16384) editbuf[x] = 0xFFFFFFFFu;
    else           editbuf[16383] = 0xFFFFFFFFu;

    // Convert header pointers
    if (!hdr.trackstart) hdr.trackstart = 0x180;
    else                 hdr.trackstart = (tfmx_be32(hdr.trackstart) - 0x200u) >> 2;

    if (!hdr.pattstart)  hdr.pattstart  = 0x80;
    else                 hdr.pattstart  = (tfmx_be32(hdr.pattstart) - 0x200u) >> 2;

    if (!hdr.macrostart) hdr.macrostart = 0x100;
    else                 hdr.macrostart = (tfmx_be32(hdr.macrostart) - 0x200u) >> 2;

    if (mlen < 136) return 2;

    // Convert song tables
    for (x = 0; x < 32; x++) {
        hdr.start[x] = tfmx_be16(hdr.start[x]);
        hdr.end[x]   = tfmx_be16(hdr.end[x]);
        hdr.tempo[x] = tfmx_be16(hdr.tempo[x]);
    }

    // Fix macros
    z = hdr.macrostart;
    macros = (int *)&editbuf[z];
    for (x = 0; x < 128; x++) {
        y = (tfmx_be32(editbuf[z]) - 0x200u);
        if ((y & 3u) || ((y >> 2) > mlen)) break;
        editbuf[z++] = (y >> 2);
    }
    num_mac = x;

    // Fix patterns
    z = hdr.pattstart;
    patterns = (int *)&editbuf[z];
    for (x = 0; x < 128; x++) {
        y = (tfmx_be32(editbuf[z]) - 0x200u);
        if ((y & 3u) || ((y >> 2) > mlen)) break;
        editbuf[z++] = (y >> 2);
    }
    num_pat = x;

    // Convert tracksteps to host endian
    lg = (U16 *)&editbuf[patterns[0]];
    sh = (U16 *)&editbuf[hdr.trackstart];
    num_ts = (patterns[0] - hdr.trackstart) >> 2;

    while (sh < lg) {
        *sh = tfmx_be16(*sh);
        sh++;
    }

    // Load samples
    if (singleFile == 1) {
        uint32_t nSmplPos = nTFhd_offset + nTFhd_mdatsize;

        if (!gfd) {
            // should not happen, but be safe
            gfd = fopen(mfn, "rb");
            if (!gfd) { perror("fopen(reopen)"); return 1; }
        }

        if (fseek(gfd, (long)nSmplPos, SEEK_SET) != 0) {
            perror("fseek(smpl)");
            fclose(gfd);
            return 1;
        }

        smplbuf = samplememory;

        if (fread(samplememory, 1, nTFhd_smplsize, gfd) != nTFhd_smplsize) {
            perror("fread(smpl)");
            fclose(gfd);
            return 1;
        }

        fclose(gfd);
    } else {

        FILE *fp = fopen(sfn, "rb");
        if (!fp) {
            perror("fopen(smpl)");
            return 1;
        }

        smplbuf = samplememory;
        if (!smplbuf) {
            perror("samplememory NULL");
            fclose(fp);
            return 1;
        }

        /* read up to 1MB */
        size_t r = fread(samplememory, 1, 1024 * 1024, fp);

        if (ferror(fp)) {
            perror("fread(smpl)");
            fclose(fp);
            return 1;
        }

        /* r now contains actual file size */
        size_t sample_size = r;

        fclose(fp);

    }

    return 0;
}



uint32_t RenderTFXBlock(int16_t *left, int16_t *right, uint32_t frames){
    // TODO: this would be rendered here, and then passed through left and right

    return frames;
}
