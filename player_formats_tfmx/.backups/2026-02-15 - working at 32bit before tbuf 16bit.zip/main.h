#ifndef MAIN_H
#define MAIN_H

#include <stdint.h>

#include "sidbox/players/player.h"

#ifdef __cplusplus
extern "C" {
#endif

extern uint8_t songmemory[1024 * 1024];         // this is the song data will live, thats where file data will be!


uint16_t tfmx_be16(uint16_t v);
uint32_t tfmx_be32(uint32_t v);


extern int singleFile;
extern int dosExt;

#ifdef __cplusplus
}
#endif

#endif // MAIN_H
