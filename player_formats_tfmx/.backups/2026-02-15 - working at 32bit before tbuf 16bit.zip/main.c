#include <stdio.h>
//#include <stdlib.h>
#include <stdint.h>
//#include <string.h>
//#include <math.h>
//#include <time.h>
#include <alsa/asoundlib.h>
#include "main.h"


// the parts needed for music format
/*

#define TFMX_BSWAP16(x) (uint16_t)((((uint16_t)(x) & 0x00FFu) << 8) | \
                                  (((uint16_t)(x) & 0xFF00u) >> 8))

#define TFMX_BSWAP32(x) (uint32_t)((((uint32_t)(x) & 0x000000FFu) << 24) | \
                                  (((uint32_t)(x) & 0x0000FF00u) <<  8) | \
                                  (((uint32_t)(x) & 0x00FF0000u) >>  8) | \
                                  (((uint32_t)(x) & 0xFF000000u) >> 24))



*/

uint16_t tfmx_be16(uint16_t v) { return __builtin_bswap16(v); }
uint32_t tfmx_be32(uint32_t v) { return __builtin_bswap32(v); }



#define PCM_DEVICE "default"

//////////////// SYSTEM FILE REQUESTER /////////////////////////////////
/// \brief prog_hello


#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>

#include "sidbox/players/tfmxglue.h"

uint8_t songmemory[1024 * 1024];         // this is the song data will live, thats where file data will be!



static char g_last_dir[PATH_MAX] =
    "/mnt/LinuxDatas/work/sidbox-softwares/player_formats/tunes";

static void strip_newlines(char *s){
    if (!s) return;
    size_t n = strlen(s);
    while (n && (s[n-1] == '\n' || s[n-1] == '\r')) s[--n] = 0;
}

static void path_dirname_inplace(char *path){
    if (!path || !*path) return;
    strip_newlines(path);
    char *slash = strrchr(path, '/');
    if (!slash) return;
    if (slash == path) path[1] = 0;  // keep "/"
    else *slash = 0;
}

static void ensure_dir_exists(const char *dir){
    if (!dir || !*dir) return;
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof(tmp), "%s", dir);
    for (char *p = tmp + 1; *p; ++p) {
        if (*p == '/') {
            *p = 0;
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    mkdir(tmp, 0755);
}

static int get_config_paths(char *out_dir, size_t out_dir_sz, char *out_file, size_t out_file_sz){
    const char *xdg = getenv("XDG_CONFIG_HOME");
    const char *home = getenv("HOME");
    if (xdg && *xdg) {
        snprintf(out_dir,  out_dir_sz,  "%s/sidbox_player", xdg);
    } else if (home && *home) {
        snprintf(out_dir,  out_dir_sz,  "%s/.config/sidbox_player", home);
    } else {
        return 0;
    }
    snprintf(out_file, out_file_sz, "%s/lastdir.txt", out_dir);
    return 1;
}

void music_lastdir_load(void){
    char dir[PATH_MAX], file[PATH_MAX];
    if (!get_config_paths(dir, sizeof(dir), file, sizeof(file))) return;
    FILE *f = fopen(file, "rb");
    if (!f) return;
    char buf[PATH_MAX];
    if (fgets(buf, sizeof(buf), f)) {
        strip_newlines(buf);
        if (buf[0] == '/' && buf[1] != 0) {   // basic sanity
            snprintf(g_last_dir, sizeof(g_last_dir), "%s", buf);
        }
    }
    fclose(f);
}

void music_lastdir_save(void){
    char dir[PATH_MAX], file[PATH_MAX];
    if (!get_config_paths(dir, sizeof(dir), file, sizeof(file))) return;
    ensure_dir_exists(dir);
    FILE *f = fopen(file, "wb");
    if (!f) return;
    fputs(g_last_dir, f);
    fputc('\n', f);
    fclose(f);
}

int pick_music_file(char *out_path, size_t out_sz){
    if (!out_path || out_sz == 0) return 0;
    char cmd[2048];
    snprintf(cmd, sizeof(cmd),
             "kdialog --getopenfilename \"%s\" \"*|files (*)\" \"*|All files\"",
             g_last_dir);

    FILE *fp = popen(cmd, "r");
    if (!fp) return 0;

    if (!fgets(out_path, (int)out_sz, fp)) {
        pclose(fp);
        return 0;
    }

    int rc = pclose(fp);

    strip_newlines(out_path);

    // user cancelled
    if (out_path[0] == 0 || rc != 0) return 0;

    // update last dir
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof(tmp), "%s", out_path);
    path_dirname_inplace(tmp);
    snprintf(g_last_dir, sizeof(g_last_dir), "%s", tmp);

    // persist it
    music_lastdir_save();

    return 1;
}



int main(){
    char musicfilename[256];
    uint32_t length;

    setvbuf(stdout, NULL, _IONBF, 0);

    // audio setup ##########################################################
    snd_pcm_t *pcm_handle = NULL;
    snd_pcm_sw_params_t *sw = NULL;
    snd_pcm_hw_params_t *params = NULL;
    unsigned int rate = 44100;
    int err;

    if ((err = snd_pcm_open(&pcm_handle, PCM_DEVICE, SND_PCM_STREAM_PLAYBACK, 0)) < 0) {
        fprintf(stderr, "Error opening PCM device: %s\n", snd_strerror(err));
        return 1;
    }

    snd_pcm_hw_params_malloc(&params);
    snd_pcm_hw_params_any(pcm_handle, params);

    snd_pcm_hw_params_set_access(pcm_handle, params, SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(pcm_handle, params, SND_PCM_FORMAT_S16_LE);
    snd_pcm_hw_params_set_channels(pcm_handle, params, 2);

    snd_pcm_hw_params_set_rate_near(pcm_handle, params, &rate, 0);

    snd_pcm_uframes_t period = 882;
    snd_pcm_uframes_t bufferv = period * 2;

    snd_pcm_hw_params_set_period_size_near(pcm_handle, params, &period, 0);
    snd_pcm_hw_params_set_buffer_size_near(pcm_handle, params, &bufferv);

    if ((err = snd_pcm_hw_params(pcm_handle, params)) < 0) {
        fprintf(stderr, "snd_pcm_hw_params failed: %s\n", snd_strerror(err));
        snd_pcm_hw_params_free(params);
        snd_pcm_close(pcm_handle);
        return 1;
    }

    snd_pcm_hw_params_free(params);

    snd_pcm_sw_params_malloc(&sw);
    snd_pcm_sw_params_current(pcm_handle, sw);

    snd_pcm_sw_params_set_start_threshold(pcm_handle, sw, period);
    snd_pcm_sw_params_set_avail_min(pcm_handle, sw, period);

    if ((err = snd_pcm_sw_params(pcm_handle, sw)) < 0) {
        fprintf(stderr, "snd_pcm_sw_params failed: %s\n", snd_strerror(err));
        snd_pcm_sw_params_free(sw);
        snd_pcm_close(pcm_handle);
        return 1;
    }

    snd_pcm_sw_params_free(sw);

    // Make sure PCM is ready
    if ((err = snd_pcm_prepare(pcm_handle)) < 0) {
        fprintf(stderr, "snd_pcm_prepare failed: %s\n", snd_strerror(err));
        snd_pcm_close(pcm_handle);
        return 1;
    }



    int16_t buffer[882 * 2];
    memset(buffer, 0x00, sizeof(buffer));














    // AUDIO SETUP SUCCESSFULL ------------------------
    size_t filesize;
    pick_music_file(musicfilename, 256);
    printf("File selected '%s'\n", musicfilename);


    // --- Build mdat/smpl paths like original tfmxplay does (minimal) ---
    char mfn[PATHNAME_LENGTH];
    char sfn[PATHNAME_LENGTH];

    snprintf(mfn, sizeof(mfn), "%s", musicfilename);
    snprintf(sfn, sizeof(sfn), "%s", musicfilename);

    // If user picked "mdat.*" or "tfmx.*", derive smpl.* next to it
    char *c = strrchr(sfn, '/');
    c = (c ? (c + 1) : sfn);

    singleFile = 0;     // keep as your original global if it exists; else local here is fine only for harness logic
    dosExt = 0;

    char *tfxloc = strchr(c, '\0');
    if ((tfxloc - 4) > c) {
        tfxloc -= 4;
        if (0 == strncasecmp(tfxloc, ".tfx", 4)) dosExt = 1;
    }

    if (!dosExt) {
        if (strncasecmp(c, "mdat.", 5)) {
            if (strncasecmp(c, "tfmx.", 5)) {
                printf("Warning: file does not start with mdat./tfmx.\n");
            } else {
                singleFile = 1;
                sfn[0] = '\0';
            }
        }
        if (!singleFile) {
            // case-preserving mdat -> smpl
            (*c++) ^= 'm' ^ 's';
            (*c++) ^= 'd' ^ 'm';
            (*c++) ^= 'a' ^ 'p';
            (*c++) ^= 't' ^ 'l';
        }
    } else {
        // .tfx -> .sam
        tfxloc++; // skip '.'
        (*tfxloc++) ^= 't' ^ 's';
        (*tfxloc++) ^= 'f' ^ 'a';
        (*tfxloc++) ^= 'x' ^ 'm';
    }

    // --- Configure TFMX defaults like original ---
    over = -1;
    filt = 0;
    blend = 1;
    loops = 1;
    outRate = 44100;
    eClocks = 14318;
    multimode = 0;

    // --- Load + init ---
    //check_md5_and_headers(mfn);

    int x = load_tfmx(mfn, sfn);
    if (x == 1) { fprintf(stderr, "load_tfmx failed\n"); return 1; }
    if (x == 2) { fprintf(stderr, "Not an MDAT/TFMX file\n"); return 1; }

    TfmxInit();
    songnum =0;
    StartSong(songnum, 0);



    /////////////////////////// [END TEST] ////////////////////////////////////////////////////////
    printf("DBG(main): tbuf=%p mdb=%p smplbuf=%p editbuf=%p\n",
           (void*)tbuf, (void*)&mdb, (void*)smplbuf, (void*)editbuf);
    while(1){   // this will keep looing only because later i'll add stuff to control this later
        uint32_t frames = 882;  // the usual 44100 / 50fps! FIXED NOT CHANGING THIS

        // ## HERE IS WHERE THE AUDIO DOES ITS THING where filling up the buffer #####################

        // If song ended, output silence (or break if you prefer)
        if (!mdb.PlayerEnable) {
            memset(buffer, 0, sizeof(buffer));
        } else {
            // local persistent state (same concept as original try_to_makeblock)
            static int eRem_local = 0;
            static S32 nb = 0;
            static S32 bd = 0;

            // render "frames" samples into tbuf using original engine timing
            // bd is the destination offset in tbuf (like original mixem(nb,bd))
            // We do it in one block: bd counts frames generated this call.
            bd = 0;

            while ((uint32_t)bd < frames && mdb.PlayerEnable)
            {
                if (nb <= 0)
                {
                    tfmxIrqIn();
                    //printf("."); // <-- is doin somemthing an tfmIrq IS bein fired seems to be about 50 times a second

                    nb = (S32)(eClocks * (outRate >> 1));
                    eRem_local += (nb % 357955);
                    nb /= 357955;
                    if (eRem_local > 357955) { nb++; eRem_local -= 357955; }

                    if (nb <= 0) continue;
                }

                S32 n = (S32)frames - bd;
                if (n > nb) n = nb;


                mixem((U32)n, (U32)bd);


                bd += n;
                nb -= n;
            }

            // post-process exactly like original path
            filter(tbuf, (int)frames);
            stereoblend(tbuf, (int)frames);

            // clamp + interleave into ALSA buffer, then clear tbuf
            S32 peakL = 0, peakR = 0;
            for (uint32_t i = 0; i < frames; i++) {
                S32 L = tbuf[HALFBUFSIZE + (int)i];
                S32 R = tbuf[(int)i];
                if (L < 0) L = -L;
                if (R < 0) R = -R;
                if (L > peakL) peakL = L;
                if (R > peakR) peakR = R;
            }
            printf(" peakL=%ld peakR=%ld\r", (long)peakL, (long)peakR);
            for (uint32_t i = 0; i < frames; i++)
            {
                S32 L = tbuf[HALFBUFSIZE + (int)i];
                S32 R = tbuf[(int)i];

                if (L > 32767) L = 32767; else if (L < -32768) L = -32768;
                if (R > 32767) R = 32767; else if (R < -32768) R = -32768;

                buffer[i*2u + 0u] = (int16_t)L;
                buffer[i*2u + 1u] = (int16_t)R;

                tbuf[HALFBUFSIZE + (int)i] = 0;
                tbuf[(int)i] = 0;
            }
        }













        // ###########################################################################################
        snd_pcm_sframes_t written = snd_pcm_writei(pcm_handle, buffer, frames);
        if(written == -EPIPE){
            snd_pcm_prepare(pcm_handle);
        } else if(written < 0){
            fprintf(stderr, "Write error: %s\n", snd_strerror((int)written));
            break;
        }
    }

    snd_pcm_drain(pcm_handle);
    snd_pcm_close(pcm_handle);
    printf("done\n");


    return(42);

}
