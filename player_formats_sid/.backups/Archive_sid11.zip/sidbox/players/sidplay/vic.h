#ifndef C64_VIC_H
#define C64_VIC_H

#include <stdint.h>
#include "c64_types.h"

#ifdef __cplusplus
extern "C" {
#endif

// Minimal VIC-II timing model.
// Focus: raster counter + raster IRQ generation.
// No graphics, sprites, badlines, memory fetch, etc.

typedef struct vic_t {
    c64_video_t std;

    // Registers (0x40 like real mapping; most unused)
    uint8_t reg[0x40];

    // Raster counter (full 9-bit value)
    uint16_t raster;

    // Cached compare value (from $D012 and bit7 of $D011)
    uint16_t raster_cmp;

    // IRQ line (level)
    uint8_t irq_line; // 1 = asserted

    // Internal cycle accumulation for line stepping
    uint32_t cyc_acc;
} vic_t;

void vic_reset(vic_t *v, c64_video_t std);

// Tick by CPU cycles
void vic_tick(vic_t *v, uint32_t cycles);

// VIC register access ($D000-$D3FF; addr low 6 bits used)
uint8_t vic_read(vic_t *v, uint16_t addr);
void    vic_write(vic_t *v, uint16_t addr, uint8_t val);

// Update cached raster compare + IRQ line based on regs/flags
void vic_update_irq(vic_t *v);

#ifdef __cplusplus
}
#endif

#endif // C64_VIC_H
