// bus.c - C64 bus / memory map (RAM/ROM/IO/bankswitch)
// Minimal but RSID-oriented.

#include "bus.h"
#include "cia.h"
#include "vic.h"
#include <string.h>

// ---------------- ROM blobs (stubbed) ----------------
uint8_t ROM_BASIC[0x2000];
uint8_t ROM_KERNAL[0x2000];
uint8_t ROM_CHARMAP[0x1000];

uint8_t sysRam[0x10000];   // actual ram

// --- helpers ---
static inline uint8_t io_visible(const c64_bus_t *b){
    // 6510 port bits:
    //  bit0 LORAM, bit1 HIRAM, bit2 CHAREN
    // I/O at $D000-$DFFF is visible when CHAREN=1 *and* (HIRAM|LORAM) mapping is "normal".
    // Real behavior is nuanced; this rule works well for most music drivers.
    return (b->cpu_port & 0x04) ? 1u : 0u;
}

static inline uint8_t basic_visible(const c64_bus_t *b){
    // BASIC at $A000-$BFFF when LORAM=1 and HIRAM=1
    return ((b->cpu_port & 0x03) == 0x03) ? 1u : 0u;
}

static inline uint8_t kernal_visible(const c64_bus_t *b){
    // KERNAL at $E000-$FFFF when HIRAM=1
    return (b->cpu_port & 0x02) ? 1u : 0u;
}

static inline uint8_t charrom_visible(const c64_bus_t *b){
    // CHAR ROM at $D000-$DFFF when CHAREN=0 and (HIRAM=1 or LORAM=1) (typical)
    return (b->cpu_port & 0x04) ? 0u : 1u;
}

static inline uint8_t read_kernal(uint16_t addr){
    return ROM_KERNAL[(uint16_t)(addr - 0xE000)];
}
static inline uint8_t read_basic(uint16_t addr){
    return ROM_BASIC[(uint16_t)(addr - 0xA000)];
}
static inline uint8_t read_char(uint16_t addr){
    return ROM_CHARMAP[(uint16_t)(addr - 0xD000)];
}

// ---------------- init ----------------
void c64_bus_init(c64_bus_t *b, vic_t *vic, cia_t *cia1, cia_t *cia2, c64_video_t std){
    memset(b, 0, sizeof(*b));
    b->cpu_ddr  = 0x2F;   // common power-on-ish
    b->cpu_port = 0x37;   // LORAM=1, HIRAM=1, CHAREN=1 (normal C64)
    b->vic  = vic;
    b->cia1 = cia1;
    b->cia2 = cia2;
    b->video_std = std;

    if (b->vic)  b->vic->std = std;
    c64_bus_install_stub_roms();
}

void c64_bus_set_sid(c64_bus_t *b, void *sid_user, c64_sid_read_fn rd, c64_sid_write_fn wr){
    b->sid_user = sid_user;
    b->sid_read = rd;
    b->sid_write = wr;
}

// ---------------- stub ROM installer ----------------
static void poke16_kernal(uint16_t addr, uint16_t val){
    // addr in $E000-$FFFF
    uint16_t o = (uint16_t)(addr - 0xE000);
    if (o + 1u >= 0x2000) return;
    ROM_KERNAL[o + 0] = (uint8_t)(val & 0xFF);
    ROM_KERNAL[o + 1] = (uint8_t)(val >> 8);
}

static void kernal_emit(uint16_t addr, const uint8_t *bytes, uint16_t n){
    uint16_t o = (uint16_t)(addr - 0xE000);
    if (o >= 0x2000) return;
    if ((uint32_t)o + n > 0x2000) n = (uint16_t)(0x2000 - o);
    memcpy(&ROM_KERNAL[o], bytes, n);
}

void c64_bus_install_stub_roms(void){
    // NOTE:
    // This is intentionally tiny. Real RSID compatibility generally requires *real* ROMs.
    // But we can still provide:
    //  - vectors (RESET/IRQ/NMI)
    //  - a super small IRQ handler that just RTI
    //  - a super small RESET handler that JMPs to RAM $0801 (common BASIC start / many loaders)
    //
    // Many RSID files will still fail without real kernal behavior. This is scaffolding.

    memset(ROM_BASIC,  0xEA, sizeof(ROM_BASIC));   // fill with NOP
    memset(ROM_KERNAL, 0xEA, sizeof(ROM_KERNAL));
    memset(ROM_CHARMAP,0x00, sizeof(ROM_CHARMAP));

    // --- KERNAL minimal code locations ---
    // Place IRQ routine at $FF48 (arbitrary in ROM area): SEI / RTI or just RTI
    // We'll do: PHA, TXA, PHA, TYA, PHA, ... RTI is overkill; simplest RTI.
    const uint16_t IRQ_VEC = 0xFF48;
    const uint8_t irq_code[] = { 0x40 }; // RTI
    kernal_emit(IRQ_VEC, irq_code, (uint16_t)sizeof(irq_code));

    // NMI routine at $FF50: RTI
    const uint16_t NMI_VEC = 0xFF50;
    const uint8_t nmi_code[] = { 0x40 }; // RTI
    kernal_emit(NMI_VEC, nmi_code, (uint16_t)sizeof(nmi_code));

    // RESET routine at $FCE2 (where real ROM does stuff), here: JMP $0801
    const uint16_t RST_VEC = 0xFCE2;
    const uint8_t rst_code[] = { 0x4C, 0x01, 0x08 }; // JMP $0801
    kernal_emit(RST_VEC, rst_code, (uint16_t)sizeof(rst_code));

    // Vectors at $FFFA..$FFFF
    poke16_kernal(0xFFFA, NMI_VEC);
    poke16_kernal(0xFFFC, RST_VEC);
    poke16_kernal(0xFFFE, IRQ_VEC);
}

// ---------------- read/write ----------------
uint8_t c64_bus_read8(void *user, uint16_t addr){
    c64_bus_t *b = (c64_bus_t*)user;

    // CPU port regs
    if (addr == 0x0000) return b->cpu_ddr;
    if (addr == 0x0001) return b->cpu_port;

    // ROM regions (reads only)
    if (addr >= 0xA000 && addr <= 0xBFFF) {
        if (basic_visible(b)) return read_basic(addr);
        return sysRam[addr];
    }
    if (addr >= 0xE000) {
        if (kernal_visible(b)) return read_kernal(addr);
        return sysRam[addr];
    }

    // IO / CHAR ROM window
    if (addr >= 0xD000 && addr <= 0xDFFF) {
        if (io_visible(b)) {
            // VIC
            if (addr <= 0xD3FF && b->vic) return vic_read(b->vic, addr);
            // SID
            if (addr >= 0xD400 && addr <= 0xD41F) {
                if (b->sid_read) return b->sid_read(b->sid_user, addr);
                return 0x00;
            }
            // CIA1
            if (addr >= 0xDC00 && addr <= 0xDCFF && b->cia1) return cia_read(b->cia1, addr);
            // CIA2
            if (addr >= 0xDD00 && addr <= 0xDDFF && b->cia2) return cia_read(b->cia2, addr);

            // Unimplemented I/O area: return open bus-ish value (0xFF is common)
            return 0xFF;
        } else {
            // CHAREN=0 -> character ROM visible for reads (common for some drivers)
            if (charrom_visible(b)) return read_char(addr);
            return sysRam[addr];
        }
    }

    // Default: RAM
    return sysRam[addr];
}

void c64_bus_write8(void *user, uint16_t addr, uint8_t v){
    c64_bus_t *b = (c64_bus_t*)user;

    // CPU port regs
    if (addr == 0x0000) { b->cpu_ddr = v; return; }
    if (addr == 0x0001) { b->cpu_port = v; return; }

    // Writes always go to RAM "under" ROM too (real C64 behavior)
    sysRam[addr] = v;

    // IO writes (only if IO visible)
    if (addr >= 0xD000 && addr <= 0xDFFF && io_visible(b)) {
        if (addr <= 0xD3FF && b->vic) { vic_write(b->vic, addr, v); return; }
        if (addr >= 0xD400 && addr <= 0xD41F) {
            if (b->sid_write) b->sid_write(b->sid_user, addr, v);
            return;
        }
        if (addr >= 0xDC00 && addr <= 0xDCFF && b->cia1) { cia_write(b->cia1, addr, v); return; }
        if (addr >= 0xDD00 && addr <= 0xDDFF && b->cia2) { cia_write(b->cia2, addr, v); return; }
    }
}

void c64_bus_update_irqs(c64_bus_t *b){
    uint8_t irq = 0;

    if (b->cia1) { cia_update_irq(b->cia1); if (b->cia1->irq_line) irq = 1; }
    if (b->vic)  { vic_update_irq(b->vic);   if (b->vic->irq_line)  irq = 1; }

    // CIA2 can generate NMI in real machines; keep as future hook.
    uint8_t nmi = 0;
    if (b->cia2) { cia_update_irq(b->cia2); /* not ORing into IRQ by default */ }

    b->irq_line = irq;
    b->nmi_line = nmi;
}
