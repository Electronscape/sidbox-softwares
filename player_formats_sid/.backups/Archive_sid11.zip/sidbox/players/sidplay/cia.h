#ifndef C64_CIA_H
#define C64_CIA_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Minimal CIA 6526 emulation for RSID/PSID timing.
// Focus: timers A/B, interrupt control (ICR/IMR), basic ports.
// Missing/partial: TOD clock, serial port, real keyboard/joystick matrix, etc.

typedef struct cia_t {
    // I/O ports
    uint8_t pra, prb;
    uint8_t ddra, ddrb;

    // Timers (latches + counters)
    uint16_t ta_latch, tb_latch;
    uint16_t ta, tb;

    // Interrupt Control Register
    // bits 0..4 = sources, bit 7 = "IRQ occurred" (read-only summary)
    uint8_t icr;   // pending flags (latched)
    uint8_t imr;   // mask

    // Control registers
    uint8_t cra, crb;

    // Output line (level) to CPU
    uint8_t irq_line; // 1 = asserted

    // Which CIA (for debug)
    uint8_t id;
} cia_t;

// Reset to power-on defaults
void cia_reset(cia_t *c, uint8_t id);

// Tick by N CPU cycles (CIA timers decrement at 1 MHz CPU clock)
void cia_tick(cia_t *c, uint32_t cycles);

// Register access within the CIA page (addr low 8 bits used)
uint8_t cia_read(cia_t *c, uint16_t addr);
void    cia_write(cia_t *c, uint16_t addr, uint8_t v);

// Helper: recompute irq_line from icr/imr
void cia_update_irq(cia_t *c);

#ifdef __cplusplus
}
#endif

#endif // C64_CIA_H
