#ifndef C64_TYPES_H
#define C64_TYPES_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Video standard for timing (VIC line counts differ)
typedef enum { C64_PAL = 0, C64_NTSC = 1 } c64_video_t;

#ifdef __cplusplus
}
#endif

#endif // C64_TYPES_H
