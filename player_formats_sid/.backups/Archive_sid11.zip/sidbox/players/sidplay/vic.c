// vic.c - minimal VIC-II timing (raster + IRQ only)

#include "vic.h"
#include <string.h>

#define VIC_REG(a) ((uint8_t)((a) & 0x3F))

// Registers we care about
#define REG_CTRL1   0x11 // $D011
#define REG_RASTER  0x12 // $D012
#define REG_IRQFLAG 0x19 // $D019
#define REG_IRQMASK 0x1A // $D01A

static inline uint16_t vic_lines(const vic_t *v){
    return (v->std == C64_NTSC) ? 263u : 312u;
}
static inline uint16_t vic_cycles_per_line(const vic_t *v){
    return (v->std == C64_NTSC) ? 65u : 63u;
}

static inline void vic_recalc_raster_cmp(vic_t *v){
    uint16_t lo = v->reg[REG_RASTER];
    uint16_t hi = (uint16_t)((v->reg[REG_CTRL1] & 0x80) ? 0x100 : 0x000);
    v->raster_cmp = (uint16_t)(hi | lo);
}

void vic_update_irq(vic_t *v){
    // IRQ if any enabled flag is set. For our purposes, only raster (bit0) matters.
    uint8_t enabled = v->reg[REG_IRQMASK];
    uint8_t flags   = v->reg[REG_IRQFLAG];
    v->irq_line = ((enabled & flags & 0x0F) ? 1u : 0u);
}

void vic_reset(vic_t *v, c64_video_t std){
    memset(v, 0, sizeof(*v));
    v->std = std;
    v->raster = 0;
    v->cyc_acc = 0;

    // Power-on-ish: $D011 bit4 usually 1 (screen on). Not needed but harmless.
    v->reg[REG_CTRL1] = 0x1B;
    v->reg[REG_RASTER] = 0x00;
    v->reg[REG_IRQFLAG] = 0x00;
    v->reg[REG_IRQMASK] = 0x00;

    vic_recalc_raster_cmp(v);
    vic_update_irq(v);
}

static void vic_step_line(vic_t *v){
    uint16_t lines = vic_lines(v);
    v->raster++;
    if (v->raster >= lines) v->raster = 0;

    // Update $D012 + bit7 of $D011 to reflect current raster
    v->reg[REG_RASTER] = (uint8_t)(v->raster & 0xFF);
    if (v->raster & 0x100) v->reg[REG_CTRL1] |= 0x80;
    else                   v->reg[REG_CTRL1] &= (uint8_t)~0x80;

    // Check raster compare -> set IRQ flag bit0
    if (v->raster == v->raster_cmp) {
        v->reg[REG_IRQFLAG] |= 0x01;
        vic_update_irq(v);
    }
}

void vic_tick(vic_t *v, uint32_t cycles){
    v->cyc_acc += cycles;

    const uint32_t cpl = vic_cycles_per_line(v);
    while (v->cyc_acc >= cpl) {
        v->cyc_acc -= cpl;
        vic_step_line(v);
    }
}

uint8_t vic_read(vic_t *v, uint16_t addr){
    uint8_t r = VIC_REG(addr);

    switch (r) {
    case REG_CTRL1:
    case REG_RASTER:
    case REG_IRQFLAG:
    case REG_IRQMASK:
        return v->reg[r];

    default:
        // Return stored register value for anything else (even though we don't emulate it)
        return v->reg[r];
    }
}

void vic_write(vic_t *v, uint16_t addr, uint8_t val){
    uint8_t r = VIC_REG(addr);

    switch (r) {
    case REG_CTRL1:
        // keep bit7 (raster hi) writeable per real VIC behavior (it is the compare high bit)
        v->reg[r] = (uint8_t)((v->reg[r] & 0x80) | (val & 0x7F));
        // But bit7 of $D011 is also the raster-compare high bit (for compare value)
        if (val & 0x80) v->reg[r] |= 0x80;
        else            v->reg[r] &= (uint8_t)~0x80;
        vic_recalc_raster_cmp(v);
        return;

    case REG_RASTER:
        v->reg[r] = val;
        vic_recalc_raster_cmp(v);
        return;

    case REG_IRQFLAG:
        // Writing 1s clears corresponding flags (bit0..3)
        v->reg[REG_IRQFLAG] &= (uint8_t)~(val & 0x0F);
        vic_update_irq(v);
        return;

    case REG_IRQMASK:
        v->reg[REG_IRQMASK] = val;
        vic_update_irq(v);
        return;

    default:
        v->reg[r] = val;
        return;
    }
}
