// cia.c - minimal MOS 6526 CIA (timers + IRQ)

#include "cia.h"
#include <string.h>

enum {
    CIA_PRA   = 0x00,
    CIA_PRB   = 0x01,
    CIA_DDRA  = 0x02,
    CIA_DDRB  = 0x03,
    CIA_TALO  = 0x04,
    CIA_TAHI  = 0x05,
    CIA_TBLO  = 0x06,
    CIA_TBHI  = 0x07,
    CIA_TOD10 = 0x08,
    CIA_TODSEC= 0x09,
    CIA_TODMIN= 0x0A,
    CIA_TODHR = 0x0B,
    CIA_SDR   = 0x0C,
    CIA_ICR   = 0x0D,
    CIA_CRA   = 0x0E,
    CIA_CRB   = 0x0F
};

// ICR source bits we care about
#define ICR_TA   0x01
#define ICR_TB   0x02
#define ICR_ALRM 0x04
#define ICR_SP   0x08
#define ICR_FLG  0x10
#define ICR_IRQ  0x80

static inline uint8_t timer_running(uint8_t cr){
    return (cr & 0x01) ? 1u : 0u;
}
static inline uint8_t timer_oneshot(uint8_t cr){
    return (cr & 0x08) ? 1u : 0u;
}
static inline void timer_force_load(cia_t *c, int which){
    if (which == 0) c->ta = c->ta_latch;
    else           c->tb = c->tb_latch;
}

void cia_reset(cia_t *c, uint8_t id){
    memset(c, 0, sizeof(*c));
    c->id = id;
    c->pra = c->prb = 0x00;
    c->ddra = c->ddrb = 0x00;
    c->ta_latch = c->tb_latch = 0xFFFF;
    c->ta = c->tb = 0xFFFF;
    c->cra = c->crb = 0x00;
    c->icr = 0x00;
    c->imr = 0x00;
    c->irq_line = 0;
}

void cia_update_irq(cia_t *c){
    // IRQ is asserted if any pending source is enabled
    uint8_t pending_enabled = (uint8_t)(c->icr & c->imr & 0x1F);
    if (pending_enabled) {
        c->irq_line = 1;
        c->icr |= ICR_IRQ; // summary bit set when read
    } else {
        c->irq_line = 0;
        c->icr &= (uint8_t)~ICR_IRQ;
    }
}

static void cia_raise(cia_t *c, uint8_t srcbit){
    c->icr |= srcbit;
    cia_update_irq(c);
}

void cia_tick(cia_t *c, uint32_t cycles){
    // Timers tick at the same rate as the CPU clock (1 cycle per decrement).
    // This function is intentionally simple and not cycle-perfect for weird modes.

    while (cycles--) {
        // Timer A
        if (timer_running(c->cra)) {
            if (c->ta == 0) {
                // Underflow behavior: set interrupt, reload, optionally stop (one-shot)
                cia_raise(c, ICR_TA);
                c->ta = c->ta_latch;
                if (timer_oneshot(c->cra)) c->cra &= (uint8_t)~0x01;
            } else {
                c->ta--;
            }
        }

        // Timer B (only mode implemented: count phi2 cycles)
        if (timer_running(c->crb)) {
            if (c->tb == 0) {
                cia_raise(c, ICR_TB);
                c->tb = c->tb_latch;
                if (timer_oneshot(c->crb)) c->crb &= (uint8_t)~0x01;
            } else {
                c->tb--;
            }
        }
    }
}

uint8_t cia_read(cia_t *c, uint16_t addr){
    uint8_t r = (uint8_t)(addr & 0x0F);

    switch (r) {
    case CIA_PRA:  return c->pra;
    case CIA_PRB:  return c->prb;
    case CIA_DDRA: return c->ddra;
    case CIA_DDRB: return c->ddrb;

    case CIA_TALO: return (uint8_t)(c->ta & 0xFF);
    case CIA_TAHI: return (uint8_t)(c->ta >> 8);
    case CIA_TBLO: return (uint8_t)(c->tb & 0xFF);
    case CIA_TBHI: return (uint8_t)(c->tb >> 8);

    case CIA_ICR: {
        // Reading ICR returns pending sources + bit7 summary,
        // then clears pending source bits (0..4).
        uint8_t v = c->icr;
        c->icr &= (uint8_t)~0x1F;
        cia_update_irq(c);
        return v;
    }

    case CIA_CRA: return c->cra;
    case CIA_CRB: return c->crb;

    default:
        return 0xFF;
    }
}

void cia_write(cia_t *c, uint16_t addr, uint8_t v){
    uint8_t r = (uint8_t)(addr & 0x0F);

    switch (r) {
    case CIA_PRA:  c->pra = v; return;
    case CIA_PRB:  c->prb = v; return;
    case CIA_DDRA: c->ddra = v; return;
    case CIA_DDRB: c->ddrb = v; return;

    case CIA_TALO:
        c->ta_latch = (uint16_t)((c->ta_latch & 0xFF00) | v);
        return;
    case CIA_TAHI:
        c->ta_latch = (uint16_t)((c->ta_latch & 0x00FF) | ((uint16_t)v << 8));
        // Writing high byte loads timer immediately in most modes if stopped
        if (!timer_running(c->cra)) c->ta = c->ta_latch;
        return;

    case CIA_TBLO:
        c->tb_latch = (uint16_t)((c->tb_latch & 0xFF00) | v);
        return;
    case CIA_TBHI:
        c->tb_latch = (uint16_t)((c->tb_latch & 0x00FF) | ((uint16_t)v << 8));
        if (!timer_running(c->crb)) c->tb = c->tb_latch;
        return;

    case CIA_ICR: {
        // Bit7=1 sets mask bits; bit7=0 clears mask bits
        if (v & 0x80) c->imr |= (uint8_t)(v & 0x1F);
        else          c->imr &= (uint8_t)~(v & 0x1F);
        cia_update_irq(c);
        return;
    }

    case CIA_CRA: {
        // Bit4 = force load
        uint8_t prev = c->cra;
        c->cra = (uint8_t)((c->cra & 0xD0) | (v & 0x2F)); // keep unused-ish bits stable-ish
        if (v & 0x10) timer_force_load(c, 0);

        // If transitioning from stopped->started and timer == 0, reload first
        if (!timer_running(prev) && timer_running(c->cra) && c->ta == 0) c->ta = c->ta_latch;

        return;
    }

    case CIA_CRB: {
        uint8_t prev = c->crb;
        c->crb = (uint8_t)((c->crb & 0xD0) | (v & 0x2F));
        if (v & 0x10) timer_force_load(c, 1);
        if (!timer_running(prev) && timer_running(c->crb) && c->tb == 0) c->tb = c->tb_latch;
        return;
    }

    default:
        return;
    }
}
