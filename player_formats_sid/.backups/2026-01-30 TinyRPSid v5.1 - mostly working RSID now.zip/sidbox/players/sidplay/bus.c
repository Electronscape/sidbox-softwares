#include <stdio.h>

#include "bus.h"
#include "cia.h"
#include "sid8579.h"
#include "vic.h"
#include <string.h>

uint8_t C64RAM[65536];

// --- 6510 I/O port ($0000/$0001) for banking ---
// Power-up-ish defaults (C64 reset leaves ROMs visible)
static uint8_t cpu_ddr  = 0x2F; // $0000
static uint8_t cpu_port = 0x37; // $0001

uint8_t bus_get_cpu_ddr(void)  { return cpu_ddr; }
uint8_t bus_get_cpu_port(void) { return cpu_port; }

// Effective output value (inputs read as 1)
static inline uint8_t cpu_port_eff(void){
    return (uint8_t)((cpu_port & cpu_ddr) | (uint8_t)(~cpu_ddr));
}

// Banking bits (from effective port)
static inline int loram_on(uint8_t p){ return (p & 0x01) != 0; }
static inline int hiram_on(uint8_t p){ return (p & 0x02) != 0; }
static inline int charen_on(uint8_t p){ return (p & 0x04) != 0; }


static int seen_basic_read = 0;
static int seen_kernal_read = 0;
static int seen_chargen_read = 0;


// ROM images (user-supplied)
static uint8_t rom_basic[0x2000];   // $A000-$BFFF
static uint8_t rom_kernal[0x2000];  // $E000-$FFFF
static uint8_t rom_chargen[0x1000]; // character ROM when I/O is hidden at $D000-$DFFF
static int have_basic = 0;
static int have_kernal = 0;
static int have_chargen = 0;

static int load_file_exact(const char *path, uint8_t *dst, size_t want){
    if(!path || !*path) return 0;
    FILE *f = fopen(path, "rb");
    if(!f) return 0;
    size_t n = fread(dst, 1, want, f);
    fclose(f);
    return n == want;
}


static uint32_t crc32_simple(const uint8_t *p, size_t n){
    // tiny non-table CRC32 (slow-ish but fine once at startup)
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++){
        crc ^= p[i];
        for (int k = 0; k < 8; k++){
            uint32_t mask = (uint32_t)-(int)(crc & 1u);
            crc = (crc >> 1) ^ (0xEDB88320u & mask);
        }
    }
    return ~crc;
}

int bus_load_roms(const char *basic_rom_path, const char *kernal_rom_path, const char *chargen_rom_path){
    have_basic   = load_file_exact(basic_rom_path,   rom_basic,   sizeof(rom_basic));
    have_kernal  = load_file_exact(kernal_rom_path,  rom_kernal,  sizeof(rom_kernal));
    have_chargen = load_file_exact(chargen_rom_path, rom_chargen, sizeof(rom_chargen));

    printf("[ROM] BASIC   %s  (%s)\n", have_basic  ? "OK" : "MISSING", basic_rom_path  ? basic_rom_path  : "(null)");
    printf("[ROM] KERNAL  %s  (%s)\n", have_kernal ? "OK" : "MISSING", kernal_rom_path ? kernal_rom_path : "(null)");
    printf("[ROM] CHARGEN %s  (%s)\n", have_chargen? "OK" : "MISSING", chargen_rom_path? chargen_rom_path: "(null)");

    if (have_basic)  printf("[ROM] BASIC   crc32=%08X first=%02X last=%02X\n",
               crc32_simple(rom_basic, sizeof(rom_basic)), rom_basic[0], rom_basic[sizeof(rom_basic)-1]);
    if (have_kernal) printf("[ROM] KERNAL  crc32=%08X first=%02X last=%02X\n",
               crc32_simple(rom_kernal, sizeof(rom_kernal)), rom_kernal[0], rom_kernal[sizeof(rom_kernal)-1]);
    if (have_chargen)printf("[ROM] CHARGEN crc32=%08X first=%02X last=%02X\n",
               crc32_simple(rom_chargen, sizeof(rom_chargen)), rom_chargen[0], rom_chargen[sizeof(rom_chargen)-1]);

    return have_basic && have_kernal && have_chargen;


    return have_basic && have_kernal && have_chargen;
}

#define OUT_CHAR_ADDR   0xD7F0

void clear64KRam(void){
    memset(C64RAM, 0, sizeof(C64RAM));

    // Reset banking defaults too (so each tune starts clean)
    cpu_ddr  = 0x2F;
    cpu_port = 0x37;
}




uint8_t bus_read8(uint16_t addr){
    //if(addr == OUT_CHAR_ADDR) return 0; testing debug output cant use this with a rom

    // quite literally the PSID doesnt play around with the other hardware bits, so just get RAM data, then thats it,
    // the PSID player engine does the rest from there
    if(playmode_sidtype == SIDPLAY_PLAYMODE_PSID) {
        return C64RAM[addr];        // For now: pure RAM reads.
    }

    // IF we're coming here -------- its gonna be an RSID -------------------------------------- //
    const uint8_t p = cpu_port_eff();
    const int io_vis = charen_on(p);
    const int charrom_vis = !charen_on(p) && have_chargen;


    // 6510 port regs
    if (addr == 0x0000) return cpu_ddr;
    if (addr == 0x0001) return p;

    // BASIC ROM ($A000-$BFFF)
    if (addr >= 0xA000 && addr <= 0xBFFF && have_basic && loram_on(p) && hiram_on(p)) {
        if (!seen_basic_read){
            seen_basic_read = 1;
            printf("[ROM] BASIC first read @ $%04X = %02X  (p=%02X)\n", addr, rom_basic[addr - 0xA000], p);
        }
        return rom_basic[addr - 0xA000];
    }

    // KERNAL ROM ($E000-$FFFF)
    if (addr >= 0xE000 && have_kernal && hiram_on(p)) {
        if (!seen_kernal_read){
            seen_kernal_read = 1;
            printf("[ROM] KERNAL first read @ $%04X = %02X  (p=%02X)\n", addr, rom_kernal[addr - 0xE000], p);
        }
        return rom_kernal[addr - 0xE000];
    }

    // I/O or CharROM at $D000-$DFFF depending on CHAREN
    if (addr >= 0xD000 && addr <= 0xDFFF) {


        if (io_vis) {
            if (addr == 0xD011 || addr == 0xD012 || addr == 0xD019 || addr == 0xD01A) {
                uint8_t v = vic_read((uint16_t)(0xD000 | (addr & 0x3F)));
                //printf("[BUS] R %04X=%02X  p_eff=%02X\n", addr, v, p);
                return v;
            }

            if (addr == 0xDC0D || addr == 0xDD0D) {
                uint8_t v;
                if (addr == 0xDC0D) v = cia_read(CIA_CHIP_1, 0x0D);
                else                v = cia_read(CIA_CHIP_2, 0x0D);
                //printf("[BUS] R %04X=%02X  p_eff=%02X\n", addr, v, p);
                return v;
            }


            // VIC $D000-$D3FF mirrored, regs 0..63
            if (addr <= 0xD3FF) return vic_read((uint16_t)(0xD000 | (addr & 0x3F)));

            // CIA1 $DC00-$DCFF mirrored, regs 0..15
            if (addr >= 0xDC00 && addr <= 0xDCFF) return cia_read(CIA_CHIP_1, (uint8_t)(addr & 0x0F));

            // CIA2 $DD00-$DDFF mirrored, regs 0..15
            if (addr >= 0xDD00 && addr <= 0xDDFF) return cia_read(CIA_CHIP_2, (uint8_t)(addr & 0x0F));

            // SID reads: leave as RAM for now (fine)
        }  else if (charrom_vis) {
            if (!seen_chargen_read){
                seen_chargen_read = 1;
                printf("[ROM] CHARGEN first read @ $%04X = %02X  (p=%02X)\n", addr, rom_chargen[addr & 0x0FFF], p);
            }
            return rom_chargen[addr & 0x0FFF];
        }
    }

    if (addr == 0xD019) {
        uint8_t val = io_vis ? vic_read(0xD019) : (charrom_vis ? rom_chargen[0x019] : C64RAM[0xD019]);
        //printf("[BUS] R D019=%02X  io_vis=%d p_eff=%02X -> %s\n", val, io_vis, p, io_vis ? "VIC" : (charrom_vis ? "CHARGEN" : "RAM"));
        //return val;
    }


    // a temporary register, and should be removed soon
    //if(addr == OUT_CHAR_ADDR) return 0;

    // default: RAM (including “under ROM”)
    return C64RAM[addr];
}

void bus_write8(uint16_t addr, uint8_t v){
    C64RAM[addr] = v;
    // Always write underlying RAM (matches C64 "writes under ROM" philosophy)
    // if the song is PSID? IGNORE everything else because simply PSID doesnt need anything else after
    // CIA is programmed into the RAM and then managed at the PSID play engine later, NO REAL CIA operation is required
    if(playmode_sidtype == SIDPLAY_PLAYMODE_PSID){
        C64RAM[addr] = v;

        if((addr >= 0xD400) && (addr <= 0xD41F))
            sid_write(0, (uint8_t)(addr & 0x1F), v);
        return;
    }


    /// beyond here is where the lovely RSID should run ##########################################################
    // 6510 port regs
    // For RSID, only treat $D000-$DFFF as I/O when CHAREN=1 and HIRAM=1.
    const uint8_t p = cpu_port_eff();
    const int io_vis = charen_on(p);   // <- make this match bus_read8()

    if (addr == 0xD019 || addr == 0xD01A || addr == 0xD012 || addr == 0xD011) {
        //printf("[BUS] W %04X=%02X  io_vis=%d  p_eff=%02X  ddr=%02X port=%02X\n", addr, v, io_vis, p, cpu_ddr, cpu_port);
    }
    if (addr == 0xDC0D || addr == 0xDD0D) {
        //printf("[BUS] W %04X=%02X  io_vis=%d  p_eff=%02X\n", addr, v, io_vis, p);
    }


    if (addr == 0x0000) { cpu_ddr = v; return; }
    if (addr == 0x0001) { cpu_port = v; return; }



    // SID regions:
    // $D400-$D41F (SID1)
    if (io_vis && addr >= 0xD400 && addr <= 0xD41F) {
        sid_write(0, (uint8_t)(addr & 0x1F), v);
        return;
    }

    // VIC regions: THIS IS EXCITING NOW!!!
    // NOTE: VIC registers are ONLY $D000-$D03F here.
    // Do NOT widen to $D3FF: it will wrongly treat non-VIC I/O space as VIC mirrors.
    // (Later we can implement proper I/O decode/mirroring explicitly.)
    if (io_vis && addr >= 0xD000 && addr <= 0xD3FF) {
        vic_write((uint16_t)(0xD000 | (addr & 0x3F)), v);
        return;
    }

    // CIA registers!!! 1: $DC00 - $DC0F, 2: $DD00 - $DD0F
    if (io_vis && addr >= 0xDC00 && addr <= 0xDCFF) { cia_write(CIA_CHIP_1, (uint8_t)(addr & 0x0F), v); return; }
    if (io_vis && addr >= 0xDD00 && addr <= 0xDDFF) { cia_write(CIA_CHIP_2, (uint8_t)(addr & 0x0F), v); return; }


    // $D420-$D43F (SID2 / "second SID block")
    if (io_vis && (addr >= 0xD420) && (addr <= 0xD43F)) {
        // Important: pass reg in the same 0..63 scheme your old code expects
        // (reg>=32 selects chip) — so we give 0x20..0x3F here.
        sid_write(1, (uint8_t)(0x20 + (addr & 0x1F)), v);
        return;
    }

    // Debug console output: emulate C64 KERNAL CHROUT target buffer
    // We'll treat writing to $FFD2 as "print the character".
    // needs to turn this off now if the roms are there
    if (addr == OUT_CHAR_ADDR) {
        //putchar((char)v);
    }
    C64RAM[addr] = v;

}

void bus_write16(uint16_t addr, uint16_t v){
    if (addr == 0xFFFE) printf("[VEC] IRQ vec <= %04X\n", v);
    bus_write8(addr, (uint8_t)(v & 0xFF));
    bus_write8((uint16_t)(addr + 1), (uint8_t)(v >> 8));
}

uint16_t bus_read16(uint16_t addr){
    uint8_t lo = bus_read8(addr);
    uint8_t hi = bus_read8((uint16_t)(addr + 1));
    return (uint16_t)(lo | ((uint16_t)hi << 8));
}

// 6502 JMP (indirect) bug: wraps high-byte fetch within the same page
uint16_t bus_read16_wrap(uint16_t addr){
    uint8_t lo = bus_read8(addr);
    uint16_t addr2 = (uint16_t)((addr & 0xFF00) | ((addr + 1) & 0x00FF));
    uint8_t hi = bus_read8(addr2);
    return (uint16_t)(lo | ((uint16_t)hi << 8));
}




