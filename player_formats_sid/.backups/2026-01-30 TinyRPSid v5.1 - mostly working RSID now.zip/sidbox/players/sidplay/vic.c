#include <stdio.h>

#include "vic.h"

uint8_t  VICREG[0x40];
uint16_t VICRASTER;
uint32_t VIC_CYC_ACC;
uint8_t  VIC_IRQ_LINE;


static uint8_t  VIC_RASTER_CMP_LO;   // latch written via $D012
static uint8_t  VIC_RASTER_CMP_HI;   // latch written via bit7 of $D011


#define VIC_R(a) ((uint8_t)((a) & 0x3F))


static uint8_t raster_hit_latched = 0; // 0 = not yet triggered at current match, 1 = already triggered


static inline uint16_t vic_raster_cmp(void){
    //uint16_t hi = (VICREG[0x11] & 0x80) ? 0x100 : 0x000;
    //uint16_t lo = VICREG[0x12];
    //return (uint16_t)(hi | lo);
    return (uint16_t)((VIC_RASTER_CMP_HI ? 0x100 : 0x000) | VIC_RASTER_CMP_LO);
}

static inline void vic_update_irq(void){
    uint8_t pending = (uint8_t)(VICREG[0x19] & 0x0F);
    uint8_t mask    = (uint8_t)(VICREG[0x1A] & 0x0F);

    VIC_IRQ_LINE = (pending & mask) ? 1 : 0;

    // Optional, but nice: bit7 readback indicates IRQ active
    if (VIC_IRQ_LINE) VICREG[0x19] |= 0x80;
    else              VICREG[0x19] &= (uint8_t)~0x80;

}

void vic_clear_irq(void){
    VIC_IRQ_LINE = 0;
    VICREG[0x19] &= (uint8_t)~0x80;
}

void vic_reset(void){
    for(int i=0;i<0x40;i++) VICREG[i]=0;
    VICRASTER = 0;
    VIC_CYC_ACC = 0;
    VIC_IRQ_LINE = 0;

    VIC_RASTER_CMP_LO = 0;
    VIC_RASTER_CMP_HI = 0;

    raster_hit_latched = 0;



    // sensible-ish default
    VICREG[0x11] = 0x1B; // bit7 cleared ( for clarity = (0x1B & 0x7F)  )
    VICREG[0x12] = 0x00;
    VICREG[0x19] = 0x00;
    VICREG[0x1A] = 0x00;
}

uint8_t vic_read(uint16_t addr){
    uint8_t r = VIC_R(addr);

    if (r == 0x12) return (uint8_t)(VICRASTER & 0xFF);

    // updated with this
    // This prevents any accidental weirdness if code relies on bits 0..6 staying stable while polling.
    if (r == 0x11){
        uint8_t v = (uint8_t)(VICREG[0x11] & 0x7F);  // keep bits 0..6 as written
        if (VICRASTER & 0x100) v |= 0x80;            // bit7 = current raster hi
        return v;
    }

    /* asked to not use this anymore
    if (r == 0x11){
        uint8_t v = VICREG[0x11];
        if (VICRASTER & 0x100) v |= 0x80;
        else                   v &= (uint8_t)~0x80;
        return v;
    }
    */

    return VICREG[r];
}

void vic_write(uint16_t addr, uint8_t val){
    uint8_t r = VIC_R(addr);

    switch(r){

        // this section is locked in now, too many u-turns, stick to basics
        case 0x12: // $D012 raster compare low
            VIC_RASTER_CMP_LO = val;
            VICREG[0x12] = val;

            // DO NOT trigger IRQ here. Real VIC triggers on raster reaching the compare.
            // Also reset latch so next compare crossing can fire properly.
            raster_hit_latched = 0;

            vic_update_irq();
            return;

        case 0x11: // $D011 (bit7 = raster compare high bit latch)
            VIC_RASTER_CMP_HI = (val & 0x80) ? 1 : 0;
            VICREG[0x11] = (uint8_t)(val & 0x7F);

            // DO NOT trigger IRQ here either.
            raster_hit_latched = 0;

            vic_update_irq();
            return;





        case 0x19: {
            uint8_t clear = (uint8_t)(val & 0x0F);

            // HACK TEST: if raster is pending and they write anything nonzero, clear raster.
            //if ((VICREG[0x19] & 0x01) && val) clear |= 0x01;

            VICREG[0x19] &= (uint8_t)~clear;
            vic_update_irq();
            return;
        }

        case 0x1A:
            //printf("[VIC] D01A <= %02X\n", val);
            //VICREG[0x1A] = val;
            VICREG[0x1A] = (uint8_t)(val & 0x0F);

            vic_update_irq();
            return;

        default:
            VICREG[r] = val;
            return;
    }
}

void vic_step(int cpu_cycles){
    const int32_t CYC_PER_LINE = 63;
    const int32_t LINES_PER_FRAME = 312;

    VIC_CYC_ACC += (uint32_t)cpu_cycles;

    while (VIC_CYC_ACC >= (uint32_t)CYC_PER_LINE){
        VIC_CYC_ACC -= (uint32_t)CYC_PER_LINE;

        VICRASTER++;
        if (VICRASTER >= LINES_PER_FRAME) VICRASTER = 0;

        uint16_t cmp = vic_raster_cmp();

        // latch behavior: fire once when raster == cmp, then don't refire until raster != cmp again
        if (VICRASTER == cmp){
            if (!raster_hit_latched){
                raster_hit_latched = 1;
                VICREG[0x19] |= 0x01;   // raster IRQ pending
                vic_update_irq();
            }
        } else {
            raster_hit_latched = 0;
        }
    }
}

