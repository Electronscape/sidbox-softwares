#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "3dloader.h"
#include "sb3d.h"
int loadMeshOBJ(const char *filename, Mesh *mesh, uint8_t colour, float scale)
{
    FILE *fp;
    char line[512];

    int vertCount = 0;
    int triCount = 0;

    if (!filename || !mesh) return 0;

    fp = fopen(filename, "r");
    if (!fp) {
        return 0;
    }

    /* ---------- pass 1: count verts + tris ---------- */
    while (fgets(line, sizeof(line), fp)) {
        if (line[0] == 'v' && line[1] == ' ') {
            vertCount++;
        }
        else if (line[0] == 'f' && line[1] == ' ') {
            int faceVerts = 0;
            char *p = line + 2;

            while (*p) {
                while (*p == ' ' || *p == '\t') p++;
                if (*p == '\0' || *p == '\n' || *p == '\r') break;

                faceVerts++;

                while (*p && *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r') {
                    p++;
                }
            }

            if (faceVerts >= 3) {
                triCount += (faceVerts - 2); /* fan triangulate */
            }
        }
    }

    if (vertCount <= 0 || triCount <= 0) {
        fclose(fp);
        return 0;
    }

    mesh->vertCount = vertCount;
    mesh->triCount  = triCount;
    mesh->edgeCount = 0;

    mesh->verts = malloc(sizeof(Vec3) * mesh->vertCount);
    mesh->tris  = malloc(sizeof(Tri)  * mesh->triCount);
    mesh->edges = NULL;

    if (!mesh->verts || !mesh->tris) {
        if (mesh->verts) free(mesh->verts);
        if (mesh->tris)  free(mesh->tris);
        mesh->verts = NULL;
        mesh->tris  = NULL;
        mesh->vertCount = 0;
        mesh->triCount  = 0;
        fclose(fp);
        return 0;
    }

    rewind(fp);

    /* ---------- pass 2: fill verts + tris ---------- */
    {
        int vi = 0;
        int ti = 0;
        uint8_t currentColour = colour;

        while (fgets(line, sizeof(line), fp)) {
            if (line[0] == 'v' && line[1] == ' ') {
                float bx, by, bz;

                if (sscanf(line + 2, "%f %f %f", &bx, &by, &bz) == 3) {
                    /* Blender export already set to match engine:
                       X right, Y up, Z forward
                    */
                    mesh->verts[vi].x = bx * scale;
                    mesh->verts[vi].y = by * scale;
                    mesh->verts[vi].z = -bz * scale;
                    vi++;
                }
            }
            else if (strncmp(line, "usemtl ", 7) == 0) {
                char matName[128];
                int parsedColour;

                matName[0] = '\0';

                if (sscanf(line + 7, "%127s", matName) == 1) {
                    /* expected names like: SBX_32 */
                    if (strncmp(matName, "SBX_", 4) == 0) {
                        parsedColour = atoi(matName + 4);
                        if (parsedColour >= 0 && parsedColour <= 255) {
                            currentColour = (uint8_t)parsedColour;
                        }
                    }
                }
            }
            else if (line[0] == 'f' && line[1] == ' ') {
                int idx[32];
                int n = 0;

                char *saveptr = NULL;
                char *tok = strtok_r(line + 2, " \t\r\n", &saveptr);

                while (tok && n < 32) {
                    /* parse first integer before any slash */
                    idx[n] = (int)strtol(tok, NULL, 10);
                    n++;
                    tok = strtok_r(NULL, " \t\r\n", &saveptr);
                }

                if (n >= 3) {
                    /* OBJ indices are 1-based */
                    int a0 = idx[0] - 1;

                    for (int k = 1; k < n - 1; k++) {
                        int a1 = idx[k]     - 1;
                        int a2 = idx[k + 1] - 1;

                        if (a0 < 0 || a0 >= mesh->vertCount) continue;
                        if (a1 < 0 || a1 >= mesh->vertCount) continue;
                        if (a2 < 0 || a2 >= mesh->vertCount) continue;

                        mesh->tris[ti].a = a0;
                        mesh->tris[ti].b = a2;
                        mesh->tris[ti].c = a1;
                        mesh->tris[ti].color = currentColour;
                        ti++;
                    }
                }
            }
        }

        mesh->triCount = ti;
    }

    fclose(fp);

    mesh->boundsRadius = meshComputeBoundsRadius(mesh);
    meshSetDefaultMaterial(mesh);

    return 1;
}

void freeMesh(Mesh *mesh)
{
    if (!mesh) return;

    if (mesh->verts) free(mesh->verts);
    if (mesh->tris)  free(mesh->tris);
    if (mesh->edges) free(mesh->edges);

    mesh->verts = NULL;
    mesh->tris  = NULL;
    mesh->edges = NULL;

    mesh->vertCount = 0;
    mesh->triCount  = 0;
    mesh->edgeCount = 0;
    mesh->boundsRadius = 0.0f;
}