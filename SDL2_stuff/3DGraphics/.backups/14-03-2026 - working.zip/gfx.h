
#ifndef _GFX_LIB_TEST_H_
#define _GFX_LIB_TEST_H_

#include <stdint.h>




//#define SCREEN_W  480
//#define SCREEN_H  320
#define SCREEN_W  1280
#define SCREEN_H  800



extern uint32_t clut[256];
extern uint8_t fb[];    // framebuffer (interal)
extern uint32_t pb[];   // the presented buffer for SDL2

typedef enum {
    DITHER_BAYER4X4 = 0,
    DITHER_RANDOM   = 1
} DitherMode;



extern uint16_t g_depthBuffer[SCREEN_W * SCREEN_H];

void drawText(int x, int y, const char *text, uint8_t color);

void videoMemToScreen();// real basic clear screen
void clearScreen(uint8_t colIndex);
void putPixel(int32_t x, int32_t y, uint8_t colIndex);
void drawLine(int x0, int y0, int x1, int y1, uint8_t colorIndex);

uint8_t shadeColor(uint8_t baseColor, int shade);
void fillTriangle(int x0, int y0, int x1, int y1, int x2, int y2, uint8_t color);
void fillTriangleDither(int x0, int y0, int x1, int y1, int x2, int y2, uint8_t baseColor, float shadeF, DitherMode mode);

// ZORDERED
void fillTriangleDitherZ(
    int x0, int y0,
    int x1, int y1,
    int x2, int y2,
    uint16_t z0,
    uint16_t z1,
    uint16_t z2,
    uint8_t baseColor,
    float shadeF,
    DitherMode mode
);

void fillTriangleDitherZBayer(
    int x0, int y0,
    int x1, int y1,
    int x2, int y2,
    uint16_t z0,
    uint16_t z1,
    uint16_t z2,
    uint8_t baseColor,
    float shadeF
);

uint32_t darken(uint32_t c, float f);
void resetRand();


void drawRect(int x, int y, int w, int h, uint8_t col);

#endif