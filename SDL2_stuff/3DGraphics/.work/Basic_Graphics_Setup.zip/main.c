#include <SDL2/SDL.h>

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>



// basic includes
#include "gfx.h"




#define FPS        144
#define A_FPS_MS   (1000 / FPS)

int tmr1;
//static uint8_t mouseAction = 0;

#define ZOOM 2

//static uint32_t indexTmrTest = 0;

int main(void) {
    //// HOST STARTUP
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window *sdl_win = SDL_CreateWindow(
        "3D Balls-up world Host (SDL2)",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        SCREEN_W * ZOOM, SCREEN_H * ZOOM, 0
    );
    if (!sdl_win) {
        fprintf(stderr, "CreateWindow failed: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Renderer *ren = SDL_CreateRenderer(sdl_win, -1, SDL_RENDERER_ACCELERATED);
    SDL_Texture  *tex = SDL_CreateTexture (ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, SCREEN_W, SCREEN_H);
    if (!ren) {
        fprintf(stderr, "SDL_CreateRenderer failed: %s\n", SDL_GetError());
        SDL_DestroyWindow(sdl_win);
        SDL_Quit();
        return 1;
    }

    if (!tex) {
        fprintf(stderr, "SDL_CreateTexture failed: %s\n", SDL_GetError());
        SDL_DestroyRenderer(ren);
        SDL_DestroyWindow(sdl_win);
        SDL_Quit();
        return 1;
    }
    
    int running = 1;
    const int tick_ms = A_FPS_MS;
    uint32_t last = SDL_GetTicks();

    // basic start screen direct to screen memory
    for(int32_t i = 0; i < SCREEN_H * SCREEN_W; i++){
        fb[i] = 80;
    }

    clearScreen(0);
    clut[0] = 0xFF000000;
    clut[1] = 0xFFFFFFFF;
    clut[2] = 0xFFFF0000;
    clut[3] = 0xFF00FF00;
    clut[4] = 0xFF0000FF;
    clut[5] = 0xFFFFFF00;

    putPixel(10, 10, 1);
    putPixel(11, 10, 2);
    putPixel(12, 10, 3);
    putPixel(13, 10, 4);

    drawLine(100, 100, 300, 100, 2);
    drawLine(300, 100, 300, 300, 3);
    drawLine(300, 300, 100, 300, 4);
    drawLine(100, 300, 100, 100, 5);

    
    while (running) {
        uint32_t frame_start = SDL_GetTicks();

        // ---- 1) process all pending events (NO WAIT here) ----
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) running = 0;
            if ((e.type == SDL_KEYDOWN) && (e.key.repeat == 0) && (e.key.keysym.sym == SDLK_ESCAPE))
                running = 0;

            switch (e.type) {

                case SDL_TEXTINPUT: {
                    // UTF-8 string; you only want ASCII for now
                    const char *s = e.text.text;
                    for (int i = 0; s[i]; i++) {
                        unsigned char c = (unsigned char)s[i];
                        if (c >= 32 && c <= 126) {
                            //SBOSIO_KeyboardInterface(c, 0);
                            // a keyboard interface
                        }
                    }
                } break;
                

                case SDL_KEYDOWN: {
                    //if (e.key.repeat) break;

                    //uint8_t mod = 0;
                    //SDL_Keymod m = SDL_GetModState();
                    /*
                    if (m & KMOD_SHIFT) mod |= KM_SHIFT;
                    if (m & KMOD_CTRL)  mod |= KM_CTRL;
                    if (m & KMOD_ALT)   mod |= KM_ALT;

                    switch (e.key.keysym.sym) {
                        case SDLK_BACKSPACE: SBOSIO_KeyboardInterface(KEY_BACKSPACE, mod); break;
                        case SDLK_DELETE:    SBOSIO_KeyboardInterface(KEY_DEL, mod);       break;
                        case SDLK_LEFT:      SBOSIO_KeyboardInterface(KEY_LEFT, mod);      break;
                        case SDLK_RIGHT:     SBOSIO_KeyboardInterface(KEY_RIGHT, mod);     break;
                        case SDLK_UP:        SBOSIO_KeyboardInterface(KEY_UP, mod);        break;
                        case SDLK_DOWN:      SBOSIO_KeyboardInterface(KEY_DOWN, mod);      break;
                        case SDLK_HOME:      SBOSIO_KeyboardInterface(KEY_HOME, mod);      break;
                        case SDLK_END:       SBOSIO_KeyboardInterface(KEY_END, mod);       break;
                        case SDLK_RETURN:
                        case SDLK_KP_ENTER:  SBOSIO_KeyboardInterface(KEY_ENTER, mod);     break;
                        case SDLK_TAB:       SBOSIO_KeyboardInterface(KEY_TAB, mod);       break;
                        case SDLK_ESCAPE:    SBOSIO_KeyboardInterface(KEY_ESC, mod);       break;
                        default: break;
                    }
                    */
                } break;
            }
        }

        // ---- 2) your per-frame stuff ----
        //pump_mouse_sdl();

        uint32_t now = SDL_GetTicks();
        uint32_t dt  = now - last;
        last = now;

        tmr1 += dt;
        if (tmr1 >= 1000) {
            tmr1 = 0;
            
        }



        videoMemToScreen();
        SDL_UpdateTexture(tex, NULL, pb, SCREEN_W * (int)sizeof(uint32_t));
        SDL_RenderCopy(ren, tex, NULL, NULL);
        SDL_RenderPresent(ren);

        // ---- 3) sleep remainder of frame (THIS is your cap) ----
        uint32_t frame_end = SDL_GetTicks();
        uint32_t elapsed = frame_end - frame_start;

        if (elapsed < tick_ms) {
            //SDL_Delay((uint32_t)(tick_ms - elapsed));
        }
        //SDL_GL_SetSwapInterval(1);
        
    }


    SDL_DestroyTexture(tex);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(sdl_win);
    SDL_Quit();
    printf("END OF PLAY\n");

    return 0;
}

