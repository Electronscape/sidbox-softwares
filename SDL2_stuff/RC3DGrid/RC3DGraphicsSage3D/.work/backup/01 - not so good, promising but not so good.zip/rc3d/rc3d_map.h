// file: rc3d/rc3d_map.h
#ifndef RC3D_MAP_H
#define RC3D_MAP_H

#include <stdint.h>

typedef struct
{
    float x;
    float y;
} RCVec2;

typedef struct
{
    uint16_t v0;
    uint16_t v1;

    int16_t neighbor;      /* -1 = solid wall, otherwise adjacent sector */
    uint8_t wallColor;
} RCWall;

typedef struct
{
    uint16_t firstWall;
    uint16_t wallCount;

    float floorZ;
    float ceilZ;

    uint8_t floorColor;
    uint8_t ceilColor;
} RCSector;

typedef struct
{
    const RCVec2  *verts;
    int            vertCount;

    const RCWall  *walls;
    int            wallCount;

    const RCSector *sectors;
    int             sectorCount;
} RCMap;

const RCMap *rc3dGetDemoMap(void);

#endif