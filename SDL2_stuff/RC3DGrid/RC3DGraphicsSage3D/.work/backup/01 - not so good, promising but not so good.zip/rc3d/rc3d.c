// file: rc3d/rc3d.c
#include <math.h>
#include <stdint.h>
#include <SDL2/SDL.h>

#include "../gfx.h"
#include "rc3d.h"
#include "rc3d_map.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define RC3D_FOV_DEG        75.0f
#define RC3D_NEAR_Z         0.05f
#define RC3D_MOVE_SPEED     3.25f
#define RC3D_STRAFE_SPEED   2.60f
#define RC3D_TURN_SPEED     2.30f
#define RC3D_MOUSE_SENS     0.0025f
#define RC3D_PLAYER_RADIUS  0.22f

#define RC3D_MINIMAP_SCALE  8
#define RC3D_MINIMAP_PAD    8
#define RC3D_MINIMAP_W      160
#define RC3D_MINIMAP_H      160

#define MINI_OUT_LEFT   1
#define MINI_OUT_RIGHT  2
#define MINI_OUT_TOP    4
#define MINI_OUT_BOTTOM 8

#define RC3D_MAX_WALL_SPANS   64
#define RC3D_MAX_CLIP_RANGES  64

typedef struct
{
    int x0;
    int x1;
} ClipRange;

typedef struct
{
    float sx0;
    float sx1;
    float top0;
    float top1;
    float bot0;
    float bot1;
    float nearDepth;
    uint8_t col;
} WallSpan;


typedef struct
{
    float x;
    float y;
} Vec2;

typedef struct
{
    float x;   /* camera-right */
    float z;   /* camera-forward depth */
} Cam2;

typedef struct
{
    Vec2 pos;
    float z;
    float angle;

    Vec2 forward;
    Vec2 right;
} RCPlayer;

static const RCMap *g_map = 0;
static RCPlayer g_player;

static float g_projScale = 0.0f;

static inline float v2Dot(Vec2 a, Vec2 b)
{
    return (a.x * b.x) + (a.y * b.y);
}

static inline Vec2 v2Add(Vec2 a, Vec2 b)
{
    Vec2 r;
    r.x = a.x + b.x;
    r.y = a.y + b.y;
    return r;
}

static inline Vec2 v2Sub(Vec2 a, Vec2 b)
{
    Vec2 r;
    r.x = a.x - b.x;
    r.y = a.y - b.y;
    return r;
}

static inline Vec2 v2Scale(Vec2 v, float s)
{
    Vec2 r;
    r.x = v.x * s;
    r.y = v.y * s;
    return r;
}

static inline float clampf(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static inline int clampi(int v, int lo, int hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static inline int miniOriginX(void)
{
    return SCREEN_W - RC3D_MINIMAP_PAD - RC3D_MINIMAP_W;
}

static inline int miniOriginY(void)
{
    return RC3D_MINIMAP_PAD;
}

static inline int miniCenterX(void)
{
    return miniOriginX() + (RC3D_MINIMAP_W / 2);
}

static inline int miniCenterY(void)
{
    return miniOriginY() + (RC3D_MINIMAP_H / 2);
}

static inline int worldToMiniX(float wx)
{
    return miniCenterX() + (int)((wx - g_player.pos.x) * RC3D_MINIMAP_SCALE);
}

static inline int worldToMiniY(float wy)
{
    return miniCenterY() + (int)((wy - g_player.pos.y) * RC3D_MINIMAP_SCALE);
}















static void rc3dRebuildView(void)
{
    const float c = cosf(g_player.angle);
    const float s = sinf(g_player.angle);

    /* angle 0 = face east */
    g_player.forward.x = c;
    g_player.forward.y = s;

    g_player.right.x = -s;
    g_player.right.y =  c;
}

static Cam2 worldToCamera(Vec2 p)
{
    const Vec2 rel = v2Sub(p, g_player.pos);
    Cam2 out;

    out.x = v2Dot(rel, g_player.right);
    out.z = v2Dot(rel, g_player.forward);

    return out;
}


static int pointInSector(const RCSector *sec, Vec2 p)
{
    int inside = 0;
    int i;
    int j = sec->wallCount - 1;

    for (i = 0; i < sec->wallCount; i++) {
        const RCWall *wi = &g_map->walls[sec->firstWall + i];
        const RCWall *wj = &g_map->walls[sec->firstWall + j];

        const RCVec2 vi = g_map->verts[wi->v0];
        const RCVec2 vj = g_map->verts[wj->v0];

        const int intersect =
            ((vi.y > p.y) != (vj.y > p.y)) &&
            (p.x < (vj.x - vi.x) * (p.y - vi.y) / ((vj.y - vi.y) + 1e-20f) + vi.x);

        if (intersect) inside = !inside;
        j = i;
    }

    return inside;
}


static float distPointToSegmentSq(Vec2 p, Vec2 a, Vec2 b)
{
    const Vec2 ab = v2Sub(b, a);
    const Vec2 ap = v2Sub(p, a);
    const float abLenSq = v2Dot(ab, ab);

    float t;
    Vec2 c;
    Vec2 d;

    if (abLenSq <= 1e-20f) {
        d = v2Sub(p, a);
        return v2Dot(d, d);
    }

    t = v2Dot(ap, ab) / abLenSq;
    t = clampf(t, 0.0f, 1.0f);

    c = v2Add(a, v2Scale(ab, t));
    d = v2Sub(p, c);

    return v2Dot(d, d);
}


static int pointHasWallClearance(const RCSector *sec, Vec2 p, float radius)
{
    int i;
    const float r2 = radius * radius;

    for (i = 0; i < sec->wallCount; i++) {
        const RCWall *w = &g_map->walls[sec->firstWall + i];
        Vec2 a;
        Vec2 b;

        a.x = g_map->verts[w->v0].x;
        a.y = g_map->verts[w->v0].y;

        b.x = g_map->verts[w->v1].x;
        b.y = g_map->verts[w->v1].y;

        if (distPointToSegmentSq(p, a, b) < r2) {
            return 0;
        }
    }

    return 1;
}



static int canStandAt(Vec2 p)
{
    const RCSector *sec = &g_map->sectors[0];

    if (!pointInSector(sec, p)) return 0;
    if (!pointHasWallClearance(sec, p, RC3D_PLAYER_RADIUS)) return 0;

    return 1;
}

static int clipSegmentToNear(Cam2 *a, Cam2 *b)
{
    const int aIn = (a->z >= RC3D_NEAR_Z);
    const int bIn = (b->z >= RC3D_NEAR_Z);

    if (aIn && bIn) return 1;
    if (!aIn && !bIn) return 0;

    {
        const float dz = b->z - a->z;
        const float dx = b->x - a->x;
        const float t  = (RC3D_NEAR_Z - a->z) / dz;
        Cam2 p;

        p.x = a->x + dx * t;
        p.z = RC3D_NEAR_Z;

        if (!aIn) {
            *a = p;
        } else {
            *b = p;
        }
    }

    return 1;
}

static void sortWallSpanEnds(
    float *sx0, float *sx1,
    float *top0, float *top1,
    float *bot0, float *bot1)
{
    if (*sx0 > *sx1) {
        float t;
        t = *sx0;  *sx0 = *sx1;  *sx1 = t;
        t = *top0; *top0 = *top1; *top1 = t;
        t = *bot0; *bot0 = *bot1; *bot1 = t;
    }
}

static void subtractRangeFromVisible(
    ClipRange *ranges,
    int *rangeCount,
    int cutX0,
    int cutX1)
{
    ClipRange out[RC3D_MAX_CLIP_RANGES];
    int outCount = 0;

    for (int i = 0; i < *rangeCount; i++) {
        const int rx0 = ranges[i].x0;
        const int rx1 = ranges[i].x1;

        if (cutX1 < rx0 || cutX0 > rx1) {
            if (outCount < RC3D_MAX_CLIP_RANGES) {
                out[outCount++] = ranges[i];
            }
            continue;
        }

        if (cutX0 > rx0) {
            if (outCount < RC3D_MAX_CLIP_RANGES) {
                out[outCount].x0 = rx0;
                out[outCount].x1 = cutX0 - 1;
                outCount++;
            }
        }

        if (cutX1 < rx1) {
            if (outCount < RC3D_MAX_CLIP_RANGES) {
                out[outCount].x0 = cutX1 + 1;
                out[outCount].x1 = rx1;
                outCount++;
            }
        }
    }

    for (int i = 0; i < outCount; i++) {
        ranges[i] = out[i];
    }

    *rangeCount = outCount;
}

static void drawWallSpanProjectedClipped(
    float sx0, float sx1,
    float top0, float top1,
    float bot0, float bot1,
    int clipX0, int clipX1,
    uint8_t col)
{
    if (clipX1 < clipX0) return;

    sortWallSpanEnds(&sx0, &sx1, &top0, &top1, &bot0, &bot1);

    if (sx1 - sx0 < 1e-6f) {
        const int x = clampi((int)(sx0 + 0.5f), clipX0, clipX1);
        int y0 = clampi((int)ceilf(top0), 0, SCREEN_H - 1);
        int y1 = clampi((int)floorf(bot0), 0, SCREEN_H - 1);

        if (y1 >= y0) {
            for (int y = y0; y <= y1; y++) {
                putPixel(x, y, col);
            }
        }
        return;
    }

    for (int x = clipX0; x <= clipX1; x++) {
        const float t = ((float)x - sx0) / (sx1 - sx0);
        const float top = top0 + (top1 - top0) * t;
        const float bot = bot0 + (bot1 - bot0) * t;

        int y0 = (int)ceilf(top);
        int y1 = (int)floorf(bot);

        if (y0 < 0) y0 = 0;
        if (y1 >= SCREEN_H) y1 = SCREEN_H - 1;

        if (y1 >= y0) {
            for (int y = y0; y <= y1; y++) {
                putPixel(x, y, col);
            }
        }
    }
}


static void drawWallSpanProjected(
    float sx0, float sx1,
    float top0, float top1,
    float bot0, float bot1,
    uint8_t col)
{
    int ix0;
    int ix1;

    sortWallSpanEnds(&sx0, &sx1, &top0, &top1, &bot0, &bot1);

    ix0 = clampi((int)ceilf(sx0), 0, SCREEN_W - 1);
    ix1 = clampi((int)floorf(sx1), 0, SCREEN_W - 1);

    if (ix1 < ix0) return;

    drawWallSpanProjectedClipped(sx0, sx1, top0, top1, bot0, bot1, ix0, ix1, col);
}


static void drawSectorWalls(const RCSector *sec)
{
    WallSpan spans[RC3D_MAX_WALL_SPANS];
    int spanCount = 0;

    ClipRange visible[RC3D_MAX_CLIP_RANGES];
    int visibleCount = 1;

    visible[0].x0 = 0;
    visible[0].x1 = SCREEN_W - 1;

    for (int i = 0; i < sec->wallCount; i++) {
        const RCWall *w = &g_map->walls[sec->firstWall + i];

        Vec2 wa;
        Vec2 wb;
        Vec2 edge;
        Vec2 mid;
        Vec2 toCam;
        Cam2 ca;
        Cam2 cb;
        WallSpan s;

        wa.x = g_map->verts[w->v0].x;
        wa.y = g_map->verts[w->v0].y;

        wb.x = g_map->verts[w->v1].x;
        wb.y = g_map->verts[w->v1].y;

        edge = v2Sub(wb, wa);
        mid = v2Scale(v2Add(wa, wb), 0.5f);
        toCam = v2Sub(g_player.pos, mid);

        if ((edge.x * toCam.y) - (edge.y * toCam.x) <= 0.0f) {
            continue;
        }

        ca = worldToCamera(wa);
        cb = worldToCamera(wb);

        if (!clipSegmentToNear(&ca, &cb)) {
            continue;
        }

        s.sx0 = ((float)SCREEN_W * 0.5f) + (ca.x * g_projScale / ca.z);
        s.sx1 = ((float)SCREEN_W * 0.5f) + (cb.x * g_projScale / cb.z);

        s.top0 = ((float)SCREEN_H * 0.5f) - ((sec->ceilZ  - g_player.z) * g_projScale / ca.z);
        s.top1 = ((float)SCREEN_H * 0.5f) - ((sec->ceilZ  - g_player.z) * g_projScale / cb.z);
        s.bot0 = ((float)SCREEN_H * 0.5f) - ((sec->floorZ - g_player.z) * g_projScale / ca.z);
        s.bot1 = ((float)SCREEN_H * 0.5f) - ((sec->floorZ - g_player.z) * g_projScale / cb.z);

        sortWallSpanEnds(&s.sx0, &s.sx1, &s.top0, &s.top1, &s.bot0, &s.bot1);

        if (s.sx1 < 0.0f || s.sx0 >= (float)SCREEN_W) {
            continue;
        }

        s.nearDepth = (ca.z < cb.z) ? ca.z : cb.z;
        s.col = w->wallColor;

        if (i & 1) {
            if (s.col > 4) s.col -= 4;
        }

        if (spanCount < RC3D_MAX_WALL_SPANS) {
            spans[spanCount++] = s;
        }
    }

    /* front to back */
    for (int a = 0; a < spanCount - 1; a++) {
        for (int b = a + 1; b < spanCount; b++) {
            if (spans[a].nearDepth > spans[b].nearDepth) {
                WallSpan t = spans[a];
                spans[a] = spans[b];
                spans[b] = t;
            }
        }
    }

    for (int i = 0; i < spanCount; i++) {
        const int wallX0 = clampi((int)ceilf(spans[i].sx0), 0, SCREEN_W - 1);
        const int wallX1 = clampi((int)floorf(spans[i].sx1), 0, SCREEN_W - 1);

        if (wallX1 < wallX0) {
            continue;
        }

        for (int r = 0; r < visibleCount; r++) {
            const int drawX0 = (wallX0 > visible[r].x0) ? wallX0 : visible[r].x0;
            const int drawX1 = (wallX1 < visible[r].x1) ? wallX1 : visible[r].x1;

            if (drawX1 >= drawX0) {
                drawWallSpanProjectedClipped(
                    spans[i].sx0, spans[i].sx1,
                    spans[i].top0, spans[i].top1,
                    spans[i].bot0, spans[i].bot1,
                    drawX0, drawX1,
                    spans[i].col
                );
            }
        }

        subtractRangeFromVisible(visible, &visibleCount, wallX0, wallX1);

        if (visibleCount <= 0) {
            break;
        }
    }
}


static int miniOutCode(int x, int y, int rx0, int ry0, int rx1, int ry1)
{
    int code = 0;

    if (x < rx0) code |= MINI_OUT_LEFT;
    else if (x > rx1) code |= MINI_OUT_RIGHT;

    if (y < ry0) code |= MINI_OUT_TOP;
    else if (y > ry1) code |= MINI_OUT_BOTTOM;

    return code;
}

static int clipLineToRect(int *x0, int *y0, int *x1, int *y1,
                          int rx0, int ry0, int rx1, int ry1)
{
    int out0 = miniOutCode(*x0, *y0, rx0, ry0, rx1, ry1);
    int out1 = miniOutCode(*x1, *y1, rx0, ry0, rx1, ry1);

    for (;;) {
        if (!(out0 | out1)) {
            return 1;
        }

        if (out0 & out1) {
            return 0;
        }

        {
            int out = out0 ? out0 : out1;
            int x = 0;
            int y = 0;

            if (out & MINI_OUT_TOP) {
                if (*y1 == *y0) return 0;
                x = *x0 + (*x1 - *x0) * (ry0 - *y0) / (*y1 - *y0);
                y = ry0;
            }
            else if (out & MINI_OUT_BOTTOM) {
                if (*y1 == *y0) return 0;
                x = *x0 + (*x1 - *x0) * (ry1 - *y0) / (*y1 - *y0);
                y = ry1;
            }
            else if (out & MINI_OUT_RIGHT) {
                if (*x1 == *x0) return 0;
                y = *y0 + (*y1 - *y0) * (rx1 - *x0) / (*x1 - *x0);
                x = rx1;
            }
            else if (out & MINI_OUT_LEFT) {
                if (*x1 == *x0) return 0;
                y = *y0 + (*y1 - *y0) * (rx0 - *x0) / (*x1 - *x0);
                x = rx0;
            }

            if (out == out0) {
                *x0 = x;
                *y0 = y;
                out0 = miniOutCode(*x0, *y0, rx0, ry0, rx1, ry1);
            } else {
                *x1 = x;
                *y1 = y;
                out1 = miniOutCode(*x1, *y1, rx0, ry0, rx1, ry1);
            }
        }
    }
}

static void drawMiniMap(void)
{
    const RCSector *sec = &g_map->sectors[0];
    const int x0 = miniOriginX();
    const int y0 = miniOriginY();
    const int x1 = x0 + RC3D_MINIMAP_W - 1;
    const int y1 = y0 + RC3D_MINIMAP_H - 1;
    const int px = miniCenterX();
    const int py = miniCenterY();

    drawRect(x0 - 2, y0 - 2, RC3D_MINIMAP_W + 4, RC3D_MINIMAP_H + 4, 1);
    drawRect(x0, y0, RC3D_MINIMAP_W, RC3D_MINIMAP_H, 0);

    for (int i = 0; i < sec->wallCount; i++) {
        const RCWall *w = &g_map->walls[sec->firstWall + i];

        int lx0 = worldToMiniX(g_map->verts[w->v0].x);
        int ly0 = worldToMiniY(g_map->verts[w->v0].y);
        int lx1 = worldToMiniX(g_map->verts[w->v1].x);
        int ly1 = worldToMiniY(g_map->verts[w->v1].y);

        if (clipLineToRect(&lx0, &ly0, &lx1, &ly1, x0, y0, x1, y1)) {
            drawLine(lx0, ly0, lx1, ly1, 15);
        }
    }

    {
        int sx = px;
        int sy = py;
        int ex = px + (int)(g_player.forward.x * 12.0f);
        int ey = py + (int)(g_player.forward.y * 12.0f);

        if (clipLineToRect(&sx, &sy, &ex, &ey, x0, y0, x1, y1)) {
            drawLine(sx, sy, ex, ey, 31);
        }
    }

    {
        int sx = px;
        int sy = py;
        int ex = px + (int)(g_player.right.x * 10.0f);
        int ey = py + (int)(g_player.right.y * 10.0f);

        if (clipLineToRect(&sx, &sy, &ex, &ey, x0, y0, x1, y1)) {
            drawLine(sx, sy, ex, ey, 27);
        }
    }

    if (px >= x0 + 2 && px <= x1 - 2 &&
        py >= y0 + 2 && py <= y1 - 2) {
        drawRect(px - 2, py - 2, 5, 5, 48);
    }
}


static void drawCrosshair(void)
{
    const int cx = SCREEN_W / 2;
    const int cy = SCREEN_H / 2;

    drawLine(cx - 6, cy, cx + 6, cy, 15);
    drawLine(cx, cy - 6, cx, cy + 6, 15);
}

void rc3dInit(void)
{
    g_map = rc3dGetDemoMap();

    g_player.pos.x = 2.5f;
    g_player.pos.y = 2.5f;
    g_player.z     = 1.0f;
    g_player.angle = 0.0f;

    g_projScale = ((float)SCREEN_W * 0.5f) /
                  tanf((RC3D_FOV_DEG * 0.5f) * ((float)M_PI / 180.0f));

    rc3dRebuildView();
}

void rc3dUpdate(float dt, const uint8_t *keys, int mouseDx)
{
    Vec2 tryPos;
    Vec2 move;
    float turn = 0.0f;

    if (dt > 0.05f) dt = 0.05f;
    if (dt < 0.0f) dt = 0.0f;

    if (keys[SDL_SCANCODE_Q]) turn -= RC3D_TURN_SPEED * dt;
    if (keys[SDL_SCANCODE_E]) turn += RC3D_TURN_SPEED * dt;

    turn += (float)mouseDx * RC3D_MOUSE_SENS;

    g_player.angle += turn;
    rc3dRebuildView();

    move.x = 0.0f;
    move.y = 0.0f;

    if (keys[SDL_SCANCODE_W]) {
        move.x += g_player.forward.x * RC3D_MOVE_SPEED * dt;
        move.y += g_player.forward.y * RC3D_MOVE_SPEED * dt;
    }
    if (keys[SDL_SCANCODE_S]) {
        move.x -= g_player.forward.x * RC3D_MOVE_SPEED * dt;
        move.y -= g_player.forward.y * RC3D_MOVE_SPEED * dt;
    }
    if (keys[SDL_SCANCODE_A]) {
        move.x -= g_player.right.x * RC3D_STRAFE_SPEED * dt;
        move.y -= g_player.right.y * RC3D_STRAFE_SPEED * dt;
    }
    if (keys[SDL_SCANCODE_D]) {
        move.x += g_player.right.x * RC3D_STRAFE_SPEED * dt;
        move.y += g_player.right.y * RC3D_STRAFE_SPEED * dt;
    }

    tryPos = g_player.pos;
    tryPos.x += move.x;
    if (canStandAt(tryPos)) {
        g_player.pos.x = tryPos.x;
    }

    tryPos = g_player.pos;
    tryPos.y += move.y;
    if (canStandAt(tryPos)) {
        g_player.pos.y = tryPos.y;
    }
}

void rc3dRender(void)
{
    const RCSector *sec = &g_map->sectors[0];
    const int horizon = SCREEN_H / 2;

    clearScreen(sec->ceilColor);
    drawRect(0, horizon, SCREEN_W, SCREEN_H - horizon, sec->floorColor);

    drawSectorWalls(sec);

    drawCrosshair();
    drawMiniMap();

    drawText(8, 8,  "W/S move", 15);
    drawText(8, 16, "A/D turn", 15);
    drawText(8, 24, "Q/E strafe", 15);
}