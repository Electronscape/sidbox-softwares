// file: rc3d/rc3d_map.c
#include "rc3d_map.h"

static const RCVec2 g_demoVerts[] = {
    {  0.0f,  0.0f },  /* 0 */
    { 16.0f,  0.0f },  /* 1 */
    { 16.0f,  3.0f },  /* 2 */
    { 12.0f,  3.0f },  /* 3 */
    { 12.0f,  6.0f },  /* 4 */
    { 15.0f,  6.0f },  /* 5 */
    { 15.0f, 12.0f },  /* 6 */
    { 14.0f, 12.0f },  /* 7 */
    { 10.0f, 16.0f },  /* 8 */
    {  4.0f, 16.0f },  /* 9 */
    {  4.0f, 10.0f },  /* 10 */
    {  0.0f, 10.0f }   /* 11 */
};

static const RCWall g_demoWalls[] = {
    {  0,  1, -1, 79 },
    {  1,  2, -1, 79 },
    {  2,  3, -1, 79 },
    {  3,  4, -1, 79 },
    {  4,  5, -1, 79 },
    {  5,  6, -1, 79 },
    {  6,  7, -1, 79 },
    {  7,  8, -1, 79 },
    {  8,  9, -1, 79 },
    {  9, 10, -1, 79 },
    { 10, 11, -1, 79 },
    { 11,  0, -1, 79 }
};

static const RCSector g_demoSectors[] = {
    {
        .firstWall   = 0,
        .wallCount   = 12,
        .floorZ      = 0.0f,
        .ceilZ       = 2.8f,
        .floorColor  = 214,
        .ceilColor   = 173
    }
};

static const RCMap g_demoMap = {
    .verts       = g_demoVerts,
    .vertCount   = (int)(sizeof(g_demoVerts) / sizeof(g_demoVerts[0])),

    .walls       = g_demoWalls,
    .wallCount   = (int)(sizeof(g_demoWalls) / sizeof(g_demoWalls[0])),

    .sectors     = g_demoSectors,
    .sectorCount = (int)(sizeof(g_demoSectors) / sizeof(g_demoSectors[0]))
};

const RCMap *rc3dGetDemoMap(void)
{
    return &g_demoMap;
}