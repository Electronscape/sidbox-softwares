
#ifndef _GFX_LIB_TEST_H_
#define _GFX_LIB_TEST_H_

#include <stddef.h>
#include <stdint.h>


#define SCREEN_TEST 1

#if(SCREEN_TEST == 0)
#define ZOOM 1
#define SCREEN_W  480
#define SCREEN_H  320
#endif

#if(SCREEN_TEST == 1)
#define ZOOM 1
#define SCREEN_W  1900
#define SCREEN_H  1000
#endif

#if(SCREEN_TEST == 2)
#define ZOOM 1
#define SCREEN_W  1900/2
#define SCREEN_H  1000/2
#endif

#if(SCREEN_TEST == 3)
#define ZOOM 1
#define SCREEN_W  800
#define SCREEN_H  380
#endif



extern uint32_t clut[256];
extern uint8_t fb[];    // framebuffer (interal)
extern uint32_t pb[];   // the presented buffer for SDL2


#pragma pack(push, 1)
typedef struct {
    uint8_t  config;        // [0]

    uint16_t width_be;      // [1..2]  big-endian
    uint16_t height_be;     // [3..4]  big-endian
    uint32_t length_be;     // [5..8]  big-endian payload length

    uint8_t  reserved[7];   // [9..15] must be 0

    uint8_t  palette[1024]; // [16..1039] fixed 1024-byte palette
} ppb_t;
#pragma pack(pop)


#define FB_INDEX(x, y) (((x) * SCREEN_H) + (y))

void drawText(int x, int y, const char *text, uint8_t color);

void videoMemToScreen();// real basic clear screen
void clearScreen(uint8_t colIndex);
void putPixel(int32_t x, int32_t y, uint8_t colIndex);
void drawImage(int x, int y, int width, int height, uint8_t *img);

//void drawCircle(int x, int y, int radius, uint8_t col);
void drawDiamond(int x, int y, int radius, uint8_t col);
void drawLine(int x0, int y0, int x1, int y1, uint8_t colorIndex);
void drawLineDots(int x0, int y0, int x1, int y1, uint8_t colorIndex);
void drawLineGridDots(int x0, int y0, int x1, int y1, uint8_t colorIndex);
void drawCircle(int cx, int cy, int radius, uint8_t col);


void resetRand();

void drawRect(int x, int y, int w, int h, uint8_t col);
void drawRectDots(int x, int y, int w, int h, uint8_t col);
void drawRectL(int x, int y, int w, int h, uint8_t col);

int LoadPPB(const char *filename, uint8_t *img, int destWidth, int destHeight);

#endif
