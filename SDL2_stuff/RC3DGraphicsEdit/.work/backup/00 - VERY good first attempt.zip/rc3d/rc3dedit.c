#include "rc3dedit.h"

#include <SDL2/SDL.h>

#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "../gfx.h"
#include "rc3d_map.h"

#define RC3D_WALL_PORTAL   0x01
#define RC3D_WALL_UPPER    0x02
#define RC3D_WALL_MIDDLE   0x04
#define RC3D_WALL_LOWER    0x08
#define RC3D_WALL_SOLID    0x10

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define ED_MAX_VERTS            4096
#define ED_MAX_WALLS            4096
#define ED_MAX_SECTORS          512
#define ED_MAX_DRAFT_POINTS     128
#define ED_GRID_STEP            1.0f
#define ED_EPSILON              0.001f
#define ED_PICK_DIST_PX         10


#define ED_TEXT_COL             15
#define ED_UI_BG                16
#define ED_UI_BORDER            2
#define ED_GRID_MAJOR_COL       9
#define ED_GRID_MINOR_COL       6
#define ED_VERT_COL             31
#define ED_WALL_COL             2
#define ED_PORTAL_COL           27
#define ED_DRAFT_COL            29
#define ED_CURSOR_COL           14
#define ED_START_COL            15


typedef struct {
    float x;
    float y;
} EdVec2;

typedef struct {
    int v0;
    int v1;
    int neighbour;
    float openBottom;
    float openTop;
    uint8_t upperColor;
    uint8_t midColor;
    uint8_t lowerColor;
    uint8_t flags;
} EdWall;

typedef struct {
    int wallStart;
    int wallCount;
    int boundaryCount;
    float floorHeight;
    float ceilHeight;
    uint8_t floorColor;
    uint8_t ceilColor;
} EdSector;

typedef struct {
    EdVec2 verts[ED_MAX_VERTS];
    int vertCount;

    EdWall walls[ED_MAX_WALLS];
    int wallCount;

    EdSector sectors[ED_MAX_SECTORS];
    int sectorCount;

    int startSector;
    float startX;
    float startY;
    float startAngle;
} EditorMap;

typedef struct {
    float camX;
    float camY;
    float zoom;
    int draggingPan;
    int lastMouseX;
    int lastMouseY;

    int draftVertIndices[ED_MAX_DRAFT_POINTS];
    int draftCount;

    float sectorFloor;
    float sectorCeil;
    uint8_t sectorFloorColor;
    uint8_t sectorCeilColor;

    int hoverVert;
    int hoverWall;
    int hoverSector;

    int prevLeftDown;
    int prevRightDown;
    int prevMiddleDown;
    uint8_t prevKeys[SDL_NUM_SCANCODES];
} EditorState;

static EditorMap g_edMap;
static EditorState g_ed;

static float absf_local(float v)
{
    return (v < 0.0f) ? -v : v;
}

static int clampi_local(int v, int lo, int hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static float clampf_local(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static float snapf(float v)
{
    const float inv = 1.0f / ED_GRID_STEP;
    return roundf(v * inv) / inv;
}

static int keyPressedOnce(const uint8_t *keys, SDL_Scancode sc)
{
    return keys[sc] && !g_ed.prevKeys[sc];
}

static void screenToWorld(int sx, int sy, float *wx, float *wy)
{
    *wx = g_ed.camX + ((float)sx - (SCREEN_W * 0.5f)) / g_ed.zoom;
    *wy = g_ed.camY + ((float)sy - (SCREEN_H * 0.5f)) / g_ed.zoom;
}

static void worldToScreen(float wx, float wy, int *sx, int *sy)
{
    *sx = (int)lroundf((wx - g_ed.camX) * g_ed.zoom + (SCREEN_W * 0.5f));
    *sy = (int)lroundf((wy - g_ed.camY) * g_ed.zoom + (SCREEN_H * 0.5f));
}

static int addVertex(float x, float y)
{
    if (g_edMap.vertCount >= ED_MAX_VERTS) {
        return -1;
    }
    g_edMap.verts[g_edMap.vertCount].x = x;
    g_edMap.verts[g_edMap.vertCount].y = y;
    g_edMap.vertCount++;
    return g_edMap.vertCount - 1;
}

static int findVertexExact(float x, float y)
{
    for (int i = 0; i < g_edMap.vertCount; i++) {
        if (absf_local(g_edMap.verts[i].x - x) < ED_EPSILON &&
            absf_local(g_edMap.verts[i].y - y) < ED_EPSILON) {
            return i;
        }
    }
    return -1;
}

static int findOrAddVertex(float x, float y)
{
    const int idx = findVertexExact(x, y);
    if (idx >= 0) return idx;
    return addVertex(x, y);
}

static int pointInSector(float px, float py, int sectorIndex)
{
    const EdSector *sec = &g_edMap.sectors[sectorIndex];
    int inside = 0;

    for (int i = 0; i < sec->boundaryCount; i++) {
        const EdWall *w = &g_edMap.walls[sec->wallStart + i];
        const EdVec2 *a = &g_edMap.verts[w->v0];
        const EdVec2 *b = &g_edMap.verts[w->v1];

        const int condY = ((a->y > py) != (b->y > py));
        if (condY) {
            const float t = (py - a->y) / (b->y - a->y);
            const float xHit = a->x + ((b->x - a->x) * t);
            if (px < xHit) {
                inside ^= 1;
            }
        }
    }

    return inside;
}

static int findSectorForPoint(float x, float y)
{
    for (int i = 0; i < g_edMap.sectorCount; i++) {
        if (pointInSector(x, y, i)) {
            return i;
        }
    }
    return -1;
}

static float distPointSegSq(float px, float py, float ax, float ay, float bx, float by)
{
    const float abx = bx - ax;
    const float aby = by - ay;
    const float apx = px - ax;
    const float apy = py - ay;
    const float abLenSq = (abx * abx) + (aby * aby);

    if (abLenSq <= ED_EPSILON) {
        const float dx = px - ax;
        const float dy = py - ay;
        return (dx * dx) + (dy * dy);
    }

    float t = ((apx * abx) + (apy * aby)) / abLenSq;
    t = clampf_local(t, 0.0f, 1.0f);

    const float cx = ax + (abx * t);
    const float cy = ay + (aby * t);
    const float dx = px - cx;
    const float dy = py - cy;
    return (dx * dx) + (dy * dy);
}

static int findReversedWall(int v0, int v1)
{
    for (int i = 0; i < g_edMap.wallCount; i++) {
        if (g_edMap.walls[i].v0 == v1 && g_edMap.walls[i].v1 == v0) {
            return i;
        }
    }
    return -1;
}

static void setPortalPair(int wallA, int sectorA, int wallB, int sectorB)
{
    EdWall *a = &g_edMap.walls[wallA];
    EdWall *b = &g_edMap.walls[wallB];
    const EdSector *sa = &g_edMap.sectors[sectorA];
    const EdSector *sb = &g_edMap.sectors[sectorB];

    const float openBottom = (sa->floorHeight > sb->floorHeight) ? sa->floorHeight : sb->floorHeight;
    const float openTop    = (sa->ceilHeight  < sb->ceilHeight)  ? sa->ceilHeight  : sb->ceilHeight;

    a->neighbour = sectorB;
    b->neighbour = sectorA;

    a->openBottom = openBottom;
    a->openTop = openTop;
    b->openBottom = openBottom;
    b->openTop = openTop;

    a->upperColor = a->midColor;
    a->lowerColor = a->midColor;
    b->upperColor = b->midColor;
    b->lowerColor = b->midColor;

    a->flags = RC3D_WALL_PORTAL;
    b->flags = RC3D_WALL_PORTAL;

    if (sb->ceilHeight < sa->ceilHeight) a->flags |= RC3D_WALL_UPPER;
    if (sb->floorHeight > sa->floorHeight) a->flags |= RC3D_WALL_LOWER;
    if (sa->ceilHeight < sb->ceilHeight) b->flags |= RC3D_WALL_UPPER;
    if (sa->floorHeight > sb->floorHeight) b->flags |= RC3D_WALL_LOWER;

    if (openTop <= openBottom) {
        a->flags = RC3D_WALL_SOLID | RC3D_WALL_MIDDLE;
        b->flags = RC3D_WALL_SOLID | RC3D_WALL_MIDDLE;
        a->neighbour = -1;
        b->neighbour = -1;
        a->openBottom = 0.0f;
        a->openTop = 0.0f;
        b->openBottom = 0.0f;
        b->openTop = 0.0f;
    }
}

static void syncAllPortals(void)
{
    for (int wi = 0; wi < g_edMap.wallCount; wi++) {
        EdWall *w = &g_edMap.walls[wi];
        if (w->neighbour >= 0) {
            w->neighbour = -1;
            w->openBottom = 0.0f;
            w->openTop = 0.0f;
            w->flags = RC3D_WALL_SOLID | RC3D_WALL_MIDDLE;
        }
    }

    for (int s = 0; s < g_edMap.sectorCount; s++) {
        const EdSector *sec = &g_edMap.sectors[s];
        for (int i = 0; i < sec->boundaryCount; i++) {
            const int wi = sec->wallStart + i;
            EdWall *w = &g_edMap.walls[wi];
            const int other = findReversedWall(w->v0, w->v1);
            if (other >= 0 && other != wi) {
                int otherSector = -1;
                for (int ss = 0; ss < g_edMap.sectorCount; ss++) {
                    const EdSector *s2 = &g_edMap.sectors[ss];
                    if (other >= s2->wallStart && other < (s2->wallStart + s2->boundaryCount)) {
                        otherSector = ss;
                        break;
                    }
                }
                if (otherSector >= 0) {
                    setPortalPair(wi, s, other, otherSector);
                }
            }
        }
    }
}

static void clearDraft(void)
{
    g_ed.draftCount = 0;
}

static void beginNewMap(void)
{
    memset(&g_edMap, 0, sizeof(g_edMap));
    g_edMap.startSector = 0;
    g_edMap.startX = 0.0f;
    g_edMap.startY = 0.0f;
    g_edMap.startAngle = 0.0f;

    g_ed.camX = 0.0f;
    g_ed.camY = 0.0f;
    g_ed.zoom = 32.0f;

    g_ed.draggingPan = 0;
    g_ed.lastMouseX = 0;
    g_ed.lastMouseY = 0;
    g_ed.hoverVert = -1;
    g_ed.hoverWall = -1;
    g_ed.hoverSector = -1;

    g_ed.sectorFloor = 0.0f;
    g_ed.sectorCeil = 2.0f;
    g_ed.sectorFloorColor = 173;
    g_ed.sectorCeilColor = 79;

    clearDraft();
    memset(g_ed.prevKeys, 0, sizeof(g_ed.prevKeys));
    g_ed.prevLeftDown = 0;
    g_ed.prevRightDown = 0;
    g_ed.prevMiddleDown = 0;
}

static int saveTextMap(const char *path)
{
    FILE *f = fopen(path, "w");
    if (!f) return 0;

    fprintf(f, "MAPEDIT1\n");
    fprintf(f, "START %.6f %.6f %.6f %d\n",
            g_edMap.startX, g_edMap.startY, g_edMap.startAngle, g_edMap.startSector);

    fprintf(f, "VERTS %d\n", g_edMap.vertCount);
    for (int i = 0; i < g_edMap.vertCount; i++) {
        fprintf(f, "%.6f %.6f\n", g_edMap.verts[i].x, g_edMap.verts[i].y);
    }

    fprintf(f, "WALLS %d\n", g_edMap.wallCount);
    for (int i = 0; i < g_edMap.wallCount; i++) {
        const EdWall *w = &g_edMap.walls[i];
        fprintf(f, "%d %d %d %.6f %.6f %u %u %u %u\n",
                w->v0, w->v1, w->neighbour,
                w->openBottom, w->openTop,
                (unsigned)w->upperColor,
                (unsigned)w->midColor,
                (unsigned)w->lowerColor,
                (unsigned)w->flags);
    }

    fprintf(f, "SECTORS %d\n", g_edMap.sectorCount);
    for (int i = 0; i < g_edMap.sectorCount; i++) {
        const EdSector *s = &g_edMap.sectors[i];
        fprintf(f, "%d %d %d %.6f %.6f %u %u\n",
                s->wallStart, s->wallCount, s->boundaryCount,
                s->floorHeight, s->ceilHeight,
                (unsigned)s->floorColor,
                (unsigned)s->ceilColor);
    }

    fclose(f);
    return 1;
}

static int loadTextMap(const char *path)
{
    FILE *f = fopen(path, "r");
    char tag[64];

    if (!f) return 0;
    beginNewMap();

    if (fscanf(f, "%63s", tag) != 1 || strcmp(tag, "MAPEDIT1") != 0) {
        fclose(f);
        return 0;
    }

    if (fscanf(f, "%63s", tag) != 1 || strcmp(tag, "START") != 0) {
        fclose(f);
        return 0;
    }
    fscanf(f, "%f %f %f %d",
           &g_edMap.startX, &g_edMap.startY, &g_edMap.startAngle, &g_edMap.startSector);

    int count = 0;

    if (fscanf(f, "%63s %d", tag, &count) != 2 || strcmp(tag, "VERTS") != 0) {
        fclose(f);
        return 0;
    }
    if (count > ED_MAX_VERTS) {
        fclose(f);
        return 0;
    }
    g_edMap.vertCount = count;
    for (int i = 0; i < count; i++) {
        fscanf(f, "%f %f", &g_edMap.verts[i].x, &g_edMap.verts[i].y);
    }

    if (fscanf(f, "%63s %d", tag, &count) != 2 || strcmp(tag, "WALLS") != 0) {
        fclose(f);
        return 0;
    }
    if (count > ED_MAX_WALLS) {
        fclose(f);
        return 0;
    }
    g_edMap.wallCount = count;
    for (int i = 0; i < count; i++) {
        unsigned uc, mc, lc, flags;
        fscanf(f, "%d %d %d %f %f %u %u %u %u",
               &g_edMap.walls[i].v0,
               &g_edMap.walls[i].v1,
               &g_edMap.walls[i].neighbour,
               &g_edMap.walls[i].openBottom,
               &g_edMap.walls[i].openTop,
               &uc, &mc, &lc, &flags);
        g_edMap.walls[i].upperColor = (uint8_t)uc;
        g_edMap.walls[i].midColor   = (uint8_t)mc;
        g_edMap.walls[i].lowerColor = (uint8_t)lc;
        g_edMap.walls[i].flags      = (uint8_t)flags;
    }

    if (fscanf(f, "%63s %d", tag, &count) != 2 || strcmp(tag, "SECTORS") != 0) {
        fclose(f);
        return 0;
    }
    if (count > ED_MAX_SECTORS) {
        fclose(f);
        return 0;
    }
    g_edMap.sectorCount = count;
    for (int i = 0; i < count; i++) {
        unsigned fc, cc;
        fscanf(f, "%d %d %d %f %f %u %u",
               &g_edMap.sectors[i].wallStart,
               &g_edMap.sectors[i].wallCount,
               &g_edMap.sectors[i].boundaryCount,
               &g_edMap.sectors[i].floorHeight,
               &g_edMap.sectors[i].ceilHeight,
               &fc, &cc);
        g_edMap.sectors[i].floorColor = (uint8_t)fc;
        g_edMap.sectors[i].ceilColor  = (uint8_t)cc;
    }

    fclose(f);
    clearDraft();
    return 1;
}

static int exportCStringMap(const char *path)
{
    FILE *f = fopen(path, "w");
    if (!f) return 0;

    fprintf(f, "#include \"rc3d_map.h\"\n\n");

    fprintf(f, "static const RC3D_Vec2 g_verts[] = {\n");
    for (int i = 0; i < g_edMap.vertCount; i++) {
        fprintf(f, "    { %.6ff, %.6ff },\n", g_edMap.verts[i].x, g_edMap.verts[i].y);
    }
    fprintf(f, "};\n\n");

    fprintf(f, "static const RC3D_Wall g_walls[] = {\n");
    for (int i = 0; i < g_edMap.wallCount; i++) {
        const EdWall *w = &g_edMap.walls[i];
        fprintf(f,
            "    { %d, %d, %d, %.6ff, %.6ff, %u, %u, %u, %u },\n",
            w->v0, w->v1, w->neighbour, w->openBottom, w->openTop,
            (unsigned)w->upperColor,
            (unsigned)w->midColor,
            (unsigned)w->lowerColor,
            (unsigned)w->flags);
    }
    fprintf(f, "};\n\n");

    fprintf(f, "static const RC3D_Sector g_sectors[] = {\n");
    for (int i = 0; i < g_edMap.sectorCount; i++) {
        const EdSector *s = &g_edMap.sectors[i];
        fprintf(f,
            "    { %d, %d, %d, %.6ff, %.6ff, %u, %u },\n",
            s->wallStart, s->wallCount, s->boundaryCount,
            s->floorHeight, s->ceilHeight,
            (unsigned)s->floorColor, (unsigned)s->ceilColor);
    }
    fprintf(f, "};\n\n");

    fprintf(f, "const RC3D_Map g_rc3dDemoMap = {\n");
    fprintf(f, "    g_verts,\n");
    fprintf(f, "    (int)(sizeof(g_verts) / sizeof(g_verts[0])),\n\n");
    fprintf(f, "    g_walls,\n");
    fprintf(f, "    (int)(sizeof(g_walls) / sizeof(g_walls[0])),\n\n");
    fprintf(f, "    g_sectors,\n");
    fprintf(f, "    (int)(sizeof(g_sectors) / sizeof(g_sectors[0])),\n\n");
    fprintf(f, "    %d,\n", g_edMap.startSector);
    fprintf(f, "    %.6ff,\n", g_edMap.startX);
    fprintf(f, "    %.6ff,\n", g_edMap.startY);
    fprintf(f, "    %.6ff\n", g_edMap.startAngle);
    fprintf(f, "};\n");

    fclose(f);
    return 1;
}

static void addDraftPoint(float wx, float wy)
{
    if (g_ed.draftCount >= ED_MAX_DRAFT_POINTS) return;

    wx = snapf(wx);
    wy = snapf(wy);

    const int v = findOrAddVertex(wx, wy);
    if (v < 0) return;

    if (g_ed.draftCount > 0 && g_ed.draftVertIndices[g_ed.draftCount - 1] == v) {
        return;
    }

    g_ed.draftVertIndices[g_ed.draftCount++] = v;
}

static void finalizeDraftSector(void)
{
    if (g_ed.draftCount < 3) return;
    if (g_edMap.sectorCount >= ED_MAX_SECTORS) return;
    if ((g_edMap.wallCount + g_ed.draftCount) > ED_MAX_WALLS) return;

    const int sectorIndex = g_edMap.sectorCount;
    const int wallStart = g_edMap.wallCount;

    for (int i = 0; i < g_ed.draftCount; i++) {
        const int v0 = g_ed.draftVertIndices[i];
        const int v1 = g_ed.draftVertIndices[(i + 1) % g_ed.draftCount];
        EdWall *w = &g_edMap.walls[g_edMap.wallCount++];

        w->v0 = v0;
        w->v1 = v1;
        w->neighbour = -1;
        w->openBottom = 0.0f;
        w->openTop = 0.0f;
        w->upperColor = 0;
        w->midColor = 10 + (sectorIndex % 22);
        w->lowerColor = 0;
        w->flags = RC3D_WALL_SOLID | RC3D_WALL_MIDDLE;
    }

    g_edMap.sectors[g_edMap.sectorCount].wallStart = wallStart;
    g_edMap.sectors[g_edMap.sectorCount].wallCount = g_ed.draftCount;
    g_edMap.sectors[g_edMap.sectorCount].boundaryCount = g_ed.draftCount;
    g_edMap.sectors[g_edMap.sectorCount].floorHeight = g_ed.sectorFloor;
    g_edMap.sectors[g_edMap.sectorCount].ceilHeight = g_ed.sectorCeil;
    g_edMap.sectors[g_edMap.sectorCount].floorColor = g_ed.sectorFloorColor;
    g_edMap.sectors[g_edMap.sectorCount].ceilColor = g_ed.sectorCeilColor;
    g_edMap.sectorCount++;

    syncAllPortals();
    clearDraft();
}

static void updateHover(float worldX, float worldY)
{
    g_ed.hoverVert = -1;
    g_ed.hoverWall = -1;
    g_ed.hoverSector = findSectorForPoint(worldX, worldY);

    float bestVertDistSq = 99999999.0f;
    for (int i = 0; i < g_edMap.vertCount; i++) {
        int sx, sy;
        worldToScreen(g_edMap.verts[i].x, g_edMap.verts[i].y, &sx, &sy);
        const int dx = sx - g_ed.lastMouseX;
        const int dy = sy - g_ed.lastMouseY;
        const float d2 = (float)(dx * dx + dy * dy);
        if (d2 < (float)(ED_PICK_DIST_PX * ED_PICK_DIST_PX) && d2 < bestVertDistSq) {
            bestVertDistSq = d2;
            g_ed.hoverVert = i;
        }
    }

    float bestWallDistSq = 99999999.0f;
    const float worldPick = (float)ED_PICK_DIST_PX / g_ed.zoom;
    const float worldPickSq = worldPick * worldPick;

    for (int i = 0; i < g_edMap.wallCount; i++) {
        const EdWall *w = &g_edMap.walls[i];
        const EdVec2 *a = &g_edMap.verts[w->v0];
        const EdVec2 *b = &g_edMap.verts[w->v1];
        const float d2 = distPointSegSq(worldX, worldY, a->x, a->y, b->x, b->y);
        if (d2 < worldPickSq && d2 < bestWallDistSq) {
            bestWallDistSq = d2;
            g_ed.hoverWall = i;
        }
    }
}
static void drawGrid(void)
{
    const float leftW   = g_ed.camX - (SCREEN_W * 0.5f) / g_ed.zoom;
    const float rightW  = g_ed.camX + (SCREEN_W * 0.5f) / g_ed.zoom;
    const float topW    = g_ed.camY - (SCREEN_H * 0.5f) / g_ed.zoom;
    const float bottomW = g_ed.camY + (SCREEN_H * 0.5f) / g_ed.zoom;

    const int x0 = (int)floorf(leftW);
    const int x1 = (int)ceilf(rightW);
    const int y0 = (int)floorf(topW);
    const int y1 = (int)ceilf(bottomW);

    clearScreen(16);

    for (int gx = x0; gx <= x1; gx++) {
        int sx0, sy0, sx1, sy1;
        worldToScreen((float)gx, topW, &sx0, &sy0);
        worldToScreen((float)gx, bottomW, &sx1, &sy1);
        drawLine(sx0, sy0, sx1, sy1,
                 (gx == 0) ? 31 : ((gx % 4 == 0) ? ED_GRID_MAJOR_COL : ED_GRID_MINOR_COL));
    }

    for (int gy = y0; gy <= y1; gy++) {
        int sx0, sy0, sx1, sy1;
        worldToScreen(leftW, (float)gy, &sx0, &sy0);
        worldToScreen(rightW, (float)gy, &sx1, &sy1);
        drawLine(sx0, sy0, sx1, sy1,
                 (gy == 0) ? 31 : ((gy % 4 == 0) ? ED_GRID_MAJOR_COL : ED_GRID_MINOR_COL));
    }
}

static void drawEditorUI(void)
{
    char buf[128];

    drawRect(6, 6, 770, 58, ED_UI_BG);
    drawLine(6, 6, 775, 6, ED_UI_BORDER);
    drawLine(6, 63, 775, 63, ED_UI_BORDER);
    drawLine(6, 6, 6, 63, ED_UI_BORDER);
    drawLine(775, 6, 775, 63, ED_UI_BORDER);

    snprintf(buf, sizeof(buf),
             "LMB add point  ENTER finish sector  BACKSPACE undo point  ESC cancel  MMB pan  wheel zoom");
    drawText(12, 12, buf, ED_TEXT_COL);

    snprintf(buf, sizeof(buf),
             "F/G floor %.2f  C/V ceil %.2f  J/K floorCol %u  N/M ceilCol %u",
             g_ed.sectorFloor, g_ed.sectorCeil,
             (unsigned)g_ed.sectorFloorColor,
             (unsigned)g_ed.sectorCeilColor);
    drawText(12, 24, buf, ED_TEXT_COL);

    snprintf(buf, sizeof(buf),
             "F2 save txt  F3 load txt  F5 export C  X set start  verts %d walls %d sectors %d",
             g_edMap.vertCount, g_edMap.wallCount, g_edMap.sectorCount);
    drawText(12, 36, buf, ED_TEXT_COL);

    snprintf(buf, sizeof(buf),
             "hoverV %d hoverW %d hoverS %d draft %d",
             g_ed.hoverVert, g_ed.hoverWall, g_ed.hoverSector, g_ed.draftCount);
    drawText(12, 48, buf, ED_TEXT_COL);
}

static void drawMapGeometry(void)
{
    for (int i = 0; i < g_edMap.wallCount; i++) {
        const EdWall *w = &g_edMap.walls[i];
        const EdVec2 *a = &g_edMap.verts[w->v0];
        const EdVec2 *b = &g_edMap.verts[w->v1];
        int x0, y0, x1, y1;

        worldToScreen(a->x, a->y, &x0, &y0);
        worldToScreen(b->x, b->y, &x1, &y1);

        uint8_t c = (w->neighbour >= 0) ? 27 : 2;

        if (w->flags & RC3D_WALL_MIDDLE) c = 14;
        if (w->flags & RC3D_WALL_PORTAL) c = 27;
        if (i == g_ed.hoverWall) c = 15;

        drawLine(x0, y0, x1, y1, c);
    }

    for (int i = 0; i < g_edMap.vertCount; i++) {
        int sx, sy;
        worldToScreen(g_edMap.verts[i].x, g_edMap.verts[i].y, &sx, &sy);
        drawRect(sx - 2, sy - 2, 5, 5, (i == g_ed.hoverVert) ? 15 : 31);
    }

    for (int i = 0; i < g_ed.draftCount; i++) {
        const EdVec2 *a = &g_edMap.verts[g_ed.draftVertIndices[i]];
        int sx, sy;
        worldToScreen(a->x, a->y, &sx, &sy);
        drawRect(sx - 2, sy - 2, 5, 5, 29);

        if (i > 0) {
            const EdVec2 *b = &g_edMap.verts[g_ed.draftVertIndices[i - 1]];
            int x0, y0, x1, y1;
            worldToScreen(b->x, b->y, &x0, &y0);
            worldToScreen(a->x, a->y, &x1, &y1);
            drawLine(x0, y0, x1, y1, 29);
        }
    }
}


static void drawStartMarker(void)
{
    int sx, sy, fx, fy;
    worldToScreen(g_edMap.startX, g_edMap.startY, &sx, &sy);
    fx = sx + (int)(cosf(g_edMap.startAngle) * 16.0f);
    fy = sy + (int)(sinf(g_edMap.startAngle) * 16.0f);
    drawRect(sx - 2, sy - 2, 5, 5, ED_START_COL);
    drawLine(sx, sy, fx, fy, ED_START_COL);
}

void rc3dEditInit(void)
{
    beginNewMap();
}
void rc3dEditUpdate(float dt,
                    const uint8_t *keys,
                    int mouseX,
                    int mouseY,
                    uint32_t mouseButtons,
                    int mouseWheelY)
{
    (void)dt;

    const int prevMouseX = g_ed.lastMouseX;
    const int prevMouseY = g_ed.lastMouseY;

    const int leftDown = (mouseButtons & SDL_BUTTON_LMASK) != 0;
    const int middleDown = (mouseButtons & SDL_BUTTON_MMASK) != 0;

    float worldX, worldY;
    screenToWorld(mouseX, mouseY, &worldX, &worldY);
    updateHover(worldX, worldY);

    if (mouseWheelY != 0) {
        const float beforeX = worldX;
        const float beforeY = worldY;

        g_ed.zoom *= (mouseWheelY > 0) ? 1.15f : (1.0f / 1.15f);
        g_ed.zoom = clampf_local(g_ed.zoom, 4.0f, 128.0f);

        {
            float afterX, afterY;
            screenToWorld(mouseX, mouseY, &afterX, &afterY);
            g_ed.camX += beforeX - afterX;
            g_ed.camY += beforeY - afterY;
        }
    }

    if (middleDown && !g_ed.prevMiddleDown) {
        g_ed.draggingPan = 1;
    }
    if (!middleDown) {
        g_ed.draggingPan = 0;
    }

    if (g_ed.draggingPan) {
        const int dx = mouseX - prevMouseX;
        const int dy = mouseY - prevMouseY;
        g_ed.camX -= (float)dx / g_ed.zoom;
        g_ed.camY -= (float)dy / g_ed.zoom;
    }

    if (leftDown && !g_ed.prevLeftDown) {
        addDraftPoint(worldX, worldY);
    }

    if (keyPressedOnce(keys, SDL_SCANCODE_BACKSPACE)) {
        if (g_ed.draftCount > 0) {
            g_ed.draftCount--;
        }
    }

    if (keyPressedOnce(keys, SDL_SCANCODE_ESCAPE)) {
        clearDraft();
    }

    if (keyPressedOnce(keys, SDL_SCANCODE_RETURN)) {
        finalizeDraftSector();
    }

    if (keyPressedOnce(keys, SDL_SCANCODE_F)) g_ed.sectorFloor -= 0.1f;
    if (keyPressedOnce(keys, SDL_SCANCODE_G)) g_ed.sectorFloor += 0.1f;
    if (keyPressedOnce(keys, SDL_SCANCODE_C)) g_ed.sectorCeil  -= 0.1f;
    if (keyPressedOnce(keys, SDL_SCANCODE_V)) g_ed.sectorCeil  += 0.1f;

    if (g_ed.sectorCeil < g_ed.sectorFloor + 0.1f) {
        g_ed.sectorCeil = g_ed.sectorFloor + 0.1f;
    }

    if (keyPressedOnce(keys, SDL_SCANCODE_J)) g_ed.sectorFloorColor--;
    if (keyPressedOnce(keys, SDL_SCANCODE_K)) g_ed.sectorFloorColor++;
    if (keyPressedOnce(keys, SDL_SCANCODE_N)) g_ed.sectorCeilColor--;
    if (keyPressedOnce(keys, SDL_SCANCODE_M)) g_ed.sectorCeilColor++;

    if (keyPressedOnce(keys, SDL_SCANCODE_X)) {
        const int s = findSectorForPoint(worldX, worldY);
        if (s >= 0) {
            g_edMap.startX = snapf(worldX);
            g_edMap.startY = snapf(worldY);
            g_edMap.startSector = s;
        }
    }

    if (keyPressedOnce(keys, SDL_SCANCODE_Q)) {
        g_edMap.startAngle -= 0.1f;
    }
    if (keyPressedOnce(keys, SDL_SCANCODE_E)) {
        g_edMap.startAngle += 0.1f;
    }

    if (keyPressedOnce(keys, SDL_SCANCODE_F2)) {
        saveTextMap("rc3d_map.txt");
    }
    if (keyPressedOnce(keys, SDL_SCANCODE_F3)) {
        loadTextMap("rc3d_map.txt");
    }
    if (keyPressedOnce(keys, SDL_SCANCODE_F5)) {
        exportCStringMap("rc3d_map_export.c");
    }

    memcpy(g_ed.prevKeys, keys, SDL_NUM_SCANCODES);
    g_ed.prevLeftDown = leftDown;
    g_ed.prevMiddleDown = middleDown;
    g_ed.prevRightDown = 0;

    g_ed.lastMouseX = mouseX;
    g_ed.lastMouseY = mouseY;
}

void rc3dEditRender(void)
{
    drawGrid();
    drawMapGeometry();
    drawStartMarker();
    drawEditorUI();
}
