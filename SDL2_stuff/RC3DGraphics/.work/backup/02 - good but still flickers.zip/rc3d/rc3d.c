// file: rc3d/rc3d.c
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#include <SDL2/SDL.h>

#include "../gfx.h"
#include "rc3d.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define RC3D_MAX_DRAWSEGS   4096
#define RC3D_MAX_RECURSE    16

#define RC3D_FOV_DEG        75.0f
#define RC3D_NEAR_Z         0.05f

#define RC3D_MOVE_SPEED     4.6f
#define RC3D_TURN_SPEED     2.4f
#define RC3D_MOUSE_SENS     0.0034f
#define RC3D_EYE_HEIGHT     1.6f

typedef struct
{
    float x;
    float y;
} Vec2;

typedef struct
{
    float x;
    float z;
} ViewPt;

typedef struct
{
    int v0;
    int v1;
    int neighbor;      // -1 = solid wall
    uint8_t color;

    // optional masked mid section on a portal wall
    // set midTop > midBottom to draw it
    float midBottom;
    float midTop;
    uint8_t midColor;
} Wall;

typedef struct
{
    int firstWall;
    int wallCount;

    float floorZ;
    float ceilZ;

    uint8_t wallColor;
    uint8_t floorColor;
    uint8_t ceilColor;
} Sector;

typedef struct
{
    float x;
    float y;
    float angle;
    int sector;
} Player;

typedef struct
{
    int enabled;
    float x0;
    float x1;
    float top0;
    float top1;
    float bot0;
    float bot1;
} ClipWindow;

typedef struct
{
    float sx0;
    float sx1;

    float top0;
    float top1;
    float bot0;
    float bot1;

    float depth;
    uint8_t color;

    ClipWindow clip;
} DrawSeg;

/* ========================================================================= */
/* demo world                                                                */
/* ========================================================================= */

enum
{
    SEC_START = 0,
    SEC_STEP  = 1,
    SEC_EAST  = 2,
    SEC_WIN   = 3
};

static const Vec2 g_vertices[] =
{
    /* sector 0: start room */
    {  0.0f,  0.0f },  // 0
    {  3.0f,  0.0f },  // 1
    {  7.0f,  0.0f },  // 2
    { 10.0f,  0.0f },  // 3
    { 10.0f,  2.0f },  // 4
    { 10.0f,  6.0f },  // 5
    { 10.0f,  8.0f },  // 6
    {  0.0f,  8.0f },  // 7

    /* sector 1: raised step corridor */
    { 16.0f,  2.0f },  // 8
    { 16.0f,  6.0f },  // 9

    /* sector 2: east room */
    { 16.0f,  0.0f },  // 10
    { 24.0f,  0.0f },  // 11
    { 24.0f,  8.0f },  // 12
    { 16.0f,  8.0f },  // 13

    /* sector 3: north window room */
    {  7.0f, -4.0f },  // 14
    {  3.0f, -4.0f }   // 15
};

static const Wall g_walls[] =
{
    /* ========================= sector 0 ========================= */
    { 0, 1, -1,       80, 0.0f, 0.0f, 0 },
    { 1, 2, SEC_WIN,  80, 0.0f, 0.0f, 0 },  // north "window portal"
    { 2, 3, -1,       80, 0.0f, 0.0f, 0 },
    { 3, 4, -1,       90, 0.0f, 0.0f, 0 },
    { 4, 5, SEC_STEP, 90, 0.0f, 0.0f, 0 },  // east portal (step)
    { 5, 6, -1,       90, 0.0f, 0.0f, 0 },
    { 6, 7, -1,      110, 0.0f, 0.0f, 0 },
    { 7, 0, -1,      100, 0.0f, 0.0f, 0 },

    /* ========================= sector 1 ========================= */
    { 4, 8, -1,       55, 0.0f, 0.0f, 0 },
    { 8, 9, SEC_EAST, 55, 0.0f, 0.0f, 0 },
    { 9, 5, -1,       55, 0.0f, 0.0f, 0 },
    { 5, 4, SEC_START,55, 0.0f, 0.0f, 0 },

    /* ========================= sector 2 ========================= */
    { 10, 11, -1,      46, 0.0f, 0.0f, 0 },
    { 11, 12, -1,      50, 0.0f, 0.0f, 0 },
    { 12, 13, -1,      58, 0.0f, 0.0f, 0 },
    { 13, 9, -1,       62, 0.0f, 0.0f, 0 },
    { 9, 8, SEC_STEP,  62, 0.0f, 0.0f, 0 },
    { 8, 10, -1,       62, 0.0f, 0.0f, 0 },

    /* ========================= sector 3 ========================= */
    { 1, 15, -1,       30, 0.0f, 0.0f, 0 },
    { 15,14, -1,       32, 0.0f, 0.0f, 0 },
    { 14, 2, -1,       34, 0.0f, 0.0f, 0 },
    { 2, 1, SEC_START, 36, 1.90f, 2.10f, 31 } // portal with a masked mid band
};

static const Sector g_sectors[] =
{
    /* firstWall, wallCount, floorZ, ceilZ, wall, floor, ceil */
    {  0, 8, 0.0f, 4.0f,  80, 173,  74 }, // start room
    {  8, 4, 1.0f, 4.0f,  55, 150,  74 }, // raised corridor / step
    { 12, 6, 0.0f, 4.0f,  50, 190,  76 }, // east room
    { 18, 4, 1.5f, 2.5f,  32, 120,  96 }  // low ceiling room = window slit
};

#define SECTOR_COUNT ((int)(sizeof(g_sectors) / sizeof(g_sectors[0])))
#define WALL_COUNT   ((int)(sizeof(g_walls)   / sizeof(g_walls[0])))
#define VERT_COUNT   ((int)(sizeof(g_vertices)/ sizeof(g_vertices[0])))

/* ========================================================================= */
/* globals                                                                   */
/* ========================================================================= */

static Player g_player;
static DrawSeg g_drawSegs[RC3D_MAX_DRAWSEGS];
static int g_drawSegCount = 0;
static int g_pathVisited[SECTOR_COUNT];

static float g_projScale = 0.0f;

/* ========================================================================= */
/* helpers                                                                   */
/* ========================================================================= */

static inline float rc3d_clampf(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static inline float rc3d_maxf(float a, float b)
{
    return (a > b) ? a : b;
}

static inline float rc3d_minf(float a, float b)
{
    return (a < b) ? a : b;
}

static inline float rc3d_lerp(float a, float b, float t)
{
    return a + ((b - a) * t);
}

static void worldToView(float wx, float wy, float *vx, float *vz)
{
    const float dx = wx - g_player.x;
    const float dy = wy - g_player.y;

    const float ca = cosf(g_player.angle);
    const float sa = sinf(g_player.angle);

    *vx = (-dx * sa) + (dy * ca);
    *vz = ( dx * ca) + (dy * sa);
}

static float projectX(float vx, float vz)
{
    return (SCREEN_W * 0.5f) + ((vx / vz) * g_projScale);
}

static float projectY(float worldZ, float viewZ, float eyeZ)
{
    return (SCREEN_H * 0.5f) - (((worldZ - eyeZ) / viewZ) * g_projScale);
}

static int pointInSector(int sectorIndex, float px, float py)
{
    const Sector *s = &g_sectors[sectorIndex];
    int inside = 0;

    for (int i = 0; i < s->wallCount; i++) {
        const Wall *w = &g_walls[s->firstWall + i];
        const Vec2 a = g_vertices[w->v0];
        const Vec2 b = g_vertices[w->v1];

        const int condY = ((a.y > py) != (b.y > py));
        if (condY) {
            const float xAtY = a.x + ((py - a.y) * (b.x - a.x) / (b.y - a.y));
            if (px < xAtY) {
                inside ^= 1;
            }
        }
    }

    return inside;
}

static int findContainingSector(float px, float py)
{
    for (int i = 0; i < SECTOR_COUNT; i++) {
        if (pointInSector(i, px, py)) {
            return i;
        }
    }
    return -1;
}

/* ========================================================================= */
/* clip window                                                               */
/* ========================================================================= */

static float clipTopAt(const ClipWindow *c, float x)
{
    if (!c->enabled) return 0.0f;
    if (fabsf(c->x1 - c->x0) < 0.0001f) return c->top0;

    {
        float t = (x - c->x0) / (c->x1 - c->x0);
        t = rc3d_clampf(t, 0.0f, 1.0f);
        return rc3d_lerp(c->top0, c->top1, t);
    }
}

static float clipBotAt(const ClipWindow *c, float x)
{
    if (!c->enabled) return (float)(SCREEN_H - 1);
    if (fabsf(c->x1 - c->x0) < 0.0001f) return c->bot0;

    {
        float t = (x - c->x0) / (c->x1 - c->x0);
        t = rc3d_clampf(t, 0.0f, 1.0f);
        return rc3d_lerp(c->bot0, c->bot1, t);
    }
}

static int intersectClipWindows(
    const ClipWindow *parent,
    float px0, float px1,
    float ptop0, float ptop1,
    float pbot0, float pbot1,
    ClipWindow *out)
{
    if (px1 < px0) {
        float tf;
        tf = px0;   px0   = px1;   px1   = tf;
        tf = ptop0; ptop0 = ptop1; ptop1 = tf;
        tf = pbot0; pbot0 = pbot1; pbot1 = tf;
    }

    if (!parent->enabled) {
        out->enabled = 1;
        out->x0 = px0;
        out->x1 = px1;
        out->top0 = ptop0;
        out->top1 = ptop1;
        out->bot0 = pbot0;
        out->bot1 = pbot1;
        return (out->bot0 > out->top0) || (out->bot1 > out->top1);
    }

    {
        const float ix0 = rc3d_maxf(px0, parent->x0);
        const float ix1 = rc3d_minf(px1, parent->x1);

        if (ix1 <= ix0) {
            return 0;
        }

        {
            const float pt0 = ptop0 + ((ptop1 - ptop0) * ((ix0 - px0) / (px1 - px0)));
            const float pt1 = ptop0 + ((ptop1 - ptop0) * ((ix1 - px0) / (px1 - px0)));
            const float pb0 = pbot0 + ((pbot1 - pbot0) * ((ix0 - px0) / (px1 - px0)));
            const float pb1 = pbot0 + ((pbot1 - pbot0) * ((ix1 - px0) / (px1 - px0)));

            const float top0 = rc3d_maxf(pt0, clipTopAt(parent, ix0));
            const float top1 = rc3d_maxf(pt1, clipTopAt(parent, ix1));
            const float bot0 = rc3d_minf(pb0, clipBotAt(parent, ix0));
            const float bot1 = rc3d_minf(pb1, clipBotAt(parent, ix1));

            out->enabled = 1;
            out->x0 = ix0;
            out->x1 = ix1;
            out->top0 = top0;
            out->top1 = top1;
            out->bot0 = bot0;
            out->bot1 = bot1;

            if ((bot0 <= top0) && (bot1 <= top1)) {
                return 0;
            }

            return 1;
        }
    }
}

/* ========================================================================= */
/* view-space line clipping                                                  */
/* ========================================================================= */

static int clipAgainstNear(ViewPt *a, ViewPt *b)
{
    const float fa = a->z - RC3D_NEAR_Z;
    const float fb = b->z - RC3D_NEAR_Z;

    if (fa >= 0.0f && fb >= 0.0f) return 1;
    if (fa <  0.0f && fb <  0.0f) return 0;

    {
        const float t = fa / (fa - fb);
        ViewPt p;
        p.x = a->x + ((b->x - a->x) * t);
        p.z = a->z + ((b->z - a->z) * t);

        if (fa < 0.0f) *a = p;
        else           *b = p;
    }

    return 1;
}

static int clipAgainstLeft(ViewPt *a, ViewPt *b, float leftSlope)
{
    const float fa = a->x - (a->z * leftSlope);
    const float fb = b->x - (b->z * leftSlope);

    if (fa >= 0.0f && fb >= 0.0f) return 1;
    if (fa <  0.0f && fb <  0.0f) return 0;

    {
        const float t = fa / (fa - fb);
        ViewPt p;
        p.x = a->x + ((b->x - a->x) * t);
        p.z = a->z + ((b->z - a->z) * t);

        if (fa < 0.0f) *a = p;
        else           *b = p;
    }

    return 1;
}

static int clipAgainstRight(ViewPt *a, ViewPt *b, float rightSlope)
{
    const float fa = (a->z * rightSlope) - a->x;
    const float fb = (b->z * rightSlope) - b->x;

    if (fa >= 0.0f && fb >= 0.0f) return 1;
    if (fa <  0.0f && fb <  0.0f) return 0;

    {
        const float t = fa / (fa - fb);
        ViewPt p;
        p.x = a->x + ((b->x - a->x) * t);
        p.z = a->z + ((b->z - a->z) * t);

        if (fa < 0.0f) *a = p;
        else           *b = p;
    }

    return 1;
}

static int clipWallToFrustum(ViewPt *a, ViewPt *b, float leftAngle, float rightAngle)
{
    const float leftSlope  = tanf(leftAngle);
    const float rightSlope = tanf(rightAngle);

    if (!clipAgainstNear(a, b))                 return 0;
    if (!clipAgainstLeft(a, b, leftSlope))      return 0;
    if (!clipAgainstRight(a, b, rightSlope))    return 0;

    return 1;
}

/* ========================================================================= */
/* draw seg collection                                                       */
/* ========================================================================= */

static void addDrawSeg(
    float sx0, float sx1,
    float top0, float top1,
    float bot0, float bot1,
    uint8_t color,
    float depth,
    const ClipWindow *clip)
{
    DrawSeg *d;

    if (g_drawSegCount >= RC3D_MAX_DRAWSEGS) return;

    if (sx1 < sx0) {
        float tf;
        tf = sx0;  sx0  = sx1;  sx1  = tf;
        tf = top0; top0 = top1; top1 = tf;
        tf = bot0; bot0 = bot1; bot1 = tf;
    }

    if (sx1 < 0.0f || sx0 > (float)(SCREEN_W - 1)) return;

    if (sx1 - sx0 < 0.001f) {
        sx1 = sx0 + 1.0f;
    }

    d = &g_drawSegs[g_drawSegCount++];
    d->sx0 = sx0;
    d->sx1 = sx1;
    d->top0 = top0;
    d->top1 = top1;
    d->bot0 = bot0;
    d->bot1 = bot1;
    d->color = color;
    d->depth = depth;
    d->clip = *clip;
}

static void addWallPiece(
    float sx0, float sx1,
    float z0, float z1,
    float topWorld,
    float botWorld,
    uint8_t color,
    const ClipWindow *clip)
{
    const float eyeZ = g_sectors[g_player.sector].floorZ + RC3D_EYE_HEIGHT;

    const float yt0 = projectY(topWorld, z0, eyeZ);
    const float yt1 = projectY(topWorld, z1, eyeZ);
    const float yb0 = projectY(botWorld, z0, eyeZ);
    const float yb1 = projectY(botWorld, z1, eyeZ);

    const float depth = (z0 + z1) * 0.5f;

    addDrawSeg(sx0, sx1, yt0, yt1, yb0, yb1, color, depth, clip);
}

/* ========================================================================= */
/* portal recursion                                                          */
/* ========================================================================= */

static void collectSector(int sectorIndex, float leftAngle, float rightAngle, const ClipWindow *clip, int depth)
{
    const Sector *sec;

    if (depth > RC3D_MAX_RECURSE) return;
    if (sectorIndex < 0 || sectorIndex >= SECTOR_COUNT) return;
    if (g_pathVisited[sectorIndex]) return;

    sec = &g_sectors[sectorIndex];
    g_pathVisited[sectorIndex] = 1;

    for (int i = 0; i < sec->wallCount; i++) {
        const Wall *w = &g_walls[sec->firstWall + i];
        const Vec2 a2 = g_vertices[w->v0];
        const Vec2 b2 = g_vertices[w->v1];

        ViewPt a, b;
        float sx0, sx1;
        float wallAng0, wallAng1;
        float portalLeft, portalRight;

        worldToView(a2.x, a2.y, &a.x, &a.z);
        worldToView(b2.x, b2.y, &b.x, &b.z);

        if (!clipWallToFrustum(&a, &b, leftAngle, rightAngle)) {
            continue;
        }

        sx0 = projectX(a.x, a.z);
        sx1 = projectX(b.x, b.z);

        if (fabsf(sx1 - sx0) < 0.001f) {
            continue;
        }

        wallAng0 = atan2f(a.x, a.z);
        wallAng1 = atan2f(b.x, b.z);

        portalLeft  = rc3d_maxf(leftAngle,  rc3d_minf(wallAng0, wallAng1));
        portalRight = rc3d_minf(rightAngle, rc3d_maxf(wallAng0, wallAng1));

        if (w->neighbor < 0) {
            addWallPiece(
                sx0, sx1,
                a.z, b.z,
                sec->ceilZ,
                sec->floorZ,
                w->color ? w->color : sec->wallColor,
                clip
            );
        } else {
            const Sector *ns = &g_sectors[w->neighbor];
            const float openBottom = rc3d_maxf(sec->floorZ, ns->floorZ);
            const float openTop    = rc3d_minf(sec->ceilZ,  ns->ceilZ);

            /* lower wall piece */
            if (openBottom > sec->floorZ) {
                addWallPiece(
                    sx0, sx1,
                    a.z, b.z,
                    openBottom,
                    sec->floorZ,
                    w->color ? w->color : sec->wallColor,
                    clip
                );
            }

            /* upper wall piece */
            if (sec->ceilZ > openTop) {
                addWallPiece(
                    sx0, sx1,
                    a.z, b.z,
                    sec->ceilZ,
                    openTop,
                    w->color ? w->color : sec->wallColor,
                    clip
                );
            }

            /* optional masked middle section */
            if (w->midTop > w->midBottom) {
                addWallPiece(
                    sx0, sx1,
                    a.z, b.z,
                    w->midTop,
                    w->midBottom,
                    w->midColor ? w->midColor : (w->color ? w->color : sec->wallColor),
                    clip
                );
            }

            /* recurse through portal opening */
            if ((openTop > openBottom) && !g_pathVisited[w->neighbor]) {
                ClipWindow childClip;

                const float ptop0 = projectY(openTop,    a.z, g_sectors[g_player.sector].floorZ + RC3D_EYE_HEIGHT);
                const float ptop1 = projectY(openTop,    b.z, g_sectors[g_player.sector].floorZ + RC3D_EYE_HEIGHT);
                const float pbot0 = projectY(openBottom, a.z, g_sectors[g_player.sector].floorZ + RC3D_EYE_HEIGHT);
                const float pbot1 = projectY(openBottom, b.z, g_sectors[g_player.sector].floorZ + RC3D_EYE_HEIGHT);

                if (intersectClipWindows(clip, sx0, sx1, ptop0, ptop1, pbot0, pbot1, &childClip)) {
                    collectSector(w->neighbor, portalLeft, portalRight, &childClip, depth + 1);
                }
            }
        }
    }

    g_pathVisited[sectorIndex] = 0;
}

/* ========================================================================= */
/* raster                                                                    */
/* ========================================================================= */

static int drawSegCompare(const void *a, const void *b)
{
    const DrawSeg *da = (const DrawSeg *)a;
    const DrawSeg *db = (const DrawSeg *)b;

    if (da->depth < db->depth) return 1;
    if (da->depth > db->depth) return -1;
    return 0;
}

static void drawVertical(int x, int y0, int y1, uint8_t color)
{
    if ((unsigned)x >= SCREEN_W) return;
    if (y0 < 0) y0 = 0;
    if (y1 >= SCREEN_H) y1 = SCREEN_H - 1;
    if (y1 < y0) return;

    for (int y = y0; y <= y1; y++) {
        fb[(y * SCREEN_W) + x] = color;
    }
}

static void rasterDrawSeg(const DrawSeg *d)
{
    int ix0 = (int)ceilf(d->sx0);
    int ix1 = (int)floorf(d->sx1);

    if (d->clip.enabled) {
        const int cx0 = (int)ceilf(d->clip.x0);
        const int cx1 = (int)floorf(d->clip.x1);

        if (ix0 < cx0) ix0 = cx0;
        if (ix1 > cx1) ix1 = cx1;
    }

    if (ix1 < 0 || ix0 >= SCREEN_W) return;
    if (ix0 < 0) ix0 = 0;
    if (ix1 >= SCREEN_W) ix1 = SCREEN_W - 1;
    if (ix1 < ix0) return;

    {
        const float dx = d->sx1 - d->sx0;
        const float invDx = (fabsf(dx) < 0.0001f) ? 0.0f : (1.0f / dx);

        for (int x = ix0; x <= ix1; x++) {
            float t;
            float yt;
            float yb;

            if (invDx == 0.0f) t = 0.0f;
            else               t = ((float)x - d->sx0) * invDx;

            t = rc3d_clampf(t, 0.0f, 1.0f);

            yt = rc3d_lerp(d->top0, d->top1, t);
            yb = rc3d_lerp(d->bot0, d->bot1, t);

            if (d->clip.enabled) {
                const float ct = clipTopAt(&d->clip, (float)x);
                const float cb = clipBotAt(&d->clip, (float)x);

                if (yt < ct) yt = ct;
                if (yb > cb) yb = cb;
            }

            drawVertical(x, (int)ceilf(yt), (int)floorf(yb), d->color);
        }
    }
}

/* ========================================================================= */
/* api                                                                       */
/* ========================================================================= */

void rc3dInit(void)
{
    g_projScale = (SCREEN_W * 0.5f) / tanf((RC3D_FOV_DEG * (float)M_PI / 180.0f) * 0.5f);

    g_player.x = 5.0f;
    g_player.y = 4.0f;
    g_player.angle = 0.0f;
    g_player.sector = SEC_START;
}

void rc3dShutdown(void)
{
    /* nothing yet */
}

void rc3dUpdate(float dt, const uint8_t *keys, int mouseDx)
{
    float moveForward = 0.0f;
    float moveSide    = 0.0f;

    const float ca = cosf(g_player.angle);
    const float sa = sinf(g_player.angle);

    float nx, ny;
    int foundSector;

    g_player.angle += (float)mouseDx * RC3D_MOUSE_SENS;

    if (keys[SDL_SCANCODE_LEFT])  g_player.angle -= RC3D_TURN_SPEED * dt;
    if (keys[SDL_SCANCODE_RIGHT]) g_player.angle += RC3D_TURN_SPEED * dt;

    if (keys[SDL_SCANCODE_W]) moveForward += 1.0f;
    if (keys[SDL_SCANCODE_S]) moveForward -= 1.0f;
    if (keys[SDL_SCANCODE_A]) moveSide    -= 1.0f;
    if (keys[SDL_SCANCODE_D]) moveSide    += 1.0f;

    {
        const float speed = RC3D_MOVE_SPEED * (keys[SDL_SCANCODE_LSHIFT] ? 1.8f : 1.0f);

        const float dx = ((ca * moveForward) + (-sa * moveSide)) * speed * dt;
        const float dy = ((sa * moveForward) + ( ca * moveSide)) * speed * dt;

        /* try full move */
        nx = g_player.x + dx;
        ny = g_player.y + dy;

        foundSector = findContainingSector(nx, ny);
        if (foundSector >= 0) {
            g_player.x = nx;
            g_player.y = ny;
            g_player.sector = foundSector;
            return;
        }

        /* try X only */
        nx = g_player.x + dx;
        ny = g_player.y;
        foundSector = findContainingSector(nx, ny);
        if (foundSector >= 0) {
            g_player.x = nx;
            g_player.sector = foundSector;
        }

        /* try Y only */
        nx = g_player.x;
        ny = g_player.y + dy;
        foundSector = findContainingSector(nx, ny);
        if (foundSector >= 0) {
            g_player.y = ny;
            g_player.sector = foundSector;
        }
    }
}

void rc3dRender(void)
{
    ClipWindow rootClip;
    const Sector *s;

    memset(g_pathVisited, 0, sizeof(g_pathVisited));
    g_drawSegCount = 0;

    s = &g_sectors[g_player.sector];

    /* cheap flat background */
    clearScreen(s->floorColor);
    drawRect(0, 0, SCREEN_W, SCREEN_H / 2, s->ceilColor);
    drawRect(0, SCREEN_H / 2, SCREEN_W, SCREEN_H - (SCREEN_H / 2), s->floorColor);

    rootClip.enabled = 0;
    rootClip.x0 = 0.0f;
    rootClip.x1 = 0.0f;
    rootClip.top0 = 0.0f;
    rootClip.top1 = 0.0f;
    rootClip.bot0 = 0.0f;
    rootClip.bot1 = 0.0f;

    collectSector(
        g_player.sector,
        -(RC3D_FOV_DEG * (float)M_PI / 180.0f) * 0.5f,
         (RC3D_FOV_DEG * (float)M_PI / 180.0f) * 0.5f,
        &rootClip,
        0
    );

    qsort(g_drawSegs, g_drawSegCount, sizeof(g_drawSegs[0]), drawSegCompare);

    for (int i = 0; i < g_drawSegCount; i++) {
        rasterDrawSeg(&g_drawSegs[i]);
    }

    /* tiny crosshair */
    drawRect((SCREEN_W / 2) - 1, (SCREEN_H / 2) - 6, 3, 13, 2);
    drawRect((SCREEN_W / 2) - 6, (SCREEN_H / 2) - 1, 13, 3, 2);

    /* debug */
    {
        char buf[128];
        snprintf(
            buf, sizeof(buf),
            "SEC:%d  POS:%.2f,%.2f  ANG:%.2f",
            g_player.sector,
            g_player.x, g_player.y,
            g_player.angle
        );
        drawText(8, 8, buf, 2);
    }
}