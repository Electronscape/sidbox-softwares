#include "rc3d.h"

#include <math.h>
#include <stdio.h>
#include <SDL2/SDL.h>

#include "gfx.h"
#include "rc3d_map.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define RC3D_FOV_DEG        70.0f
#define RC3D_TURN_SPEED     2.4f
#define RC3D_MOVE_SPEED     3.0f
#define RC3D_MOUSE_SENS     0.0035f
#define RC3D_EPSILON        0.0001f
#define RC3D_MAX_RAY_DIST   1000.0f
#define RC3D_MAX_PORTAL_STEPS 16
#define RC3D_EYE_Z          0.5f

typedef struct {
    float x;
    float y;
    float angle;
    int sector;
} RC3D_Player;

typedef struct {
    float t;
    int wallIndex;
    int hit;
} RC3D_WallHit;

static RC3D_Player g_player;
static const RC3D_Map *g_map = &g_rc3dDemoMap;

/* ------------------------------------------------------------------------- */
/* internal helpers                                                          */
/* ------------------------------------------------------------------------- */

static float wrapAngle(float a)
{
    while (a < -(float)M_PI) a += (float)(M_PI * 2.0f);
    while (a >  (float)M_PI) a -= (float)(M_PI * 2.0f);
    return a;
}

static float cross2(float ax, float ay, float bx, float by)
{
    return (ax * by) - (ay * bx);
}

static int clampi(int v, int lo, int hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static int pointInSector(float px, float py, int sectorIndex)
{
    const RC3D_Sector *sec = &g_map->sectors[sectorIndex];
    int inside = 0;

    for (int i = 0; i < sec->wallCount; i++) {
        const RC3D_Wall *w = &g_map->walls[sec->wallStart + i];
        const RC3D_Vec2 *a = &g_map->verts[w->v0];
        const RC3D_Vec2 *b = &g_map->verts[w->v1];

        const int condY = ((a->y > py) != (b->y > py));
        if (condY) {
            const float t = (py - a->y) / (b->y - a->y);
            const float xHit = a->x + ((b->x - a->x) * t);
            if (px < xHit) {
                inside ^= 1;
            }
        }
    }

    return inside;
}

static int findSectorForPoint(float x, float y)
{
    for (int i = 0; i < g_map->sectorCount; i++) {
        if (pointInSector(x, y, i)) {
            return i;
        }
    }
    return -1;
}

static int movePlayerWithSectorTest(float newX, float newY)
{
    const int newSector = findSectorForPoint(newX, newY);
    if (newSector < 0) {
        return 0;
    }

    g_player.x = newX;
    g_player.y = newY;
    g_player.sector = newSector;
    return 1;
}

static void drawVerticalColumn(int x, int y0, int y1, uint8_t col)
{
    if ((unsigned)x >= SCREEN_W) return;

    if (y0 < 0) y0 = 0;
    if (y1 >= SCREEN_H) y1 = SCREEN_H - 1;
    if (y0 > y1) return;

    for (int y = y0; y <= y1; y++) {
        putPixel(x, y, col);
    }
}

static int rayVsSegment(
    float rox, float roy,
    float rdx, float rdy,
    float ax, float ay,
    float bx, float by,
    float *outRayT
){
    const float sx = bx - ax;
    const float sy = by - ay;

    const float denom = cross2(rdx, rdy, sx, sy);
    if (fabsf(denom) < RC3D_EPSILON) {
        return 0;
    }

    {
        const float qpx = ax - rox;
        const float qpy = ay - roy;

        const float t = cross2(qpx, qpy, sx, sy) / denom;
        const float u = cross2(qpx, qpy, rdx, rdy) / denom;

        if (t < RC3D_EPSILON) return 0;
        if (u < 0.0f || u > 1.0f) return 0;

        *outRayT = t;
        return 1;
    }
}

static int projectHeightToScreenY(float worldZ, float correctedDist, float projPlane)
{
    const float dz = worldZ - RC3D_EYE_Z;
    const float sy = (SCREEN_H * 0.5f) - ((dz * projPlane) / correctedDist);
    return (int)sy;
}




static RC3D_WallHit findNearestWallInSector(
    int sectorIndex,
    float rox, float roy,
    float rdx, float rdy,
    int ignoreWallIndex
){
    RC3D_WallHit hit;
    hit.t = RC3D_MAX_RAY_DIST;
    hit.wallIndex = -1;
    hit.hit = 0;

    const RC3D_Sector *sec = &g_map->sectors[sectorIndex];

    for (int i = 0; i < sec->wallCount; i++) {
        const int wallIndex = sec->wallStart + i;
        const RC3D_Wall *w = &g_map->walls[wallIndex];
        const RC3D_Vec2 *a = &g_map->verts[w->v0];
        const RC3D_Vec2 *b = &g_map->verts[w->v1];
        float t;

        if (wallIndex == ignoreWallIndex) {
            continue;
        }

        if (!rayVsSegment(rox, roy, rdx, rdy, a->x, a->y, b->x, b->y, &t)) {
            continue;
        }

        if (t < hit.t) {
            hit.t = t;
            hit.wallIndex = wallIndex;
            hit.hit = 1;
        }
    }

    return hit;
}



static void drawBackground(void)
{
    const int half = SCREEN_H / 2;

    for (int y = 0; y < half; y++) {
        uint8_t c = (y < (half / 2)) ? 79 : 78;
        uint8_t *row = &fb[y * SCREEN_W];
        for (int x = 0; x < SCREEN_W; x++) {
            row[x] = c;
        }
    }

    for (int y = half; y < SCREEN_H; y++) {
        uint8_t c = (y & 8) ? 173 : 174;
        uint8_t *row = &fb[y * SCREEN_W];
        for (int x = 0; x < SCREEN_W; x++) {
            row[x] = c;
        }
    }
}

static void renderColumnPortalTrace(
    int sx,
    float rayAngle,
    float projPlane
){
    const float rdx = cosf(rayAngle);
    const float rdy = sinf(rayAngle);

    float rayOx = g_player.x;
    float rayOy = g_player.y;

    int currentSector = g_player.sector;
    int clipTop = 0;
    int clipBottom = SCREEN_H - 1;
    int ignoreWallIndex = -1;

    for (int step = 0; step < RC3D_MAX_PORTAL_STEPS; step++) {
        RC3D_WallHit hit;
        const RC3D_Wall *w;
        const RC3D_Sector *sec;
        float localT;
        float hitX, hitY;
        float fromPlayerDx, fromPlayerDy;
        float correctedDist;
        int ceilY;
        int floorY;

        if (currentSector < 0 || currentSector >= g_map->sectorCount) {
            break;
        }

        hit = findNearestWallInSector(currentSector, rayOx, rayOy, rdx, rdy, ignoreWallIndex);
        if (!hit.hit) {
            break;
        }

        w = &g_map->walls[hit.wallIndex];
        sec = &g_map->sectors[currentSector];
        localT = hit.t;

        hitX = rayOx + (rdx * localT);
        hitY = rayOy + (rdy * localT);

        fromPlayerDx = hitX - g_player.x;
        fromPlayerDy = hitY - g_player.y;

        correctedDist =
            (fromPlayerDx * cosf(g_player.angle)) +
            (fromPlayerDy * sinf(g_player.angle));

        if (correctedDist <= RC3D_EPSILON) {
            break;
        }

        ceilY  = projectHeightToScreenY(sec->ceilHeight, correctedDist, projPlane);
        floorY = projectHeightToScreenY(sec->floorHeight, correctedDist, projPlane);

        if (w->neighbour < 0) {
            int y0 = clampi(ceilY, clipTop, clipBottom);
            int y1 = clampi(floorY, clipTop, clipBottom);

            drawVerticalColumn(sx, y0, y1, w->color);

            if (y0 >= clipTop && y0 <= clipBottom) putPixel(sx, y0, 16);
            if (y1 >= clipTop && y1 <= clipBottom) putPixel(sx, y1, 16);
            break;
        } else {
            const RC3D_Sector *nextSec = &g_map->sectors[w->neighbour];
            const int nextCeilY  = projectHeightToScreenY(nextSec->ceilHeight, correctedDist, projPlane);
            const int nextFloorY = projectHeightToScreenY(nextSec->floorHeight, correctedDist, projPlane);

            if (nextCeilY > ceilY) {
                int y0 = clampi(ceilY, clipTop, clipBottom);
                int y1 = clampi(nextCeilY, clipTop, clipBottom);
                drawVerticalColumn(sx, y0, y1, 6);
            }

            if (nextFloorY < floorY) {
                int y0 = clampi(nextFloorY, clipTop, clipBottom);
                int y1 = clampi(floorY, clipTop, clipBottom);
                drawVerticalColumn(sx, y0, y1, 6);
            }

            if (nextCeilY > clipTop) {
                clipTop = nextCeilY;
            }
            if (nextFloorY < clipBottom) {
                clipBottom = nextFloorY;
            }

            if (clipTop > clipBottom) {
                break;
            }

            rayOx = hitX + (rdx * 0.001f);
            rayOy = hitY + (rdy * 0.001f);
            currentSector = w->neighbour;
            ignoreWallIndex = hit.wallIndex;
        }
    }
}

static void renderCurrentSectorColumns(void)
{
    const float halfFov = (RC3D_FOV_DEG * 0.5f) * (float)(M_PI / 180.0f);
    const float projPlane = (SCREEN_W * 0.5f) / tanf(halfFov);

    for (int sx = 0; sx < SCREEN_W; sx++) {
        const float camX = ((float)sx / (float)(SCREEN_W - 1)) * 2.0f - 1.0f;
        const float rayAngle = g_player.angle + (camX * halfFov);
        renderColumnPortalTrace(sx, rayAngle, projPlane);
    }
}



static void drawMiniMap(void)
{
    const int ox = 8;
    const int oy = 20;
    const int scale = 12;

    for (int s = 0; s < g_map->sectorCount; s++) {
        const RC3D_Sector *sec = &g_map->sectors[s];

        for (int i = 0; i < sec->wallCount; i++) {
            const RC3D_Wall *w = &g_map->walls[sec->wallStart + i];
            const RC3D_Vec2 *a = &g_map->verts[w->v0];
            const RC3D_Vec2 *b = &g_map->verts[w->v1];

            const int x0 = ox + (int)(a->x * scale);
            const int y0 = oy + (int)(a->y * scale);
            const int x1 = ox + (int)(b->x * scale);
            const int y1 = oy + (int)(b->y * scale);

            drawLine(x0, y0, x1, y1, (w->neighbour >= 0) ? 27 : 2);
        }
    }

    {
        const int px = ox + (int)(g_player.x * scale);
        const int py = oy + (int)(g_player.y * scale);
        const int fx = px + (int)(cosf(g_player.angle) * 8.0f);
        const int fy = py + (int)(sinf(g_player.angle) * 8.0f);

        drawRect(px - 1, py - 1, 3, 3, 15);
        drawLine(px, py, fx, fy, 31);
    }
}

/* ------------------------------------------------------------------------- */
/* public API                                                                */
/* ------------------------------------------------------------------------- */

void rc3dInit(void)
{
    g_player.x = g_map->startX;
    g_player.y = g_map->startY;
    g_player.angle = g_map->startAngle;
    g_player.sector = g_map->startSector;
}

void rc3dUpdate(float dt, const uint8_t *keys, int mouseDx)
{
    float moveX = 0.0f;
    float moveY = 0.0f;

    const float forwardX = cosf(g_player.angle);
    const float forwardY = sinf(g_player.angle);
    const float rightX   = -sinf(g_player.angle);
    const float rightY   =  cosf(g_player.angle);

    if (keys[SDL_SCANCODE_Q]) g_player.angle -= RC3D_TURN_SPEED * dt;
    if (keys[SDL_SCANCODE_E]) g_player.angle += RC3D_TURN_SPEED * dt;

    g_player.angle += (float)mouseDx * RC3D_MOUSE_SENS;
    g_player.angle = wrapAngle(g_player.angle);

    if (keys[SDL_SCANCODE_W]) {
        moveX += forwardX;
        moveY += forwardY;
    }
    if (keys[SDL_SCANCODE_S]) {
        moveX -= forwardX;
        moveY -= forwardY;
    }
    if (keys[SDL_SCANCODE_A]) {
        moveX -= rightX;
        moveY -= rightY;
    }
    if (keys[SDL_SCANCODE_D]) {
        moveX += rightX;
        moveY += rightY;
    }

    if ((moveX != 0.0f) || (moveY != 0.0f)) {
        const float len = sqrtf((moveX * moveX) + (moveY * moveY));
        const float step = RC3D_MOVE_SPEED * dt;

        moveX = (moveX / len) * step;
        moveY = (moveY / len) * step;

        if (!movePlayerWithSectorTest(g_player.x + moveX, g_player.y + moveY)) {
            if (!movePlayerWithSectorTest(g_player.x + moveX, g_player.y)) {
                movePlayerWithSectorTest(g_player.x, g_player.y + moveY);
            }
        }
    }
}

void rc3dRender(void)
{
    drawBackground();
    renderCurrentSectorColumns();
    drawMiniMap();

    {
        char buf[64];
        snprintf(buf, sizeof(buf), "SECTOR %d", g_player.sector);
        drawText(8, 8, buf, 15);
    }
}