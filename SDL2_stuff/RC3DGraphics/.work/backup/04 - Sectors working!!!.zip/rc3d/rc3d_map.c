#include "rc3d_map.h"

/*
    Expanded non-box sector test

    Sector 0:
        irregular 8-sided hub

              sector 3
          +----------------+
          |                |
          |                |
          +---- portal ----+
               \        /
                \  s0  /
                 \    /
                  ----

    Sector 1:
        below sector 0 through the bottom portal

    Sector 2:
        further below / after sector 1

    Shared portals:
        s0 <-> s1 : (9,10) -> (3,10) and reverse
        s1 <-> s2 : (10,22) -> (2,22) and reverse
        s0 <-> s3 : (3,0) -> (9,0) and reverse
*/

static const RC3D_Vec2 g_verts[] = {
    /* sector 0 */
    {  3.0f,  0.0f },   // 0
    {  9.0f,  0.0f },   // 1
    { 12.0f,  2.0f },   // 2
    { 12.0f,  8.0f },   // 3
    {  9.0f, 10.0f },   // 4
    {  3.0f, 10.0f },   // 5
    {  0.0f,  8.0f },   // 6
    {  0.0f,  2.0f },   // 7

    /* sector 1 */
    {  2.0f, 14.0f },   // 8
    { 10.0f, 14.0f },   // 9
    { 12.0f, 18.0f },   // 10
    { 10.0f, 22.0f },   // 11
    {  2.0f, 22.0f },   // 12
    {  0.0f, 18.0f }    // 13

    ,
    /* sector 2 */
    {  1.0f, 26.0f },   // 14
    { 11.0f, 26.0f },   // 15
    { 13.0f, 30.0f },   // 16
    {  9.0f, 35.0f },   // 17
    {  3.0f, 35.0f },   // 18
    { -1.0f, 30.0f }    // 19

    ,
    /* sector 3 */
    {  2.0f, -8.0f },   // 20
    { 10.0f, -8.0f },   // 21
    { 12.0f, -4.0f },   // 22
    {  0.0f, -4.0f }    // 23
};

static const RC3D_Wall g_walls[] = {
    /* ------------------------------------------------------------------ */
    /* sector 0 : irregular octagon                                       */
    /* clockwise                                                          */
    /* ------------------------------------------------------------------ */
    { 0, 1,  3,  0 },   // portal to sector 3
    { 1, 2, -1, 10 },   // upper-right angle
    { 2, 3, -1, 11 },   // right
    { 3, 4, -1, 12 },   // lower-right angle
    { 4, 5,  1,  0 },   // portal to sector 1
    { 5, 6, -1, 12 },   // lower-left angle
    { 6, 7, -1, 11 },   // left
    { 7, 0, -1, 10 },   // upper-left angle

    /* ------------------------------------------------------------------ */
    /* sector 1 : angled lower room                                       */
    /* clockwise                                                          */
    /* ------------------------------------------------------------------ */
    { 5, 4,  0,  0 },   // portal back to sector 0
    { 4, 9, -1, 13 },   // upper-right connector
    { 9,10, -1, 14 },   // upper-right angle
    {10,11, -1, 15 },   // lower-right angle
    {11,12,  2,  0 },   // portal to sector 2
    {12,13, -1, 15 },   // lower-left angle
    {13, 8, -1, 14 },   // upper-left angle
    { 8, 5, -1, 13 },   // upper-left connector

    /* ------------------------------------------------------------------ */
    /* sector 2 : further lower room                                      */
    /* clockwise                                                          */
    /* ------------------------------------------------------------------ */
    {12,11,  1,  0 },   // portal back to sector 1
    {11,15, -1, 27 },   // upper-right connector
    {15,16, -1, 28 },   // upper-right angle
    {16,17, -1, 29 },   // lower-right angle
    {17,18, -1, 31 },   // bottom
    {18,19, -1, 29 },   // lower-left angle
    {19,14, -1, 28 },   // upper-left angle
    {14,12, -1, 27 },   // upper-left connector

    /* ------------------------------------------------------------------ */
    /* sector 3 : upper room above sector 0                               */
    /* clockwise                                                          */
    /* ------------------------------------------------------------------ */
    { 1, 0,  0,  0 },   // portal back to sector 0
    { 0,23, -1, 20 },   // lower-left connector
    {23,20, -1, 21 },   // left
    {20,21, -1, 22 },   // top
    {21,22, -1, 21 },   // right
    {22, 1, -1, 20 }    // lower-right connector
};

static const RC3D_Sector g_sectors[] = {
    {  0, 8,  0.0f, 1.0f },   // sector 0
    {  8, 8,  0.1f, 0.8f },   // sector 1
    { 16, 8,  0.2f, 0.7f },   // sector 2
    { 24, 6, -0.1f, 1.1f }    // sector 3
};

const RC3D_Map g_rc3dDemoMap = {
    g_verts,
    (int)(sizeof(g_verts) / sizeof(g_verts[0])),

    g_walls,
    (int)(sizeof(g_walls) / sizeof(g_walls[0])),

    g_sectors,
    (int)(sizeof(g_sectors) / sizeof(g_sectors[0])),

    0,          // start sector
    6.0f,       // startX
    5.0f,       // startY
    1.5707963f  // startAngle
};