#ifndef RC3D_MAP_H
#define RC3D_MAP_H

#include <stdint.h>

typedef struct {
    float x;
    float y;
} RC3D_Vec2;

typedef struct {
    int v0;
    int v1;
    int neighbour;     // -1 = solid wall, >=0 = adjoining sector
    uint8_t color;
} RC3D_Wall;

typedef struct {
    int wallStart;
    int wallCount;
    float floorHeight;
    float ceilHeight;
} RC3D_Sector;

typedef struct {
    const RC3D_Vec2  *verts;
    int               vertCount;

    const RC3D_Wall  *walls;
    int               wallCount;

    const RC3D_Sector *sectors;
    int                sectorCount;

    int startSector;
    float startX;
    float startY;
    float startAngle;
} RC3D_Map;

extern const RC3D_Map g_rc3dDemoMap;

#endif