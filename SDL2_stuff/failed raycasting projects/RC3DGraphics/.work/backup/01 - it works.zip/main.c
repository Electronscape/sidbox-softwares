#include <SDL2/SDL.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>

#include "gfx.h"

/* Define various vision related constants */
#define EyeHeight  6.0f
#define DuckHeight 2.5f
#define HeadMargin 1.0f
#define KneeHeight 2.0f
#define hfov (0.73f * SCREEN_H)
#define vfov (0.2f  * SCREEN_H)

#define TURN_SPEED        0.58f
#define LOOK_SPEED        1.30f
#define MOVE_SPEED        6.0f
#define GRAVITY          28.0f
#define JUMP_SPEED        8.5f

#define FPS        60
#define A_FPS_MS   (1000 / FPS)

/* ------------------------------------------------------------------------- */
/* original code data structures                                             */
/* ------------------------------------------------------------------------- */

static struct sector
{
    float floor, ceil;
    struct xy { float x,y; } *vertex;
    signed char *neighbors;
    unsigned npoints;
} *sectors = NULL;

static unsigned NumSectors = 0;

static struct player
{
    struct xyz { float x,y,z; } where,
                                velocity;
    float angle, anglesin, anglecos, yaw;
    unsigned sector;
} player;

/* ------------------------------------------------------------------------- */
/* original macros                                                           */
/* ------------------------------------------------------------------------- */

#define min(a,b)             (((a) < (b)) ? (a) : (b))
#define max(a,b)             (((a) > (b)) ? (a) : (b))
#define clamp(a, mi,ma)      min(max(a,mi),ma)
#define vxs(x0,y0, x1,y1)    ((x0)*(y1) - (x1)*(y0))
#define Overlap(a0,a1,b0,b1) (min(a0,a1) <= max(b0,b1) && min(b0,b1) <= max(a0,a1))
#define IntersectBox(x0,y0, x1,y1, x2,y2, x3,y3) (Overlap(x0,x1,x2,x3) && Overlap(y0,y1,y2,y3))
#define PointSide(px,py, x0,y0, x1,y1) vxs((x1)-(x0), (y1)-(y0), (px)-(x0), (py)-(y0))
#define Intersect(x1,y1, x2,y2, x3,y3, x4,y4) ((struct xy) { \
    vxs(vxs(x1,y1, x2,y2), (x1)-(x2), vxs(x3,y3, x4,y4), (x3)-(x4)) / vxs((x1)-(x2), (y1)-(y2), (x3)-(x4), (y3)-(y4)), \
    vxs(vxs(x1,y1, x2,y2), (y1)-(y2), vxs(x3,y3, x4,y4), (y3)-(y4)) / vxs((x1)-(x2), (y1)-(y2), (x3)-(x4), (y3)-(y4)) })

/* ------------------------------------------------------------------------- */
/* basic CLUT choices                                                        */
/* ------------------------------------------------------------------------- */

#define COL_CEIL_TOP      17
#define COL_CEIL_MID      18
#define COL_FLOOR_TOP     72
#define COL_FLOOR_MID     73
#define COL_WALL_NEAR     26
#define COL_WALL_FAR      255
#define COL_LOWER_NEAR    48
#define COL_LOWER_FAR     31

static inline uint8_t shadeRange(uint8_t nearCol, uint8_t farCol, int z, int zmax)
{
    if (z < 0) z = 0;
    if (z > zmax) z = zmax;
    return (uint8_t)(nearCol + ((farCol - nearCol) * z) / zmax);
}

/* ------------------------------------------------------------------------- */
/* load/unload - same logic as original                                      */
/* ------------------------------------------------------------------------- */

static void LoadData(const char *filename)
{
    FILE* fp = fopen(filename, "rt");
    if(!fp) { perror(filename); exit(1); }

    char Buf[256], word[256], *ptr;
    struct xy* vert = NULL, v;
    int n, m, NumVertices = 0;

    while(fgets(Buf, sizeof Buf, fp))
        switch(sscanf(ptr = Buf, "%32s%n", word, &n) == 1 ? word[0] : '\0')
        {
            case 'v':
                for(sscanf(ptr += n, "%f%n", &v.y, &n);
                    sscanf(ptr += n, "%f%n", &v.x, &n) == 1; )
                {
                    vert = realloc(vert, ++NumVertices * sizeof(*vert));
                    vert[NumVertices-1] = v;
                }
                break;

            case 's':
            {
                sectors = realloc(sectors, ++NumSectors * sizeof(*sectors));
                struct sector* sect = &sectors[NumSectors-1];
                int* num = NULL;

                sscanf(ptr += n, "%f%f%n", &sect->floor,&sect->ceil, &n);

                for(m=0; sscanf(ptr += n, "%32s%n", word, &n) == 1 && word[0] != '#'; )
                {
                    num = realloc(num, ++m * sizeof(*num));
                    num[m-1] = word[0]=='x' ? -1 : atoi(word);
                }

                sect->npoints   = m /= 2;
                sect->neighbors = malloc((m  ) * sizeof(*sect->neighbors));
                sect->vertex    = malloc((m+1) * sizeof(*sect->vertex));

                for(n=0; n<m; ++n) sect->neighbors[n] = num[m + n];
                for(n=0; n<m; ++n) sect->vertex[n+1]  = vert[num[n]];
                sect->vertex[0] = sect->vertex[m];

                free(num);
                break;
            }

            case 'p':
            {
                float angle;
                sscanf(ptr += n, "%f %f %f %d", &v.x, &v.y, &angle,&n);
                player = (struct player) { {v.x, v.y, 0}, {0,0,0}, angle,0,0,0, (unsigned)n };
                player.where.z = sectors[player.sector].floor + EyeHeight;
                break;
            }
        }

    fclose(fp);
    free(vert);

    player.anglesin = sinf(player.angle);
    player.anglecos = cosf(player.angle);
}

static void UnloadData(void)
{
    for(unsigned a=0; a<NumSectors; ++a) free(sectors[a].vertex);
    for(unsigned a=0; a<NumSectors; ++a) free(sectors[a].neighbors);
    free(sectors);
    sectors    = NULL;
    NumSectors = 0;
}

/* ------------------------------------------------------------------------- */
/* adapted vline: same function, writes to gfx framebuffer                   */
/* ------------------------------------------------------------------------- */

static void vline(int x, int y1, int y2, uint8_t top, uint8_t middle, uint8_t bottom)
{
    if ((unsigned)x >= SCREEN_W) return;

    y1 = clamp(y1, 0, SCREEN_H - 1);
    y2 = clamp(y2, 0, SCREEN_H - 1);

    if (y2 < y1) return;

    if (y1 == y2) {
        fb[(y1 * SCREEN_W) + x] = middle;
        return;
    }

    fb[(y1 * SCREEN_W) + x] = top;

    for (int y = y1 + 1; y < y2; ++y) {
        fb[(y * SCREEN_W) + x] = middle;
    }

    fb[(y2 * SCREEN_W) + x] = bottom;
}

/* ------------------------------------------------------------------------- */
/* same movement code                                                        */
/* ------------------------------------------------------------------------- */

static void MovePlayer(float dx, float dy)
{
    float px = player.where.x, py = player.where.y;
    const struct sector* const sect = &sectors[player.sector];
    const struct xy* const vert = sect->vertex;

    for(unsigned s = 0; s < sect->npoints; ++s)
        if(sect->neighbors[s] >= 0
        && IntersectBox(px,py, px+dx,py+dy, vert[s+0].x, vert[s+0].y, vert[s+1].x, vert[s+1].y)
        && PointSide(px+dx, py+dy, vert[s+0].x, vert[s+0].y, vert[s+1].x, vert[s+1].y) < 0)
        {
            player.sector = sect->neighbors[s];
            break;
        }

    player.where.x += dx;
    player.where.y += dy;
    player.anglesin = sinf(player.angle);
    player.anglecos = cosf(player.angle);
}

/* ------------------------------------------------------------------------- */
/* same renderer, only colour writes changed                                 */
/* ------------------------------------------------------------------------- */

static void DrawScreen(void)
{
    enum { MaxQueue = 32 };
    struct item { int sectorno,sx1,sx2; } queue[MaxQueue], *head=queue, *tail=queue;

    int ytop[SCREEN_W];
    int ybottom[SCREEN_W];
    int renderedsectors[NumSectors];

    for(unsigned x=0; x<SCREEN_W; ++x) {
        ytop[x] = 0;
        ybottom[x] = SCREEN_H-1;
    }

    for(unsigned n=0; n<NumSectors; ++n) renderedsectors[n] = 0;

    *head = (struct item) { (int)player.sector, 0, SCREEN_W-1 };
    if(++head == queue+MaxQueue) head = queue;

    do {
        const struct item now = *tail;
        if(++tail == queue+MaxQueue) tail = queue;

        if(renderedsectors[now.sectorno] & 0x21) continue;
        ++renderedsectors[now.sectorno];

        const struct sector* const sect = &sectors[now.sectorno];

        for(unsigned s = 0; s < sect->npoints; ++s)
        {
            float vx1 = sect->vertex[s+0].x - player.where.x, vy1 = sect->vertex[s+0].y - player.where.y;
            float vx2 = sect->vertex[s+1].x - player.where.x, vy2 = sect->vertex[s+1].y - player.where.y;

            float pcos = player.anglecos, psin = player.anglesin;
            float tx1 = vx1 * psin - vy1 * pcos,  tz1 = vx1 * pcos + vy1 * psin;
            float tx2 = vx2 * psin - vy2 * pcos,  tz2 = vx2 * pcos + vy2 * psin;

            if(tz1 <= 0 && tz2 <= 0) continue;

            if(tz1 <= 0 || tz2 <= 0)
            {
                float nearz = 1e-4f, farz = 5, nearside = 1e-5f, farside = 20.f;
                struct xy i1 = Intersect(tx1,tz1,tx2,tz2, -nearside,nearz, -farside,farz);
                struct xy i2 = Intersect(tx1,tz1,tx2,tz2,  nearside,nearz,  farside,farz);

                if(tz1 < nearz) { if(i1.y > 0) { tx1 = i1.x; tz1 = i1.y; } else { tx1 = i2.x; tz1 = i2.y; } }
                if(tz2 < nearz) { if(i1.y > 0) { tx2 = i1.x; tz2 = i1.y; } else { tx2 = i2.x; tz2 = i2.y; } }
            }

            float xscale1 = hfov / tz1, yscale1 = vfov / tz1;
            int x1 = SCREEN_W/2 - (int)(tx1 * xscale1);

            float xscale2 = hfov / tz2, yscale2 = vfov / tz2;
            int x2 = SCREEN_W/2 - (int)(tx2 * xscale2);

            if(x1 >= x2 || x2 < now.sx1 || x1 > now.sx2) continue;

            float yceil  = sect->ceil  - player.where.z;
            float yfloor = sect->floor - player.where.z;

            int neighbor = sect->neighbors[s];
            float nyceil=0, nyfloor=0;

            if(neighbor >= 0)
            {
                nyceil  = sectors[neighbor].ceil  - player.where.z;
                nyfloor = sectors[neighbor].floor - player.where.z;
            }

            #define Yaw(y,z) (y + z*player.yaw)

            int y1a  = SCREEN_H/2 - (int)(Yaw(yceil, tz1)  * yscale1);
            int y1b  = SCREEN_H/2 - (int)(Yaw(yfloor, tz1) * yscale1);
            int y2a  = SCREEN_H/2 - (int)(Yaw(yceil, tz2)  * yscale2);
            int y2b  = SCREEN_H/2 - (int)(Yaw(yfloor, tz2) * yscale2);

            int ny1a = SCREEN_H/2 - (int)(Yaw(nyceil, tz1)  * yscale1);
            int ny1b = SCREEN_H/2 - (int)(Yaw(nyfloor, tz1) * yscale1);
            int ny2a = SCREEN_H/2 - (int)(Yaw(nyceil, tz2)  * yscale2);
            int ny2b = SCREEN_H/2 - (int)(Yaw(nyfloor, tz2) * yscale2);

            int beginx = max(x1, now.sx1), endx = min(x2, now.sx2);

            for(int x = beginx; x <= endx; ++x)
            {
                int z = (int)((((x - x1) * (tz2-tz1) / (float)(x2-x1)) + tz1) * 8.0f);

                int ya  = (x - x1) * (y2a-y1a) / (x2-x1) + y1a;
                int cya = clamp(ya, ytop[x],ybottom[x]);

                int yb  = (x - x1) * (y2b-y1b) / (x2-x1) + y1b;
                int cyb = clamp(yb, ytop[x],ybottom[x]);

                vline(x, ytop[x], cya-1, COL_CEIL_TOP, COL_CEIL_MID, COL_CEIL_TOP);
                vline(x, cyb+1, ybottom[x], COL_FLOOR_TOP, COL_FLOOR_MID, COL_FLOOR_TOP);

                if(neighbor >= 0)
                {
                    int nya  = (x - x1) * (ny2a-ny1a) / (x2-x1) + ny1a;
                    int cnya = clamp(nya, ytop[x],ybottom[x]);

                    int nyb  = (x - x1) * (ny2b-ny1b) / (x2-x1) + ny1b;
                    int cnyb = clamp(nyb, ytop[x],ybottom[x]);

                    uint8_t r1 = shadeRange(COL_WALL_NEAR,  COL_WALL_FAR,  z, 255);
                    uint8_t r2 = shadeRange(COL_LOWER_NEAR, COL_LOWER_FAR, z, 255);

                    vline(x, cya, cnya-1, 0, x==x1||x==x2 ? 0 : r1, 0);
                    ytop[x] = clamp(max(cya, cnya), ytop[x], SCREEN_H-1);

                    vline(x, cnyb+1, cyb, 0, x==x1||x==x2 ? 0 : r2, 0);
                    ybottom[x] = clamp(min(cyb, cnyb), 0, ybottom[x]);
                }
                else
                {
                    uint8_t r = shadeRange(COL_WALL_NEAR, COL_WALL_FAR, z, 255);
                    vline(x, cya, cyb, 0, x==x1||x==x2 ? 0 : r, 0);
                }
            }

            if(neighbor >= 0 && endx >= beginx && (head+MaxQueue+1-tail)%MaxQueue)
            {
                *head = (struct item) { neighbor, beginx, endx };
                if(++head == queue+MaxQueue) head = queue;
            }
        }

        ++renderedsectors[now.sectorno];
    } while(head != tail);
}

/* ------------------------------------------------------------------------- */
/* your SDL2 setup code                                                      */
/* ------------------------------------------------------------------------- */

int tmr1;
SDL_Window *sdl_win;
SDL_Renderer *ren;
SDL_Texture *tex;
int running = 1;

int updateFPS() {
    static uint32_t fpsTimer = 0;
    static uint32_t lastFrameTime = 0;
    static int frameCount = 0;
    static int uncappedCount = 0;
    static int fps = 0;
    static int uncappedFPS = 0;

    uint32_t now = SDL_GetTicks();
    uncappedCount++;

    if (now - fpsTimer >= 1000) {
        fps = frameCount;
        uncappedFPS = uncappedCount;
        frameCount = 0;
        uncappedCount = 0;
        fpsTimer = now;
    }

    {
        char buf[64];
        sprintf(buf, "FPS: %d (Uncapped: %d)", fps, uncappedFPS);
        drawText(0, 1, buf, 16);
        drawText(2, 1, buf, 16);
        drawText(1, 0, buf, 16);
        drawText(1, 2, buf, 16);
        drawText(1, 1, buf, 15);
    }

    if (now - lastFrameTime >= A_FPS_MS) {
        lastFrameTime += A_FPS_MS;
        frameCount++;
        return 1;
    }

    return 0;
}

int BasicSDL2Setup(){
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }

    sdl_win = SDL_CreateWindow(
        "Portal Demo (SDL2)",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        SCREEN_W * ZOOM, SCREEN_H * ZOOM, 0
    );
    if (!sdl_win) {
        fprintf(stderr, "CreateWindow failed: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    ren = SDL_CreateRenderer(sdl_win, -1, SDL_RENDERER_ACCELERATED);
    if (!ren) {
        fprintf(stderr, "SDL_CreateRenderer failed: %s\n", SDL_GetError());
        SDL_DestroyWindow(sdl_win);
        SDL_Quit();
        return 1;
    }

    tex = SDL_CreateTexture(
        ren,
        SDL_PIXELFORMAT_ARGB8888,
        SDL_TEXTUREACCESS_STREAMING,
        SCREEN_W,
        SCREEN_H
    );
    if (!tex) {
        fprintf(stderr, "SDL_CreateTexture failed: %s\n", SDL_GetError());
        SDL_DestroyRenderer(ren);
        SDL_DestroyWindow(sdl_win);
        SDL_Quit();
        return 1;
    }

    return 0;
}

void EndSDL2Session(){
    SDL_DestroyTexture(tex);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(sdl_win);
    SDL_Quit();
}

void screenupdate(){
    videoMemToScreen();
    SDL_UpdateTexture(tex, NULL, pb, SCREEN_W * (int)sizeof(uint32_t));
    SDL_RenderClear(ren);
    SDL_RenderCopy(ren, tex, NULL, NULL);
    SDL_RenderPresent(ren);
}

/* ------------------------------------------------------------------------- */
/* adapted main: same original logic, SDL2 loop                             */
/* ------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
    const char *mapPath = "map-clear.txt";
    if (argc >= 2 && argv[1] && argv[1][0]) mapPath = argv[1];

    if (BasicSDL2Setup() != 0) {
        return 1;
    }

    LoadData(mapPath);

    SDL_SetRelativeMouseMode(SDL_TRUE);

    int wsad[4]={0,0,0,0}, ground=0, falling=1, moving=0, ducking=0;
    float yaw = 0.0f;

    uint32_t lastTicks = SDL_GetTicks();

    do
    {
        uint32_t nowTicks = SDL_GetTicks();
        float dt = (float)(nowTicks - lastTicks) / 1000.0f;
        lastTicks = nowTicks;

        if (dt > 0.05f) dt = 0.05f;


        SDL_Event ev;
        while(SDL_PollEvent(&ev))
        {
            switch(ev.type)
            {
                case SDL_QUIT:
                    running = 0;
                    break;

                case SDL_KEYDOWN:
                case SDL_KEYUP:
                    switch(ev.key.keysym.sym)
                    {
                        case SDLK_w: wsad[0] = ev.type==SDL_KEYDOWN; break;
                        case SDLK_s: wsad[1] = ev.type==SDL_KEYDOWN; break;
                        case SDLK_a: wsad[2] = ev.type==SDL_KEYDOWN; break;
                        case SDLK_d: wsad[3] = ev.type==SDL_KEYDOWN; break;
                        case SDLK_q: running = 0; break;

                        case SDLK_SPACE:
                            if(ev.type == SDL_KEYDOWN && ground) {
                                player.velocity.z = JUMP_SPEED;
                                falling = 1;
                            }
                            break;

                        case SDLK_LCTRL:
                        case SDLK_RCTRL:
                            ducking = ev.type==SDL_KEYDOWN;
                            falling = 1;
                            break;

                        default:
                            break;
                    }
                    break;
            }
        }

        int mx, my;
        SDL_GetRelativeMouseState(&mx, &my);

        player.angle += mx * TURN_SPEED * dt;
        yaw          = clamp(yaw + my * LOOK_SPEED * dt, -5.0f, 5.0f);
        player.yaw   = yaw - player.velocity.z * 0.05f * dt;

        MovePlayer(0,0);

        float eyeheight = ducking ? DuckHeight : EyeHeight;
        ground = !falling;

        if(falling)
        {
            player.velocity.z -= GRAVITY * dt;
            float nextz = player.where.z + player.velocity.z * dt;

            if(player.velocity.z < 0.0f && nextz < sectors[player.sector].floor + eyeheight)
            {
                player.where.z    = sectors[player.sector].floor + eyeheight;
                player.velocity.z = 0.0f;
                falling = 0;
                ground  = 1;
            }
            else if(player.velocity.z > 0.0f && nextz > sectors[player.sector].ceil)
            {
                player.velocity.z = 0.0f;
                falling = 1;
            }

            if(falling)
            {
                player.where.z += player.velocity.z * dt;
                moving = 1;
            }
        }

        if(moving)
        {
            float px = player.where.x, py = player.where.y;

            /* velocity is units/sec, so build the actual frame step first */
            float dx = player.velocity.x * dt;
            float dy = player.velocity.y * dt;

            const struct sector* const sect = &sectors[player.sector];
            const struct xy* const vert = sect->vertex;

            for(unsigned s = 0; s < sect->npoints; ++s)
            {
                if(IntersectBox(px, py, px + dx, py + dy,
                                vert[s+0].x, vert[s+0].y,
                                vert[s+1].x, vert[s+1].y)
                && PointSide(px + dx, py + dy,
                             vert[s+0].x, vert[s+0].y,
                             vert[s+1].x, vert[s+1].y) < 0)
                {
                    float hole_low  = sect->neighbors[s] < 0 ?  9e9f : max(sect->floor, sectors[sect->neighbors[s]].floor);
                    float hole_high = sect->neighbors[s] < 0 ? -9e9f : min(sect->ceil,  sectors[sect->neighbors[s]].ceil );

                    if(hole_high < player.where.z + HeadMargin
                    || hole_low  > player.where.z - eyeheight + KneeHeight)
                    {
                        /* slide along wall using the ACTUAL frame delta, not velocity/sec */
                        float xd = vert[s+1].x - vert[s+0].x;
                        float yd = vert[s+1].y - vert[s+0].y;
                        float denom = (xd * xd) + (yd * yd);

                        if (denom > 0.0f) {
                            float dot = (dx * xd + dy * yd) / denom;
                            dx = xd * dot;
                            dy = yd * dot;
                        } else {
                            dx = 0.0f;
                            dy = 0.0f;
                        }

                        moving = 0;
                    }
                }
            }

            MovePlayer(dx, dy);
            falling = 1;
        }

        {
            float move_vec[2] = {0.f, 0.f};

            if(wsad[0]) { move_vec[0] += player.anglecos * MOVE_SPEED; move_vec[1] += player.anglesin * MOVE_SPEED; }
            if(wsad[1]) { move_vec[0] -= player.anglecos * MOVE_SPEED; move_vec[1] -= player.anglesin * MOVE_SPEED; }
            if(wsad[2]) { move_vec[0] += player.anglesin * MOVE_SPEED; move_vec[1] -= player.anglecos * MOVE_SPEED; }
            if(wsad[3]) { move_vec[0] -= player.anglesin * MOVE_SPEED; move_vec[1] += player.anglecos * MOVE_SPEED; }

            int pushing = wsad[0] || wsad[1] || wsad[2] || wsad[3];
            float acceleration = pushing ? 12.0f * dt : 8.0f * dt;

            if (acceleration > 1.0f) acceleration = 1.0f;

            player.velocity.x = player.velocity.x * (1.0f - acceleration) + move_vec[0] * acceleration;
            player.velocity.y = player.velocity.y * (1.0f - acceleration) + move_vec[1] * acceleration;

            if(pushing) moving = 1;
        }

        clearScreen(0);
        DrawScreen();
        updateFPS();
        screenupdate();

    } while (running);

    UnloadData();
    EndSDL2Session();
    return 0;
}