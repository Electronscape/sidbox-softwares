#ifndef C64_BUS_H
#define C64_BUS_H

#include <stdint.h>
#include "cpu6502.h"
#include "c64_types.h"

#ifdef __cplusplus
extern "C" {
#endif

// Forward-declare device types without pulling their headers in.
typedef struct cia_t cia_t;
typedef struct vic_t vic_t;

// Optional SID hooks (provide your own SID core and plug it in)
typedef uint8_t (*c64_sid_read_fn)(void *user, uint16_t addr);
typedef void    (*c64_sid_write_fn)(void *user, uint16_t addr, uint8_t v);

// -------- ROM blobs (stubs for now) --------
// Sizes match real C64 ROM sizes:
//  BASIC  : $A000-$BFFF (8 KiB)
//  KERNAL : $E000-$FFFF (8 KiB)
//  CHAR   : $D000-$DFFF (4 KiB)
extern uint8_t ROM_BASIC[0x2000];
extern uint8_t ROM_KERNAL[0x2000];
extern uint8_t ROM_CHARMAP[0x1000];
extern uint8_t ram[0x10000];


// -------- C64 bus / memory map --------
typedef struct c64_bus_t {
    // 64K RAM (always physically present)
    // removed because i wont be using this

    // 6510 CPU port ($0000 DDR, $0001 PORT)
    uint8_t cpu_ddr;
    uint8_t cpu_port;

    // IO devices
    cia_t *cia1;  // $DC00-$DCFF
    cia_t *cia2;  // $DD00-$DDFF
    vic_t *vic;   // $D000-$D3FF

    // SID hooks for $D400-$D41F
    void *sid_user;
    c64_sid_read_fn  sid_read;
    c64_sid_write_fn sid_write;

    // Resolved interrupt lines (level)
    uint8_t irq_line; // 1 = asserted
    uint8_t nmi_line; // 1 = asserted (kept for future)

    // Video standard (affects VIC tick timing)
    c64_video_t video_std;
} c64_bus_t;

// Create a bus and wire device pointers (devices may be NULL if you stub them)
void c64_bus_init(c64_bus_t *b, vic_t *vic, cia_t *cia1, cia_t *cia2, c64_video_t std);

// Optional: plug in a SID implementation
void c64_bus_set_sid(c64_bus_t *b, void *sid_user, c64_sid_read_fn rd, c64_sid_write_fn wr);

// Helpers to install *minimal* stub ROM contents (vectors + a couple tiny routines).
// For serious RSID compatibility you’ll eventually replace these arrays with real ROM dumps.
void c64_bus_install_stub_roms(void);

// Main CPU bus callbacks (hook these into cpu6502_bus_t)
uint8_t c64_bus_read8(void *user, uint16_t addr);
void    c64_bus_write8(void *user, uint16_t addr, uint8_t v);

// Recompute IRQ/NMI based on CIA/VIC state and internal flags.
// Call this after ticking CIA/VIC or after writes to their IRQ regs.
void c64_bus_update_irqs(c64_bus_t *b);

#ifdef __cplusplus
}
#endif

#endif // C64_BUS_H
