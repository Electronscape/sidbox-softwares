/***************************************************************************
 *   Copyright (C) 2004 by David Banz                                      *
 *   neko@netcologne.de                                                    *
 *   GPL'ed                                                                *
 ***************************************************************************/

#include "../../main.h"
#include <stdio.h>
#include <string.h>
#include "player.h"
#include "tfmxglue.h"

/* external functions */

void TfmxInit();
void StartSong();
void play_it();
void TfmxTakedown();

int load_tfmx(char *mfn, char *sfn);

int dangerFreakHack=0;
int oopsUpHack=0;

/* do we have a single-file TFMX (mdat+smpl in one file) ? */
int singleFile=0;
/* are DOS extensions used? (.tfx/.sam) */
int dosExt=0;
/* header data for single-file TFMX */
uint32_t nTFhd_offset=0;
uint32_t nTFhd_mdatsize=0;
uint32_t nTFhd_smplsize=0;

U32 outRate=44100;



extern struct Hdb hdb[8];
extern struct Pdblk pdb;
extern int LoopOff();
extern struct Mdb mdb;

extern char act[8];

unsigned int mlen;
U32 editbuf[16384];
U8 *smplbuf;
int *macros;
int *patterns;


int num_ts,num_pat,num_mac;

int songnum=0;
int gubed=0;
int printinfo=0;
int startPat=-1;
int gemx=0;
int loops=1;
extern int blend,filt,over;

/* misc vars for TFMX format test */
#define MAGIK_LEN 11        /* length including final null byte */
unsigned int nMagikLen=MAGIK_LEN;
char pMagikBuf[MAGIK_LEN];




/* TFMX format test from UADE */
static int tfmxtest(unsigned char *buf, int filesize, char *pre){
  int ret = 0;

  if (buf[0] == 'T' && buf[1] == 'F' && buf[2] =='H' && buf[3] =='D')  {
    if (buf[0x8] == 0x01) {
      strncpy (pre, "TFHD1.5\x00", nMagikLen-1);		/* One File TFMX format */
      /* by Alexis NASR */
      ret = 1;
    } else if (buf[0x8] == 0x02) {
      strncpy (pre, "TFHDPro\x00",nMagikLen-1);
      ret = 1;
    } else if (buf[0x8] == 0x03) {
      strncpy (pre, "TFHD7V\x00",nMagikLen-1);
      ret = 1;
    }

  } else if ((buf[0] == 'T' && buf[1] == 'F' && buf[2] =='M' && buf[3] == 'X')||
	     (buf[0] == 't' && buf[1] == 'f' && buf[2] =='m' && buf[3] == 'x'))  {

    strncpy (pre, "MDAT\x00",nMagikLen-1);	/*default TFMX: TFMX Pro*/
    ret = 1;

    if ((buf [4] == '-' &&  buf[5] == 'S' && buf[6] =='O' && buf[7] == 'N' && buf[8] == 'G' && buf[9] == ' ')||
	(buf [4] == '_' &&  buf[5] == 'S' && buf[6] =='O' && buf[7] == 'N' && buf[8] == 'G' && buf[9] == ' ')||
	(buf [4] == 'S' &&  buf[5] == 'O' && buf[6] =='N' && buf[7] == 'G')||
	(buf [4] == 's' &&  buf[5] == 'o' && buf[6] =='n' && buf[7] == 'g')||
	(buf [4] == 0x20)) {
      if ((buf [10] =='b'  && buf[11] =='y')  ||
	  (buf [16] == ' ' && buf[17] ==' ')  ||
	  (buf [16] == '(' && buf[17] =='E' && buf[18] == 'm' && buf[19] =='p' && buf[20] =='t' && buf[21] == 'y' && buf[22] ==')' ) ||
	  (buf [16] == 0x30 && buf[17] == 0x3d) || /*lethal Zone*/
	  (buf [4]  == 0x20)) {
	if (buf[464]==0x00 && buf[465]==0x00 && buf[466]==0x00 && buf[467]==0x00) {
	  if ((buf [14]!=0x0e && buf[15] !=0x60) || /*z-out title */
	      (buf [14]==0x08 && buf[15] ==0x60 && buf[4644] != 0x09 && buf[4645] != 0x0c) || /* metal law */
	      (buf [14]==0x0b && buf[15] ==0x20 && buf[5120] != 0x8c && buf[5121] != 0x26) || /* bug bomber */
	      (buf [14]==0x09 && buf[15] ==0x20 && buf[3876] != 0x93 && buf[3977] != 0x05)) { /* metal preview */
	    strncpy (pre, "TFMX1.5\x00",nMagikLen-1);	/*TFMX 1.0 - 1.6*/
	  }
	}
      } else if (((buf[0x0e]== 0x08 && buf[0x0f] ==0xb0) &&   /* BMWi */
		  (buf[0x140] ==0x00 && buf[0x141]==0x0b) && /*End tackstep 1st subsong*/
		  (buf[0x1d2]== 0x02 && buf[0x1d3] ==0x00) && /*Trackstep datas*/

		  (buf[0x200] == 0xff && buf[0x201] ==0x00 && /*First effect*/
		   buf[0x202] == 0x00 && buf[0x203] ==0x00 &&
		   buf[0x204] == 0x01 && buf[0x205] ==0xf4 &&
		   buf[0x206] ==0xff && buf[0x207] ==0x00)) ||

		 ((buf[0x0e]== 0x0A && buf[0x0f] ==0xb0) && /* B.C Kid */
		  (buf[0x140] ==0x00 && buf[0x141]==0x15) && /*End tackstep 1st subsong*/
		  (buf[0x1d2]== 0x02 && buf[0x1d3] ==0x00) && /*Trackstep datas*/

		  (buf[0x200] == 0xef && buf[0x201] ==0xfe && /*First effect*/
		   buf[0x202] == 0x00 && buf[0x203] ==0x03 &&
		   buf[0x204] == 0x00 && buf[0x205] ==0x0d &&
		   buf[0x206] ==0x00 && buf[0x207] ==0x00)))  {
	strncpy (pre, "TFMX7V\x00",nMagikLen-1);	/* "special cases TFMX 7V*/

      } else {

	int e, i, s, t;

	/* Trackstep datas offset */
	if (buf[0x1d0] ==0x00 && buf[0x1d1] ==0x00 && buf[0x1d2] ==0x00 && buf[0x1d3] ==0x00) {
	  /* unpacked*/
	  s = 0x00000800;
	} else {
	  /*packed */
	  s = (buf[0x1d0] <<24) + (buf[0x1d1] <<16) + (buf[0x1d2] <<8) + buf[0x1d3]; /*packed*/
	}

	for (i = 0; i < 0x3d; i += 2) {
	  if (( (buf[0x140+i] <<8 ) +buf[0x141+i]) > 0x00 ) { /*subsong*/
	    t = (((buf[0x100+i]<<8) +(buf[0x101+i]))*16 +s ); /*Start of subsongs Trackstep data :)*/
	    e = (((buf[0x140+i]<<8) +(buf[0x141+i]))*16 +s ); /*End of subsongs Trackstep data :)*/
	    if (t < filesize || e < filesize) {
	      for (t = t ; t < e ; t += 2) {
		if (buf[t] == 0xef && buf[t+1] == 0xfe) {
		  if (buf[t+2] == 0x00 && buf[t+3] == 0x03 &&
		      buf[t+4] == 0xff && buf[t+5] == 0x00 && buf[t+6] == 0x00) {
		    i=0x3d;
		    strncpy (pre, "TFMX7V\x00",nMagikLen-1);	/*TFMX 7V*/
		    break;
		  }
		}
	      }
	    }
	  }
	}
      }
    }
  }
  return ret;
}


void usage(char *x)
{
	fprintf(stderr,"tfmxplay v1.1.7/SDL by Jon Pickard <marxmarv@antigates.com>,\n"
"Neochrome <neko@netcologne.de> and others.\n"
"Copyright 1996-2004, see accompanying README for details.\n"
"\n"
"Usage: %s [options] mdat-file [smpl-file]\n"
"where options is one or more of:\n"
"-b mode		set stereo mode (0=mono, default 1=headphone, 2=stereo)\n"
"-8		generate 8-bit output\n"
"-p num		subsong to play (default 0)\n"
"-f freq		suggest playback rate in samples/sec (default 44100)\n"
"-o file		write audio output to file\n"
"-i		print info about the module (text, subsong, etc.)\n"
"-w num		set low-pass filter frequency (0=none, 3=lowest, default 0)\n"
"-l num		set loop mode (0=no repeat, default 1=infinite)\n"
"-v              disable oversampling (=linear interpolation)\n"
"-D              force hack for Danger Freak title tune\n"
"-G              force old hack for GemX title tune (still incomplete)\n"
,x
);

}

void dump_macro(int *a)
{
	int x=0,s=0;
	while (((x&0xff000000)!=(0x07000000))&&(s<511))
	{
        x=tfmx_be32(a[s]);
		printf("%04x: %08x ",s,x);
		puts("");
		s++;
	}
}

/* this one can also load a single-file TFMX :) */
int load_tfmx(char *mfn, char *sfn)
{
    FILE *gfd;
    unsigned int x, y, z = 0;
    U16 *sh, *lg;

    printf("MDAT: %s\nSMPL: %s\n", mfn, sfn);

    if (!mfn || !mfn[0]) return 1;

    gfd = fopen(mfn, "rb");                 // <-- BINARY
    if (!gfd) {
        perror("fopen");
        return 1;
    }

    // jump to mdat start if single-file format
    if (singleFile == 1) {
        if (fseek(gfd, (long)nTFhd_offset, SEEK_SET) != 0) {   // <-- SEEK_SET
            perror("fseek(mdat)");
            fclose(gfd);
            return 1;
        }
    }

    // Read header (packed struct must match on-disk layout)
    if (fread(&hdr, 1, sizeof(hdr), gfd) != sizeof(hdr)) {
        perror("fread(hdr)");
        fclose(gfd);
        return 1;
    }

    // Magic checks
    if (strncmp("TFMX-SONG", hdr.magic, 9) &&
        strncmp("TFMX_SONG", hdr.magic, 9) &&
        strncasecmp("TFMXSONG", hdr.magic, 8) &&
        strncmp("TFMX",      hdr.magic, 4))
    {
        fclose(gfd);
        return 2;
    }

    // Read MDAT "editbuf" as 32-bit words, not sizeof(int)
    x = (unsigned int)fread(editbuf, sizeof(U32), 16384, gfd);
    if (x == 0) {
        perror("fread(editbuf)");
        fclose(gfd);
        return 1;
    }

    // If dual-file, close MDAT now (matches original flow)
    if (singleFile == 0) {
        fclose(gfd);
        gfd = NULL;
    }

    mlen = x;

    // Safe sentinel (don’t write past end if x == 16384)
    if (x < 16384) editbuf[x] = 0xFFFFFFFFu;
    else           editbuf[16383] = 0xFFFFFFFFu;

    // Convert header pointers
    if (!hdr.trackstart) hdr.trackstart = 0x180;
    else                 hdr.trackstart = (tfmx_be32(hdr.trackstart) - 0x200u) >> 2;

    if (!hdr.pattstart)  hdr.pattstart  = 0x80;
    else                 hdr.pattstart  = (tfmx_be32(hdr.pattstart) - 0x200u) >> 2;

    if (!hdr.macrostart) hdr.macrostart = 0x100;
    else                 hdr.macrostart = (tfmx_be32(hdr.macrostart) - 0x200u) >> 2;

    if (mlen < 136) return 2;

    // Convert song tables
    for (x = 0; x < 32; x++) {
        hdr.start[x] = tfmx_be16(hdr.start[x]);
        hdr.end[x]   = tfmx_be16(hdr.end[x]);
        hdr.tempo[x] = tfmx_be16(hdr.tempo[x]);
    }

    // Fix macros
    z = hdr.macrostart;
    macros = (int *)&editbuf[z];
    for (x = 0; x < 128; x++) {
        y = (tfmx_be32(editbuf[z]) - 0x200u);
        if ((y & 3u) || ((y >> 2) > mlen)) break;
        editbuf[z++] = (y >> 2);
    }
    num_mac = x;

    // Fix patterns
    z = hdr.pattstart;
    patterns = (int *)&editbuf[z];
    for (x = 0; x < 128; x++) {
        y = (tfmx_be32(editbuf[z]) - 0x200u);
        if ((y & 3u) || ((y >> 2) > mlen)) break;
        editbuf[z++] = (y >> 2);
    }
    num_pat = x;

    // Convert tracksteps to host endian
    lg = (U16 *)&editbuf[patterns[0]];
    sh = (U16 *)&editbuf[hdr.trackstart];
    num_ts = (patterns[0] - hdr.trackstart) >> 2;

    while (sh < lg) {
        *sh = tfmx_be16(*sh);
        sh++;
    }

    // Load samples
    if (singleFile == 1) {
        uint32_t nSmplPos = nTFhd_offset + nTFhd_mdatsize;

        if (!gfd) {
            // should not happen, but be safe
            gfd = fopen(mfn, "rb");
            if (!gfd) { perror("fopen(reopen)"); return 1; }
        }

        if (fseek(gfd, (long)nSmplPos, SEEK_SET) != 0) {
            perror("fseek(smpl)");
            fclose(gfd);
            return 1;
        }

        smplbuf = samplememory;

        if (fread(samplememory, 1, nTFhd_smplsize, gfd) != nTFhd_smplsize) {
            perror("fread(smpl)");
            fclose(gfd);
            return 1;
        }

        fclose(gfd);
    } else {



        FILE *fp = fopen(sfn, "rb");
        if (!fp) {
            perror("fopen(smpl)");
            return 1;
        }

        smplbuf = samplememory;
        if (!smplbuf) {
            perror("samplememory NULL");
            fclose(fp);
            return 1;
        }

        /* read up to 1MB */
        size_t r = fread(samplememory, 1, 1024 * 1024, fp);

        if (ferror(fp)) {
            perror("fread(smpl)");
            fclose(fp);
            return 1;
        }

        /* r now contains actual file size */
        size_t sample_size = r;

        fclose(fp);

    }

    return 0;
}
