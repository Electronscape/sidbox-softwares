//// TFMX AUDIO.C ////
#include <stdio.h>

#include "player.h"
#include <stdint.h>
#include "tfmxglue.h"

void tfmxIrqIn();

char act[8]={1,1,1,1,1,1,1,1};

extern int toOutFile;
extern struct Hdb hdb[8];
//extern struct Cdb cdb[8];
extern struct Mdb mdb;


union {
    U8 b8[BUFSIZE];
} buf;

volatile int bhead=0, btail=0;


S32 tbuf[HALFBUFSIZE*2];

extern int jiffies;
int bytes = 0, bytes2 = 0;

U32 blocksize = 0, multiplier = 1, stereo = 0;

int sndhdl = 0;
int force8 = 0;
int isfile = 0;
int over   = 0;



void mix_add_ov(struct Hdb *hw,int n,S32 *b);
void mix_add(struct Hdb *hw,int n,S32 *b);
void mixit(int n,int b);  
void mixem(U32 nb,U32 bd);
int play_it(void);
void tfmxIrqIn(void);

static int available_sound_data(){
    int l = bhead - btail + BUFSIZE;
    l %= BUFSIZE;
    return l;
}

static int nul=0;
void (*mix)(struct Hdb *,int,S32 *);

void mix_add(struct Hdb *hw,int n,S32 *b){
	register S8 * p = hw->sbeg;
	register U32 ps=hw->pos;
	int v=hw->vol;
	U32 d=hw->delta;
	U32 l=(hw->slen<<14);

	if (v>0x40)v=0x40;
	if ((p==(S8 *)&nul)||( ((hw->mode)&1)==0 )||(l<0x10000))
		return;
    if ((hw->mode&3)==1){
		p=hw->sbeg=hw->SampleStart;
		l=(hw->slen=hw->SampleLength)<<14;
		ps=0;
		hw->mode|=2;
	}
	while(n--){
		(*b++)+=(p[(ps+=d)>>14]*v);
		if (ps<l) continue;
		ps-=l;
		p=hw->SampleStart;
		if ( ((l=((hw->slen=hw->SampleLength)<<14))<0x10000) ||
		     (!hw->loop(hw)) )
				 {
			hw->slen=ps=d=0;
			p=smplbuf;
			break;
		}
	}
	hw->sbeg=p;
	hw->pos=ps;
	hw->delta=d;
	if (hw->mode&4) (hw->mode=0);
}

void mix_add_ov(struct Hdb *hw,int n,S32 *b){
	register S8 * p = hw->sbeg;
	register U32 ps=hw->pos;
	register U32 psreal;
	int v=hw->vol;
	U32 d=hw->delta;
	U32 l=(hw->slen<<14);

	int v1;
	int v2;

	if (v>0x40)v=0x40;
	if ((p==(S8 *)&nul)||( ((hw->mode)&1)==0 )||(l<0x10000))
		return;
    if ((hw->mode&3)==1){
		p=hw->sbeg=hw->SampleStart;
		l=(hw->slen=hw->SampleLength)<<14;
		ps=0;
		hw->mode|=2;
	}

#define FRACTION_BITS 14
#define INTEGER_MASK (0xFFFFFFFF << FRACTION_BITS)
#define FRACTION_MASK (~ INTEGER_MASK)

	while(n--){
		psreal = ps>>FRACTION_BITS;
		v1 = p[psreal];
        if (psreal+1 < hw->slen){
			v2 = p[psreal+1];
        } else {
			v2 = hw->SampleStart[0];
			/* fprintf(stderr, "H"); */
			/* (*b++) += v*v1; */
		}
		(*b++) += v*((v1 +
			      (((signed) ((v2-v1) * (ps & FRACTION_MASK)))
			       >> FRACTION_BITS)));
		ps += d;

		if (ps<l) continue;
		ps-=l;
		p=hw->SampleStart;
		if ( ((l=((hw->slen=hw->SampleLength)<<14))<0x10000) ||
		     (!hw->loop(hw)) )
				 {
			hw->slen=ps=d=0;
			p=smplbuf;
			break;
		}
	}
	hw->sbeg=p;
	hw->pos=ps;
	hw->delta=d;
	if (hw->mode&4) (hw->mode=0);
}
	
void (*mix)(struct Hdb *,int,S32 *)=&mix_add;

void mixit(int n,int b){
	int x;
    S32 *y;
	if (multimode)	{
		if(act[4])mix(&hdb[4],n,&tbuf[b]);
		if(act[5])mix(&hdb[5],n,&tbuf[b]);
		if(act[6])mix(&hdb[6],n,&tbuf[b]);
		if(act[7])mix(&hdb[7],n,&tbuf[b]);
		y=&tbuf[HALFBUFSIZE+b];
		for (x=0;x<n;x++,y++)
			*y=(*y>16383)?16383:
			   (*y<-16383)?-16383:*y;
	}
	else
		if(act[3])mix(&hdb[3],n,&tbuf[b]);

	if(act[0])mix(&hdb[0],n,&tbuf[b]);
	if(act[1])mix(&hdb[1],n,&tbuf[HALFBUFSIZE+b]);
	if(act[2])mix(&hdb[2],n,&tbuf[HALFBUFSIZE+b]);
}

void mixem(U32 nb,U32 bd){
	if (over==-1) mix=&mix_add_ov; else mix=&mix_add;
    mixit(nb, bd);

}



