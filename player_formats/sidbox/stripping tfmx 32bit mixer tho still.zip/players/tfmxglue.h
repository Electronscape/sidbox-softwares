#ifndef TFMXGLUE_H
#define TFMXGLUE_H



// =================== TFMX INTEGRATION (no SDL) ===================
#include "player.h"     // your original TFMX headers
#include "tfmxplay.h"

// TFMX expects these globals (they already exist in original codebase).
// Make sure they are defined EXACTLY ONCE across your build.
extern struct Hdr hdr;
extern struct Hdb hdb[8];
extern struct Cdb cdb[16];
extern struct Mdb mdb;

extern void TfmxInit(void);
extern void StartSong(int song, int mode);
extern void tfmxIrqIn(void);
extern void mixem(U32 nb, U32 bd);
extern void filter(S32 *b, int num);
extern void stereoblend(S32 *b, int num);

extern void check_md5_and_headers(char *mfile);
extern int  load_tfmx(char *mfn, char *sfn);

// If your build already defines these in the original files, KEEP them there.
// Do NOT duplicate definitions here, or you’ll get multiple-definition link errors.
extern U32 outRate;
extern U32 eClocks;
extern int multimode;
extern int blend;
extern int filt;
extern int over;
extern int loops;
extern int songnum;

// This exists in original audio.c (SDL harness). We need it for mixit() paths.
extern char act[8];

#define     BUF_SIZE    4096
// Needed by mix/convert path
#define HALFBUFSIZE ((BUF_SIZE * 4) /4)
#define BUFSIZE (( (BUF_SIZE*2) * 4) /4)
extern S32 tbuf[HALFBUFSIZE * 2];

extern uint8_t songmemory[];
extern uint8_t samplememory[];







#endif // TFMXGLUE_H
