// playmed.c
#include "playmed.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MED_MAX_SAMPLES   63
#define MED_MAX_TRACKS    64
#define MED_MAX_ROWS      256

#define FP_SHIFT          14
#define FP_ONE            (1u << FP_SHIFT)

// PAL Paula master clock
#define AMIGA_CLOCK_PAL   7093789u

typedef struct {
    uint8_t note;   // 0 = empty
    uint8_t inst;   // 0 = empty, else 1..63
    uint8_t cmd;
    uint8_t param;
} MedEvent;

typedef struct {
    int8_t  *data;          // signed 8-bit mono
    uint32_t length;        // bytes
    uint32_t loopStart;     // bytes
    uint32_t loopLen;       // bytes
    uint8_t  volume;        // 0..64
    int8_t   transpose;     // semitones
    uint8_t  valid;
} MedSample;

typedef struct {
    uint8_t  active;
    uint8_t  inst;          // 0..62
    uint8_t  vol;           // 0..64

    uint16_t period;        // base amiga period
    uint16_t targetPeriod;  // tone porta target
    uint16_t portaSpeed;

    uint8_t  vibSpeed;
    uint8_t  vibDepth;
    uint8_t  vibPos;

    uint8_t  arpX, arpY;

    uint8_t  noteDelay;     // EDx
    uint8_t  noteCut;       // ECx

    uint8_t  lastInst1;     // last inst in 1..63
    uint8_t  lastNote;      // last note val

    uint32_t stepFP;
    uint32_t posFP;

    uint8_t  loopCount;     // E6x
    uint16_t loopRow;       // E60
} MedChan;

typedef struct {
    uint8_t  *file;
    uint32_t  fileLen;
    char      lastErr[256];

    uint8_t   version;          // 0 or 1
    uint32_t  songOffset;
    uint32_t  blockArrOffset;
    uint32_t  sampleArrOffset;
    uint32_t  expDataOffset;

    // song header
    uint16_t  numBlocks;
    uint16_t  songLen;
    uint8_t   playSeq[256];

    uint16_t  defTempo;         // MED tempo value (interpretation depends on mode)
    int8_t    playTransp;
    uint8_t   flags;
    uint8_t   flags2;
    uint8_t   tempo2;           // ticks-per-line (TPL)
    uint8_t   trkVol[16];
    uint8_t   masterVol;
    uint8_t   numSamples;

    struct {
        uint16_t rep;
        uint16_t replen;
        uint8_t  midich;
        uint8_t  midipreset;
        uint8_t  svol;
        int8_t   strans;
    } smphdr[MED_MAX_SAMPLES];

    MedSample samples[MED_MAX_SAMPLES];

    // derived modes
    uint8_t  bpmMode;           // flags2 & 0x20
    uint8_t  rowsPerBeat;       // (flags2 & 0x1F) + 1
    uint8_t  ticksPerLine;      // tempo2 (TPL)

    // playback
    uint32_t outRate;

    uint16_t curOrder;
    uint16_t curRow;
    uint8_t  curTick;

    // fixed-point tick scheduler:
    // tickAccFP accumulates "1 sample" each output sample (FP_ONE)
    // when tickAccFP >= samplesPerTickFP: advance a tick, subtract
    uint32_t samplesPerTickFP;
    uint32_t tickAccFP;

    // pattern delay (EEx)
    uint8_t  patDelayCnt;

    // pattern cache
    uint8_t  patLoaded;
    uint16_t patIndex;
    uint16_t patRows;
    uint16_t patTracks;
    uint8_t  numTracks;
    MedEvent pat[MED_MAX_ROWS][MED_MAX_TRACKS];

    MedChan  ch[MED_MAX_TRACKS];
} MedState;

static MedState g_med;

// ---------------- basic utils ----------------
static void med_err(const char *msg){
    snprintf(g_med.lastErr, sizeof(g_med.lastErr), "%s", msg ? msg : "error");
}
const char *playMED_LastError(void){
    return g_med.lastErr[0] ? g_med.lastErr : "";
}

static uint16_t rd_be16(const uint8_t *p){
    return (uint16_t)((p[0] << 8) | p[1]);
}
static uint32_t rd_be32(const uint8_t *p){
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static int file_can(uint32_t off, uint32_t need){
    return (g_med.file && off <= g_med.fileLen && need <= g_med.fileLen && (off + need) <= g_med.fileLen);
}
static inline int16_t clamp16(int32_t v){
    if(v < -32768) return -32768;
    if(v >  32767) return  32767;
    return (int16_t)v;
}
static inline uint8_t clamp_u8_64(int v){
    if(v < 0) return 0;
    if(v > 64) return 64;
    return (uint8_t)v;
}

// ---------------- period table ----------------
// ProTracker base periods C-1..B-4
static const uint16_t basePeriods[48] = {
    1712,1616,1524,1440,1356,1280,1208,1140,1076,1016, 960, 906,
    856, 808, 762, 720, 678, 640, 604, 570, 538, 508, 480, 453,
    428, 404, 381, 360, 339, 320, 302, 285, 269, 254, 240, 226,
    214, 202, 190, 180, 170, 160, 151, 143, 135, 127, 120, 113
};

static uint16_t note_to_period(int noteVal /*1..*/){
    if(noteVal <= 0) return 0;
    int idx = noteVal - 1;
    int oct = idx / 12;
    int n   = idx % 12;

    int baseOct = oct;
    if(baseOct > 3) baseOct = 3;
    int baseIdx = baseOct * 12 + n;
    if(baseIdx < 0) baseIdx = 0;
    if(baseIdx > 47) baseIdx = 47;

    uint32_t p = basePeriods[baseIdx];

    int diff = oct - baseOct;
    while(diff > 0){ p >>= 1; diff--; }
    while(diff < 0){ p <<= 1; diff++; }

    if(p < 1) p = 1;
    if(p > 65535u) p = 65535u;
    return (uint16_t)p;
}

static uint32_t period_to_stepFP(uint16_t period){
    if(period == 0) return 0;
    uint32_t rate = (uint32_t)(AMIGA_CLOCK_PAL / (uint32_t)period); // Hz
    uint32_t step = (uint32_t)(((uint64_t)rate * (uint64_t)FP_ONE) / (uint64_t)g_med.outRate);
    if(step < 1) step = 1;
    return step;
}

// ---------------- tempo model (this is the real fix) ----------------
// Convert MED "tempo value" into a BPM-ish number.
// Rules that behave well across real-world MMD0/1:
//
// - If tempo >= 0x20: treat as BPM (MOD style).
// - If tempo 1..10: use classic MED import table.
// - Else fallback to 125.
static double med_tempo_to_bpm(uint32_t tempo)
{
    // Practical MED timing model:
    //
    // bpmMode=1:
    //   - tempo is closer to real BPM (OctaMED), with a known quirk for <7.
    //
    // bpmMode=0:
    //   - tempo is a MED tempo-value, NOT literal BPM.
    //   - 1..10 uses the classic import table
    //   - otherwise use the widely-used MED scale: tempo / 0.264

    static const uint8_t tbl[10] = {179,164,152,141,131,123,116,110,104,99};

    if(tempo == 0) tempo = 125;

    if(g_med.bpmMode){
        if(tempo < 7) return 111.5;     // common OctaMED quirk
        return (double)tempo;
    }

    // non-bpmMode
    if(tempo >= 1 && tempo <= 10) return (double)tbl[tempo - 1];

    return ((double)tempo / 0.264);
}

// ---- drop-in: libmodplug-compatible MED timing (MMD0/MMD1) ----
// Matches libmodplug/src/load_med.cpp conversion rules. :contentReference[oaicite:1]{index=1}

// ---- drop-in recompute_timing (32-bit safe, no floats) ----

static uint32_t muldiv_u32(uint32_t a, uint32_t b, uint32_t c)
{
    if(c == 0) return 0;
    return (uint32_t)(((uint64_t)a * (uint64_t)b) / (uint64_t)c);
}

static void recompute_timing(void)
{
    // Defaults (match common tracker expectations)
    uint32_t tpl = g_med.ticksPerLine ? g_med.ticksPerLine : 6;               // ticks per line
    uint32_t lpb = (uint32_t)((g_med.flags2 & 0x1F) + 1u);                    // lines per beat
    if(lpb == 0) lpb = 4;

    uint32_t tempo = g_med.defTempo ? g_med.defTempo : 125;

    g_med.ticksPerLine = (uint8_t)tpl;
    g_med.rowsPerBeat  = (uint8_t)lpb;
    g_med.bpmMode      = (g_med.flags2 & 0x20) ? 1 : 0;

    uint32_t samplesPerTickFP = 1;

    if(g_med.bpmMode)
    {
        // --- OctaMED BPM mode ---
        // secPerTick = 60 / (BPM * LPB * TPL)
        // samplesPerTickFP = outRate * 60 * FP_ONE / (BPM * LPB * TPL)
        // Use 64-bit intermediate, round-to-nearest.
        uint64_t den = (uint64_t)tempo * (uint64_t)lpb * (uint64_t)tpl;
        if(den == 0) den = 1;

        uint64_t num = (uint64_t)g_med.outRate * 60ull * (uint64_t)FP_ONE;
        samplesPerTickFP = (uint32_t)((num + (den / 2ull)) / den);
    }
    else
    {
        // --- Old MED tempo (non-BPM) -> MOD-style BPM ---
        // This is the conversion that generally matches real-world MMD0/1.
        static const uint8_t bpmvals[10] = {179,164,152,141,131,123,116,110,104,99};

        uint32_t bpm;

        // if 8-channel flag and tempo 1..10 use table (common MED import quirk)
        if((g_med.flags & 0x40) && (tempo >= 1u) && (tempo <= 10u))
        {
            bpm = (uint32_t)bpmvals[tempo - 1u];
        }
        else
        {
            // bpm = tempo * 3579545 / 948652
            bpm = muldiv_u32(tempo, 3579545u, 948652u);
        }

        // Clamp to sane MOD tempo range
        if(bpm < 32u)  bpm = 32u;
        if(bpm > 255u) bpm = 255u;

        // MOD tick law: secPerTick = 2.5 / BPM
        // samplesPerTickFP = outRate * 2.5 * FP_ONE / BPM
        // = outRate * 5 * FP_ONE / (2*BPM)
        uint64_t num = (uint64_t)g_med.outRate * 5ull * (uint64_t)FP_ONE;
        uint64_t den = 2ull * (uint64_t)bpm;
        if(den == 0) den = 1;

        samplesPerTickFP = (uint32_t)((num + (den / 2ull)) / den);
    }

    if(samplesPerTickFP < 1u) samplesPerTickFP = 1u;
    g_med.samplesPerTickFP = samplesPerTickFP;
}

// ---------------- file load ----------------
static int load_entire_file(const char *filename){
    FILE *f = fopen(filename, "rb");
    if(!f){ med_err("fopen failed"); return 0; }

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if(sz <= 0){ fclose(f); med_err("empty file"); return 0; }

    g_med.file = (uint8_t*)malloc((size_t)sz);
    if(!g_med.file){ fclose(f); med_err("malloc failed"); return 0; }

    if(fread(g_med.file, 1, (size_t)sz, f) != (size_t)sz){
        fclose(f);
        free(g_med.file); g_med.file = NULL;
        med_err("fread failed");
        return 0;
    }
    fclose(f);
    g_med.fileLen = (uint32_t)sz;
    return 1;
}

// ---------------- parse headers ----------------
static int parse_headers(void){
    if(!file_can(0, 52)){ med_err("file too small"); return 0; }

    if(!(g_med.file[0]=='M' && g_med.file[1]=='M' && g_med.file[2]=='D')){
        med_err("not MMD");
        return 0;
    }
    char verch = (char)g_med.file[3];
    if(verch < '0' || verch > '1'){
        med_err("only MMD0/MMD1 supported");
        return 0;
    }
    g_med.version = (uint8_t)(verch - '0');

    g_med.songOffset      = rd_be32(&g_med.file[8]);
    g_med.blockArrOffset  = rd_be32(&g_med.file[16]);
    g_med.sampleArrOffset = rd_be32(&g_med.file[24]);
    g_med.expDataOffset   = rd_be32(&g_med.file[32]);

    if(g_med.songOffset == 0 || !file_can(g_med.songOffset, 788u)){
        med_err("bad songOffset");
        return 0;
    }
    if(g_med.blockArrOffset == 0 || !file_can(g_med.blockArrOffset, 4u)){
        med_err("bad blockArrOffset");
        return 0;
    }

    uint32_t so = g_med.songOffset;

    for(uint32_t i=0;i<63;i++){
        const uint8_t *p = &g_med.file[so + i*8u];
        g_med.smphdr[i].rep        = rd_be16(p+0);
        g_med.smphdr[i].replen     = rd_be16(p+2);
        g_med.smphdr[i].midich     = p[4];
        g_med.smphdr[i].midipreset = p[5];
        g_med.smphdr[i].svol       = p[6];
        g_med.smphdr[i].strans     = (int8_t)p[7];
    }

    g_med.numBlocks  = rd_be16(&g_med.file[so + 504]);
    g_med.songLen    = rd_be16(&g_med.file[so + 506]);
    memcpy(g_med.playSeq, &g_med.file[so + 508], 256);

    g_med.defTempo   = rd_be16(&g_med.file[so + 764]);
    g_med.playTransp = (int8_t)g_med.file[so + 766];
    g_med.flags      = g_med.file[so + 767];
    g_med.flags2     = g_med.file[so + 768];
    g_med.tempo2     = g_med.file[so + 769];
    memcpy(g_med.trkVol, &g_med.file[so + 770], 16);
    g_med.masterVol  = g_med.file[so + 786];
    g_med.numSamples = g_med.file[so + 787];

    if(g_med.numSamples > 63){ med_err("numsamples > 63"); return 0; }
    if(g_med.numBlocks == 0){ med_err("no patterns"); return 0; }
    if(g_med.songLen == 0 || g_med.songLen > 256){ med_err("bad song length"); return 0; }

    g_med.bpmMode      = (g_med.flags2 & 0x20) ? 1 : 0;
    g_med.rowsPerBeat  = (uint8_t)((g_med.flags2 & 0x1F) + 1);
    g_med.ticksPerLine = g_med.tempo2 ? g_med.tempo2 : 6;

    recompute_timing();
    return 1;
}

// ---------------- samples ----------------
static int load_samples(void){
    for(uint32_t i=0;i<MED_MAX_SAMPLES;i++){
        g_med.samples[i].data = NULL;
        g_med.samples[i].length = 0;
        g_med.samples[i].loopStart = 0;
        g_med.samples[i].loopLen = 0;
        g_med.samples[i].volume = 0;
        g_med.samples[i].transpose = 0;
        g_med.samples[i].valid = 0;
    }

    if(g_med.numSamples == 0) return 1;
    if(g_med.sampleArrOffset == 0){
        return 1; // synth-only or external instruments
    }
    if(!file_can(g_med.sampleArrOffset, g_med.numSamples * 4u)){
        med_err("sample offset table out of range");
        return 0;
    }

    for(uint32_t i=0;i<g_med.numSamples;i++){
        g_med.samples[i].volume    = clamp_u8_64(g_med.smphdr[i].svol);
        g_med.samples[i].transpose = g_med.smphdr[i].strans;

        uint32_t instOff = rd_be32(&g_med.file[g_med.sampleArrOffset + i*4u]);
        if(instOff == 0) continue;
        if(!file_can(instOff, 6)) continue;

        uint32_t len  = rd_be32(&g_med.file[instOff + 0]);
        uint16_t type = rd_be16(&g_med.file[instOff + 4]);

        // Only: 8-bit mono, unpacked, no delta
        if((int16_t)type < 0) continue;
        if(type & 0x10) continue; // 16-bit
        if(type & 0x20) continue; // stereo
        if(type & 0x40) continue; // delta
        if(type & 0x80) continue; // packed

        uint32_t dataOff = instOff + 6;
        if(len == 0) continue;
        if(!file_can(dataOff, len)) continue;

        int8_t *buf = (int8_t*)malloc(len);
        if(!buf){ med_err("malloc sample failed"); return 0; }
        memcpy(buf, &g_med.file[dataOff], len);

        uint32_t loopStart = (uint32_t)g_med.smphdr[i].rep * 2u;
        uint32_t loopLen   = (uint32_t)g_med.smphdr[i].replen * 2u;

        if(loopStart >= len){ loopStart = 0; loopLen = 0; }
        if(loopLen < 2) loopLen = 0;
        if(loopLen && loopStart + loopLen > len){
            loopLen = (loopStart < len) ? (len - loopStart) : 0;
        }

        g_med.samples[i].data = buf;
        g_med.samples[i].length = len;
        g_med.samples[i].loopStart = loopStart;
        g_med.samples[i].loopLen = loopLen;
        g_med.samples[i].valid = 1;
    }

    return 1;
}

// ---------------- pattern load ----------------
static int load_pattern(uint16_t pat){
    if(pat >= g_med.numBlocks) return 0;

    if(!file_can(g_med.blockArrOffset + pat*4u, 4u)) return 0;
    uint32_t blkOff = rd_be32(&g_med.file[g_med.blockArrOffset + pat*4u]);
    if(blkOff == 0) return 0;

    if(g_med.version == 0){
        if(!file_can(blkOff, 2u)) return 0;
    } else {
        if(!file_can(blkOff, 8u)) return 0;
    }

    memset(g_med.pat, 0, sizeof(g_med.pat));
    g_med.patIndex = pat;

    uint16_t tracks = 0;
    uint16_t rows   = 0;
    uint32_t dataOff = 0;

    if(g_med.version == 0){
        tracks = g_med.file[blkOff + 0];
        rows   = (uint16_t)g_med.file[blkOff + 1] + 1u;
        dataOff= blkOff + 2u;
    } else {
        tracks = rd_be16(&g_med.file[blkOff + 0]);
        rows   = (uint16_t)rd_be16(&g_med.file[blkOff + 2]) + 1u;
        dataOff= blkOff + 8u;
    }

    if(tracks == 0) tracks = 1;
    if(rows == 0) rows = 1;
    if(rows > MED_MAX_ROWS) rows = MED_MAX_ROWS;

    g_med.patRows   = rows;
    g_med.patTracks = tracks;
    g_med.numTracks = (uint8_t)((tracks > MED_MAX_TRACKS) ? MED_MAX_TRACKS : tracks);

    uint32_t bytesPer = (g_med.version == 0) ? 3u : 4u;
    uint64_t need = (uint64_t)rows * (uint64_t)tracks * (uint64_t)bytesPer;
    if((uint64_t)dataOff + need > (uint64_t)g_med.fileLen) return 0;

    const uint8_t *p = &g_med.file[dataOff];

    for(uint16_t r=0;r<rows;r++){
        for(uint16_t t=0;t<tracks;t++){
            if(g_med.version == 0){
                uint8_t b0 = *p++;
                uint8_t b1 = *p++;
                uint8_t b2 = *p++;

                uint8_t note = (uint8_t)(b0 & 0x3F);
                uint8_t inst = (uint8_t)(((b0 & 0xC0) >> 2) | ((b1 & 0xF0) >> 4));
                uint8_t cmd  = (uint8_t)(b1 & 0x0F);
                uint8_t par  = b2;

                if(t < MED_MAX_TRACKS){
                    g_med.pat[r][t].note  = note;
                    g_med.pat[r][t].inst  = inst;
                    g_med.pat[r][t].cmd   = cmd;
                    g_med.pat[r][t].param = par;
                }
            } else {
                uint8_t note = *p++;
                uint8_t inst = *p++;
                uint8_t cmd  = *p++;
                uint8_t par  = *p++;

                if(note > 0x84) note = 0;

                if(t < MED_MAX_TRACKS){
                    g_med.pat[r][t].note  = note;
                    g_med.pat[r][t].inst  = inst;
                    g_med.pat[r][t].cmd   = cmd;
                    g_med.pat[r][t].param = par;
                }
            }
        }
    }

    g_med.patLoaded = 1;
    return 1;
}

// ---------------- reset player ----------------
static void reset_player(void){
    g_med.curOrder = 0;
    g_med.curRow   = 0;
    g_med.curTick  = 0;

    g_med.tickAccFP = 0;
    g_med.patDelayCnt = 0;

    g_med.patLoaded = 0;
    g_med.patIndex  = 0xFFFF;

    for(uint32_t i=0;i<MED_MAX_TRACKS;i++){
        memset(&g_med.ch[i], 0, sizeof(g_med.ch[i]));
    }
}

// ---------------- effect helpers ----------------
static int8_t sine64(int idx){
    static const int8_t s[64] = {
        0, 12, 25, 37, 49, 60, 71, 81,
        90, 98,105,111,116,120,123,125,
        127,125,123,120,116,111,105, 98,
        90, 81, 71, 60, 49, 37, 25, 12,
        0,-12,-25,-37,-49,-60,-71,-81,
        -90,-98,-105,-111,-116,-120,-123,-125,
        -127,-125,-123,-120,-116,-111,-105, -98,
        -90, -81, -71, -60, -49, -37, -25, -12
    };
    return s[idx & 63];
}

static void fx_arpeggio(MedChan *c, uint8_t tick){
    if(!c->period) return;
    uint8_t add = 0;
    switch(tick % 3){
    case 1: add = c->arpX; break;
    case 2: add = c->arpY; break;
    default:add = 0; break;
    }
    int nn = (int)c->lastNote + (int)add;
    if(nn < 1) nn = 1;
    uint16_t per = note_to_period(nn);
    if(per) c->stepFP = period_to_stepFP(per);
}

static void fx_porta_up(MedChan *c, uint8_t param){
    if(!c->period) return;
    uint16_t p = c->period;
    p = (p > param) ? (uint16_t)(p - param) : 1;
    c->period = p;
    c->stepFP = period_to_stepFP(p);
}

static void fx_porta_down(MedChan *c, uint8_t param){
    if(!c->period) return;
    uint32_t p = (uint32_t)c->period + (uint32_t)param;
    if(p > 65535u) p = 65535u;
    c->period = (uint16_t)p;
    c->stepFP = period_to_stepFP(c->period);
}

static void fx_tone_porta(MedChan *c){
    if(!c->period || !c->targetPeriod || !c->portaSpeed) return;

    uint16_t p = c->period;
    if(p < c->targetPeriod){
        uint32_t np = (uint32_t)p + (uint32_t)c->portaSpeed;
        if(np > c->targetPeriod) np = c->targetPeriod;
        c->period = (uint16_t)np;
    } else if(p > c->targetPeriod){
        int32_t np = (int32_t)p - (int32_t)c->portaSpeed;
        if(np < (int32_t)c->targetPeriod) np = (int32_t)c->targetPeriod;
        if(np < 1) np = 1;
        c->period = (uint16_t)np;
    }
    c->stepFP = period_to_stepFP(c->period);
}

static void fx_vibrato(MedChan *c){
    if(!c->period) return;
    int8_t sv = sine64(c->vibPos);
    int32_t delta = ((int32_t)sv * (int32_t)c->vibDepth) / 128;
    int32_t per = (int32_t)c->period + delta;
    if(per < 1) per = 1;
    if(per > 65535) per = 65535;
    c->stepFP = period_to_stepFP((uint16_t)per);
    c->vibPos = (uint8_t)(c->vibPos + c->vibSpeed);
}

static void fx_volslide(MedChan *c, uint8_t param){
    uint8_t x = (param >> 4) & 0x0F;
    uint8_t y = (param & 0x0F);
    int v = (int)c->vol + (int)x - (int)y;
    c->vol = clamp_u8_64(v);
}

// ---------------- note trigger ----------------
static void chan_trigger_note(uint16_t t, uint8_t inst1, uint8_t noteVal){
    if(t >= g_med.numTracks) return;
    if(inst1 == 0 || noteVal == 0) return;

    MedChan *c = &g_med.ch[t];

    c->lastInst1 = inst1;
    c->lastNote  = noteVal;

    uint8_t si = (uint8_t)(inst1 - 1);

    int nn = (int)noteVal + (int)g_med.playTransp;
    if(si < g_med.numSamples) nn += (int)g_med.samples[si].transpose;
    if(nn < 1) nn = 1;

    uint16_t per = note_to_period(nn);

    c->inst = (si < MED_MAX_SAMPLES) ? si : 0;
    c->period = per;
    c->targetPeriod = per;

    if(si < g_med.numSamples && g_med.samples[si].valid){
        c->active = 1;
        c->posFP  = 0;
        c->vol    = g_med.samples[si].volume;
    } else {
        c->active = 0;
    }

    c->stepFP = period_to_stepFP(c->period);
}

// ---------------- row command decode ----------------
static void apply_cmd_row(uint16_t t, uint8_t cmd, uint8_t param, uint8_t noteVal, uint8_t inst1){
    MedChan *c = &g_med.ch[t];
    uint8_t x = (param >> 4) & 0x0F;
    uint8_t y = (param & 0x0F);

    switch(cmd){
    case 0x0: // arpeggio
        c->arpX = x; c->arpY = y;
        break;

    case 0x3: // tone porta
    case 0x5: // tone porta + volslide
        if(param && cmd == 0x3) c->portaSpeed = param;
        if(noteVal){
            uint8_t useInst1 = inst1 ? inst1 : c->lastInst1;
            uint8_t si = useInst1 ? (uint8_t)(useInst1 - 1) : c->inst;
            int nn = (int)noteVal + (int)g_med.playTransp;
            if(si < g_med.numSamples) nn += (int)g_med.samples[si].transpose;
            if(nn < 1) nn = 1;
            c->targetPeriod = note_to_period(nn);
            c->lastNote = noteVal;
        }
        break;

    case 0x4: // vibrato
    case 0x6: // vibrato + volslide
        if(x) c->vibSpeed = x;
        if(y) c->vibDepth = y;
        break;

    case 0x9: // secondary speed/tempo (treat like MOD Fxx)
        if(param > 0 && param < 0x20){
            g_med.ticksPerLine = param;
            recompute_timing();
        } else if(param >= 0x20){
            g_med.defTempo = (uint16_t)param;
            recompute_timing();
        }
        break;

    case 0xB: // position jump
        g_med.curOrder = param;
        if(g_med.curOrder >= g_med.songLen) g_med.curOrder = 0;
        g_med.curRow = 0;
        break;

    case 0xC: // set volume
        c->vol = clamp_u8_64(param);
        break;

    case 0xD: { // pattern break to row (BCD)
        uint8_t row = (uint8_t)((x * 10u) + y);
        g_med.curOrder++;
        if(g_med.curOrder >= g_med.songLen) g_med.curOrder = 0;
        g_med.curRow = row;
    } break;

    case 0xE: // extended
        switch(x){
        case 0x6: // E6x pattern loop
            if(y == 0){
                c->loopRow = g_med.curRow;
            } else {
                if(c->loopCount == 0){
                    c->loopCount = y;
                    g_med.curRow = c->loopRow;
                } else {
                    c->loopCount--;
                    if(c->loopCount) g_med.curRow = c->loopRow;
                }
            }
            break;

        case 0xC: // ECx note cut
            c->noteCut = y;
            break;

        case 0xD: // EDx note delay
            c->noteDelay = y;
            break;

        case 0xE: // EEx pattern delay
            g_med.patDelayCnt = y;
            break;

        default:
            break;
        }
        break;

    case 0xF: // speed/tempo (treat like MOD Fxx)
        if(param == 0){
            // NO-OP (important). Lots of songs rely on this not doing weird jumps.
        } else if(param < 0x20){
            g_med.ticksPerLine = param;
            recompute_timing();
        } else {
            g_med.defTempo = (uint16_t)param;
            recompute_timing();
        }
        break;

    default:
        break;
    }
}

// ---------------- process row/tick ----------------
static void process_row(void){
    uint8_t pat = g_med.playSeq[g_med.curOrder];
    if(!g_med.patLoaded || g_med.patIndex != pat){
        if(!load_pattern(pat)) return;
    }

    if(g_med.curRow >= g_med.patRows) g_med.curRow = 0;

    for(uint16_t t=0;t<g_med.numTracks;t++){
        MedChan *c = &g_med.ch[t];
        MedEvent e = g_med.pat[g_med.curRow][t];

        uint8_t inst1 = e.inst;
        uint8_t note  = e.note;
        uint8_t cmd   = e.cmd;
        uint8_t par   = e.param;

        // row-only reset
        c->noteDelay = 0;
        c->noteCut   = 0;

        if(inst1){
            c->lastInst1 = inst1;
            uint8_t si = (uint8_t)(inst1 - 1);
            if(si < MED_MAX_SAMPLES) c->inst = si;
            if(si < g_med.numSamples && g_med.samples[si].valid){
                c->vol = g_med.samples[si].volume;
            }
        }

        uint8_t isTonePorta = (cmd == 0x3 || cmd == 0x5);

        if(note){
            c->lastNote = note;
            if(!isTonePorta){
                uint8_t useInst1 = inst1 ? inst1 : c->lastInst1;
                chan_trigger_note(t, useInst1, note);
            }
        }

        if(cmd || par){
            apply_cmd_row(t, cmd, par, note, inst1);
        }
    }

    // advance row unless pattern delay is active
    if(g_med.patDelayCnt){
        // hold row; countdown happens when a full line completes
    } else {
        g_med.curRow++;
        if(g_med.curRow >= g_med.patRows){
            g_med.curRow = 0;
            g_med.curOrder++;
            if(g_med.curOrder >= g_med.songLen) g_med.curOrder = 0;
        }
    }
}

static void process_tick(void){
    uint16_t rowPlaying;
    if(g_med.patDelayCnt){
        rowPlaying = g_med.curRow;
    } else {
        rowPlaying = (g_med.curRow == 0) ? (g_med.patRows - 1) : (g_med.curRow - 1);
    }

    for(uint16_t t=0;t<g_med.numTracks;t++){
        MedChan *c = &g_med.ch[t];
        if(!c->active || c->period == 0) continue;

        if(c->noteCut && g_med.curTick == c->noteCut){
            c->vol = 0;
        }

        if(c->noteDelay && g_med.curTick == c->noteDelay){
            uint8_t useInst1 = c->lastInst1 ? c->lastInst1 : (uint8_t)(c->inst + 1);
            if(c->lastNote) chan_trigger_note(t, useInst1, c->lastNote);
        }

        MedEvent e = g_med.pat[rowPlaying][t];
        uint8_t cmd = e.cmd;
        uint8_t par = e.param;

        switch(cmd){
        case 0x0: if(par) fx_arpeggio(c, g_med.curTick); break;
        case 0x1: fx_porta_up(c, par); break;
        case 0x2: fx_porta_down(c, par); break;
        case 0x3: fx_tone_porta(c); break;
        case 0x4: fx_vibrato(c); break;
        case 0x5: fx_tone_porta(c); fx_volslide(c, par); break;
        case 0x6: fx_vibrato(c);    fx_volslide(c, par); break;
        case 0xA: fx_volslide(c, par); break;
        default: break;
        }

        if(cmd == 0x0 && (g_med.curTick % 3) == 0){
            c->stepFP = period_to_stepFP(c->period);
        }
    }
}

static void player_tick_advance(void){
    if(g_med.curTick == 0){
        process_row();
    } else {
        process_tick();
    }

    g_med.curTick++;
    if(g_med.curTick >= g_med.ticksPerLine){
        g_med.curTick = 0;

        if(g_med.patDelayCnt){
            g_med.patDelayCnt--;
            if(g_med.patDelayCnt == 0){
                g_med.curRow++;
                if(g_med.curRow >= g_med.patRows){
                    g_med.curRow = 0;
                    g_med.curOrder++;
                    if(g_med.curOrder >= g_med.songLen) g_med.curOrder = 0;
                }
            }
        }
    }
}

// ---------------- mixer ----------------
static void mix_one(int16_t *outL, int16_t *outR){
    int32_t sumL = 0;
    int32_t sumR = 0;

    static const uint8_t isRight4[4] = {0,1,1,0};

    int32_t mv = g_med.masterVol ? g_med.masterVol : 64;
    if(mv > 64) mv = 64;

    for(uint16_t t=0;t<g_med.numTracks;t++){
        MedChan *c = &g_med.ch[t];
        if(!c->active || c->stepFP == 0) continue;

        uint8_t si = c->inst;
        if(si >= g_med.numSamples) continue;

        MedSample *s = &g_med.samples[si];
        if(!s->valid || !s->data || s->length == 0) continue;

        c->posFP += c->stepFP;
        uint32_t idx = (c->posFP >> FP_SHIFT);

        if(s->loopLen){
            uint32_t loopEnd = s->loopStart + s->loopLen;
            if(idx >= loopEnd){
                uint32_t over = idx - loopEnd;
                idx = s->loopStart + (over % s->loopLen);
                c->posFP = (idx << FP_SHIFT);
            }
        } else {
            if(idx >= s->length){
                c->active = 0;
                continue;
            }
        }

        int32_t smp = (int32_t)s->data[idx]; // -128..127
        int32_t v   = (int32_t)c->vol;
        if(v > 64) v = 64;

        int32_t tv = (int32_t)g_med.trkVol[t & 15];
        if(tv <= 0) tv = 64;
        if(tv > 64) tv = 64;

        int32_t out = (smp << 8);
        out = (out * v)  / 64;
        out = (out * tv) / 64;
        out = (out * mv) / 64;

        if(isRight4[t & 3]) sumR += out;
        else                sumL += out;
    }

    *outL = clamp16(sumL);
    *outR = clamp16(sumR);
}

// ---------------- API ----------------
int playMED_Load(const char *filename, uint32_t outSampleRate){
    memset(&g_med, 0, sizeof(g_med));
    g_med.outRate = outSampleRate ? outSampleRate : 44100;

    if(!load_entire_file(filename)) return 0;
    if(!parse_headers()) return 0;
    printf("MED: bpmMode=%u LPB=%u TPL=%u defTempo=%u => samplesPerTickFP=%u\n",
           g_med.bpmMode, g_med.rowsPerBeat, g_med.ticksPerLine, g_med.defTempo, g_med.samplesPerTickFP);

    if(!load_samples()) return 0;

    reset_player();


    return 1;
}

void playMED_Free(void){
    for(uint32_t i=0;i<MED_MAX_SAMPLES;i++){
        if(g_med.samples[i].data){
            free(g_med.samples[i].data);
            g_med.samples[i].data = NULL;
        }
    }
    if(g_med.file){
        free(g_med.file);
        g_med.file = NULL;
    }
    memset(&g_med, 0, sizeof(g_med));
}


uint32_t RenderMED_Interleaved(int16_t *out, uint32_t frames)
{
    if(!out || frames == 0) return 0;

    if(!g_med.file){
        memset(out, 0, frames * 2u * sizeof(int16_t));
        return frames;
    }

    // samplesPerTickFP is (samples * FP_ONE).
    // tickAccFP accumulates the same unit: (samples * FP_ONE).
    for(uint32_t i=0;i<frames;i++){
        g_med.tickAccFP += FP_ONE;

        // Correct unit: add 1 sample worth in the SAME domain as samplesPerTickFP
        // That is: +FP_ONE per output sample, BUT tickAccFP must be compared to (samples * FP_ONE).
        // So tickAccFP must represent (samples * FP_ONE), not plain FP.
        //
        // => tickAccFP += FP_ONE is fine ONLY if tickAccFP is also (samples*FP_ONE).
        // Your code is fine here — the bug is that recompute_timing() sets samplesPerTickFP too big/small
        // when BPM conversion is wrong. So we hard-fix the actual timing model below.

        while(g_med.tickAccFP >= g_med.samplesPerTickFP){
            g_med.tickAccFP -= g_med.samplesPerTickFP;
            player_tick_advance();
        }

        int16_t L=0, R=0;
        mix_one(&L, &R);

        L >>= 1;
        R >>= 1;

        out[i*2u + 0] = L;
        out[i*2u + 1] = R;
    }

    return frames;
}
