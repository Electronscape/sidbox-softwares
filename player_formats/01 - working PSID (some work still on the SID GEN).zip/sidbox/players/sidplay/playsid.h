#ifndef PLAYSID_H
#define PLAYSID_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <string.h>




typedef struct {
    uint16_t load_addr;
    uint16_t init_addr;
    uint16_t play_addr;
    uint16_t songs;
    uint16_t start_song;
    uint32_t speed;       // v1 speed word (bitfield) - we just store it
    uint16_t data_offset; // where C64 data starts in the file
    uint8_t  is_rsid;
} psid_info_t;


int psid_load_from_bytes(const uint8_t *song, uint32_t song_len, uint8_t ram[65536], psid_info_t *out);




#ifdef __cplusplus
}
#endif


#endif // PLAYSID_H
