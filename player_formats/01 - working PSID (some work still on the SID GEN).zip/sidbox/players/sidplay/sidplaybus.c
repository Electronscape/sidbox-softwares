// cpu6502_test.c
#include <stdio.h>
#include <string.h>
#include <stdint.h>


#include "cpu6502.h"
#include "sid8579.h"
#include "sidplaybus.h"


// ---- simple 64K RAM bus ----
uint8_t ram[65536];

extern sid_t sid;


void clear_ram(void) {
    memset(ram, 0, sizeof(ram));
}

// Write a program at addr, and set reset vector to it.
void load_prog(uint16_t addr, const uint8_t *prog, size_t n) {
    memcpy(&ram[addr], prog, n);
    ram[0xFFFC] = (uint8_t)(addr & 0xFF);
    ram[0xFFFD] = (uint8_t)(addr >> 8);
}


uint8_t bus_read8(void *user, uint16_t addr) {
    (void)user;


    // sid chip io
    if (addr >= 0xD400 && addr <= 0xD41F)
        return sid.reg[addr - 0xD400];

    return ram[addr];
}

void bus_write8(void *user, uint16_t addr, uint8_t v) {
    (void)user;

    if (addr == IO_PUTCHAR) {
        putchar(v);   // print char to host stdout
        fflush(stdout);
        return;
    }

    if (addr >= 0xD400 && addr <= 0xD41F) {
        sid_write(&sid, addr, v);
        return;
    }

    ram[addr] = v;
}
