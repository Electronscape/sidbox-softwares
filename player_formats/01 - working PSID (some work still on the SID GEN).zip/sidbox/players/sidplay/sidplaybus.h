#ifndef SIDPLAYBUS_H
#define SIDPLAYBUS_H

#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif


#define IO_PUTCHAR 0xD020

extern uint8_t ram[];

void clear_ram(void);
void load_prog(uint16_t addr, const uint8_t *prog, size_t n);
uint8_t bus_read8(void *user, uint16_t addr);
void bus_write8(void *user, uint16_t addr, uint8_t v);

#ifdef __cplusplus
}
#endif

#endif // SIDPLAYBUS_H
