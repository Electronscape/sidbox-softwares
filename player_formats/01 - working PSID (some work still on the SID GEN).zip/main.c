#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <alsa/asoundlib.h>


#include "sidbox/players/sidplay/cpu6502.h"
#include "sidbox/players/sidplay/sid8579.h"
#include "sidbox/players/sidplay/sidplaybus.h"
#include "sidbox/players/sidplay/playsid.h"

#include "song.h"

#define PCM_DEVICE "default"

sid_t sid;



static void sleep_for_frames(int frames, int sample_rate) {
    // seconds = frames / rate
    long ns = (long)((1000000000LL * (long long)frames) / sample_rate);
    struct timespec ts = { .tv_sec = 0, .tv_nsec = ns };
    nanosleep(&ts, NULL);
}


static inline void cpu_push8(cpu6502_t *c, uint8_t v) {
    ram[0x0100u | (uint16_t)c->sp] = v;
    c->sp--;
}

static void cpu_call_sub(cpu6502_t *c, uint16_t target, uint16_t ret_addr) {
    // 6502 RTS returns to (pulled+1), and JSR pushes (PC-1).
    // For an external call, push (ret_addr - 1).
    uint16_t retm1 = (uint16_t)(ret_addr - 1);

    cpu_push8(c, (uint8_t)((retm1 >> 8) & 0xFF)); // high first
    cpu_push8(c, (uint8_t)(retm1 & 0xFF));        // then low

    c->pc = target;
}

uint8_t loadfileram[0x10000];


uint32_t loadsidfromfile(char *filename){
    FILE *f;
    uint32_t len;

    if (!filename)
        return 0;

    f = fopen(filename, "rb");
    if (!f)
        return 0;

    fseek(f, 0, SEEK_END);
    len = (uint32_t)ftell(f);
    rewind(f);

    if (len > sizeof(loadfileram))
        len = sizeof(loadfileram);

    fread(loadfileram, 1, len, f);
    fclose(f);

    return len;

}


int main() {
    snd_pcm_t *pcm_handle;
    snd_pcm_hw_params_t *params;
    unsigned int rate = 44100;
    int err;




    ///////////// cpu testing first ///////////////////////////

#if(0)
    int cputestres;
    cputestres = do_cpuTest();  // <-- this is where we were testing the CPU this part might not be needed now
    return cputestres;
#endif
   /////////////////////////////////////////////////////////////

    /* Open PCM device for playback */
    if ((err = snd_pcm_open(&pcm_handle, PCM_DEVICE, SND_PCM_STREAM_PLAYBACK, 0)) < 0) {
        fprintf(stderr, "Error opening PCM device: %s\n", snd_strerror(err));
        return 1;
    }

    /* Set hardware parameters */
    snd_pcm_hw_params_malloc(&params);
    snd_pcm_hw_params_any(pcm_handle, params);
    snd_pcm_hw_params_set_access(pcm_handle, params, SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(pcm_handle, params, SND_PCM_FORMAT_S16_LE);
    snd_pcm_hw_params_set_channels(pcm_handle, params, 2);
    snd_pcm_hw_params_set_rate_near(pcm_handle, params, &rate, 0);
    snd_pcm_hw_params(pcm_handle, params);
    snd_pcm_hw_params_free(params);

    /* Prepare buffer and generate PWM (SID-style) audio */
    int16_t buffer[4096];                         /* stereo interleaved frames */
    int frames_per_write = sizeof(buffer) / 4;    /* 4 bytes per frame: L+R */


    /* Playback duration */
    int total_writes = 40; /* around 4–5 seconds */

    // from here would be were we do the music routine.. I hope
    // this section is NOT finished tho as i build the basics of the sid audio
    // i imagine the code be like this

    // init cpu
    // load song
    // init sid
    // reset cpu to
    // while playing
    //     cycles = cpu_step();
    //     sid_step();
    //     render audio (); <--
           //snd_pcm_sframes_t written = snd_pcm_writei(pcm_handle, buffer, frames_per_write);
    // end while;


    cpu6502_t c;
    cpu6502_bus_t bus = {0};

    bus.user = NULL;
    bus.read8 = bus_read8;
    bus.write8 = bus_write8;
    cpu6502_init(&c, bus);

    uint8_t prog_hardloop[] = {
        0x4C, 0x00, 0x80
    };

    static const uint8_t prog_sid_tone[] = {
        0xA9, 0x0F,       // LDA #$0F
        0x8D, 0x18, 0xD4, // STA $D418  (volume)

        0xA9, 0x00,       // LDA #$00
        0x8D, 0x02, 0xD4, // STA $D402  (PW lo)
        0xA9, 0x08,       // LDA #$08
        0x8D, 0x03, 0xD4, // STA $D403  (PW hi)  -> ~0x0800 (middle-ish)

        0xA9, 0x42,       // LDA #$00
        0x8D, 0x00, 0xD4, // STA $D400  (FREQ lo)
        0xA9, 0x1D,       // LDA #$20
        0x8D, 0x01, 0xD4, // STA $D401  (FREQ hi) -> some pitch

        0xA9, 0x41,       // LDA #$41  (GATE=1 + PULSE=1)
        0x8D, 0x04, 0xD4, // STA $D404  (CTRL)

        0x4C, 0x1E, 0x80  // JMP $801E (loop forever here)
    };

    static const uint8_t prog_sid_tonesweep[] = {
        0xA9, 0x0F,         // LDA #$0f
        0x8D, 0x18, 0xD4,   // STA $D418    ; master vaolume = 15


        0xA9, 0x00,         // LDA #$00
        0x8D, 0x02, 0xD4,   // STA $D402    ; PW low = 00
        0xA9, 0x08,         // LDA #$08
        0x8D, 0x03, 0xD4,   // STA $D403    ; PW hi = 08 -> pw = $0800 (50%);

        0xA9, 0x41,         // LDA #$41
        0x8D, 0x04, 0xD4,   // STA $D404    ; CTRL = GATE(1) + PULSE(1)



        0xA9, 0x00,         // LDA #$00
        0x85, 0x10,         // STA $10      ; freq lo (ZP) = 00
        0xA9, 0x10,         // LDA #$10
        0x85, 0x11,         // STA $11      ; freq hi (ZP) = 10 -> start freq = $1000
        0xA9, 0x00,         // LDA #$00
        0x85, 0x12,         // STA $12      ; dir = 0 (0 = up, 1 = down)

        0xA5, 0x10,         // LDY #$10
        0x8D, 0x00, 0xD4,   // LDX #$FF     ; FREQ lo
        0xA5, 0x11,         // LDA $11
        0x8D, 0x01, 0xD4,   // STA $D401    ; FREQ hi

        0xA0, 0x10,         // LDY #$10
        0xA2, 0xFF,         // LDX #$FF
        0xCA,               // DEX
        0xD0, 0xFD,         // BNE $802E    ; inner loop
        0x88,               // DEY
        0xD0, 0xF8,         // BNE $802C    ; outer loop

        0xA5, 0x12,         // LDA $12      ; directions
        0xD0, 0x22,         // BNE          ; do_down

        // do_up:
        0xA5, 0x10,         // LDA $10
        0x18,               // CLC
        0x69, 0xF8,         // ADC #$F8
        0x85, 0x10,         // STA $10

        0xA5, 0x11,         // LDA $11
        0x69, 0x00,         // ADC #$00     ; add carry from low-byte step
        0x85, 0x11,         // STA $11

        0xA5, 0x11,         // LDA $11
        0xC9, 0x50,         // CMP #$50
        0x90, 0x2E,         // BCC write_freq   ; if hi < $50 keep going up

        // ; else clamp and flip direction
        0xA9, 0x00,         // LDA #$00
        0x85, 0x10,         // STA $10
        0xA9, 0x50,         // LDA #$50
        0x85, 0x11,         // STA $11
        0xA9, 0x01,         // LDA #$01
        0x85, 0x12,         // STA $12      ; dir = down
        0x4C, 0x79, 0x80,   // JMP write_freq

        // do_down:
        0xA5, 0x10,         // LDA $10
        0x38,               // SEC
        0xE9, 0xF8,         // SBC #$F8
        0x85, 0x10,         // STA $10

        0xA5, 0x11,         // LDA $11
        0xE9, 0x00,         // SBC #$00
        0x85, 0x11,         // STA $11

        0xA5, 0x11,         // LDA $11
        0xC9, 0x10,         // CMP #$10
        0xB0, 0x0C,         // BCS write_freq   ; if hi >= $10 keep going down

        // else reset and flip direction up
        0xA9, 0x00,         // LDA #$00
        0x85, 0x10,         // STA $10
        0xA9, 0x10,         // LDA #$10
        0x85, 0x11,         // STA $11
        0xA9, 0x00,         // LDA #$00
        0x85, 0x12,         // STA $12          ; dir = up

        // write_freq
        0xA5, 0x10,         // LDA $10
        0x8D, 0x00, 0xD4,   // STA $D400
        0xA5, 0x11,         // LDA $11
        0x8D, 0x01, 0xD4,   // STA $D401
        0x4C, 0x2A, 0x80    // JMP $802A
    };



    clear_ram();


    psid_info_t ps;
    uint32_t length;
    //int rc = psid_load_from_bytes(Wiklund___Cheese, Wiklund___Cheese_len, ram, &ps);
    //int rc = psid_load_from_bytes(turrican, turrican_len, ram, &ps);

    //length = loadsidfromfile("../../Bionic_Commando(+).sid");
    //length = loadsidfromfile("../../Bionic_Commando(+).sid");
    length = loadsidfromfile("../../Auf_Wiedersehen_Monty.sid");


    int rc = psid_load_from_bytes(loadfileram, length, ram, &ps);
    if (rc != 0) {
        printf("PSID load failed rc=%d\n", rc);
        return 1;
    }

    printf("PSID loaded: load=$%04X init=$%04X play=$%04X songs=%u start=%u\n",
           ps.load_addr, ps.init_addr, ps.play_addr, ps.songs, ps.start_song);


    ram[0x0200] = 0x4C; // JMP abs
    ram[0x0201] = 0x00;
    ram[0x0202] = 0x02; // JMP $0200


    // init song before play :)
    sid_init(&sid, 985248, 44100);
    cpu6502_reset_to(&c, 0x0000);   // we will call INIT via jsr, PC doesn't matter
    c.x = 0;
    c.y = 0;
    //ps.start_song = 5;
    int init_cycles = cpu6502_jsr(&c, ps.init_addr, (uint8_t)((ps.start_song > 0) ? (ps.start_song - 1) : 0));
    sid_step(&sid, (uint32_t)init_cycles);  // kick start the sid chip



    int playing = 1;
    uint32_t writes = 0;

    uint32_t play_period_cycles = sid.sid_hz / 50; // ~19704 for PAL 985248
    uint32_t play_countdown = play_period_cycles;

    while (playing) {

        // how many CPU cycles correspond to one audio buffer worth of time?
        uint32_t cycles_target = (uint32_t)(((uint64_t)sid.sid_hz * (uint64_t)frames_per_write) / (uint64_t)rate);
        uint32_t cycles_done = 0;

        while (cycles_done < cycles_target) {
            int cycles = cpu6502_step(&c);
            if (cycles <= 0) { playing = 0; break; }

            cycles_done += (uint32_t)cycles;
            sid_step(&sid, (uint32_t)cycles);

            // 50Hz play call
            if (play_countdown <= (uint32_t)cycles) {
                play_countdown += play_period_cycles;

                int play_cycles = cpu6502_jsr(&c, ps.play_addr, 0);
                sid_step(&sid, (uint32_t)play_cycles);
            } else {
                play_countdown -= (uint32_t)cycles;
            }
        }

        int frames = sid_render_interleaved(&sid, buffer, frames_per_write);
        snd_pcm_sframes_t written = snd_pcm_writei(pcm_handle, buffer, frames);


        if (written == -EPIPE) {
            snd_pcm_prepare(pcm_handle);
        } else if (written < 0) {
            fprintf(stderr, "Write error: %s\n", snd_strerror((int)written));
            break;
        }
    }

//*/

    snd_pcm_drain(pcm_handle);
    snd_pcm_close(pcm_handle);
    printf("done\n");

    return 0;
}

#if(0)

/* SID-like PWM parameters */
double freq = 440.0;     /* A4 tone */
double lfo_rate = 2.0;   /* 2 Hz duty modulation */
double lfo_depth = 0.35; /* pulse modulation depth */
double base_duty = 0.5;  /* 50% square wave */
double amp = 1600.0;

/* Phase accumulators */
double phase = 0.0;
double lfo_phase = 0.0;
double phase_inc = freq / (double)rate;
double lfo_inc  = lfo_rate / (double)rate;

/* Playback duration */
int total_writes = 40; /* around 4–5 seconds */

for (int w = 0; w < total_writes; ++w) {

    for (int f = 0; f < frames_per_write; ++f) {

        /* LFO (0..1) */
        double lfo = (sin(2.0 * M_PI * lfo_phase) * 0.5) + 0.5;

        /* Modulated duty */
        double duty = base_duty + ((lfo - 0.5) * 2.0 * lfo_depth);
        if (duty < 0.01) duty = 0.01;
        if (duty > 0.99) duty = 0.99;

        /* Pulse wave: +1 or -1 */
        double sample = (phase < duty) ? 1.0 : -1.0;

        /* Soft shaping to reduce harshness */
        sample *= (1.0 - 0.2 * fabs(sample));

        int16_t out = (int16_t)(sample * amp);

        buffer[f * 2 + 0] = out; /* Left */
        buffer[f * 2 + 1] = out; /* Right */

        /* Advance phases */
        phase += phase_inc;
        if (phase >= 1.0) phase -= 1.0;

        lfo_phase += lfo_inc;
        if (lfo_phase >= 1.0) lfo_phase -= 1.0;
    }

    snd_pcm_sframes_t written = snd_pcm_writei(pcm_handle, buffer, frames_per_write);

    if (written == -EPIPE) {
        snd_pcm_prepare(pcm_handle);
    }
    else if (written < 0) {
        fprintf(stderr, "Write error: %s\n", snd_strerror((int)written));
    }
}
#endif
