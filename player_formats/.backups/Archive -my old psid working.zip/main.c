#include <stdio.h>
//#include <stdlib.h>
#include <stdint.h>
//#include <string.h>
//#include <math.h>
//#include <time.h>
#include <alsa/asoundlib.h>


#include "sidbox/players/sidplay/cpu6502.h"
#include "sidbox/players/sidplay/sid8579.h"

#include "sidbox/players/sidplay/bus.h"
#include "sidbox/players/sidplay/playsid.h"


#define PCM_DEVICE "default"


int main(){

    char sidfilename[256];
    uint32_t length;



    snd_pcm_t *pcm_handle;
    snd_pcm_hw_params_t *params;
    unsigned int rate = 44100;
    int err;



    /* Open PCM device for playback */
    if ((err = snd_pcm_open(&pcm_handle, PCM_DEVICE, SND_PCM_STREAM_PLAYBACK, 0)) < 0) {
        fprintf(stderr, "Error opening PCM device: %s\n", snd_strerror(err));
        return 1;
    }
    setvbuf(stdout, NULL, _IONBF, 0);
    /* Set hardware parameters */
    snd_pcm_hw_params_malloc(&params);
    snd_pcm_hw_params_any(pcm_handle, params);
    snd_pcm_hw_params_set_access(pcm_handle, params, SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(pcm_handle, params, SND_PCM_FORMAT_S16_LE);
    snd_pcm_hw_params_set_channels(pcm_handle, params, 2);
    snd_pcm_hw_params_set_rate_near(pcm_handle, params, &rate, 0);
    snd_pcm_hw_params(pcm_handle, params);
    snd_pcm_hw_params_free(params);

    /*
    uint32_t length;
    //length = loadsidfromfile("../../Bionic_Commando(+).sid");
    //length = loadsidfromfile("../../Sonic_the_Hedgehog.sid");
    //length = loadsidfromfile("../../Auf_Wiedersehen_Monty.sid");  // <-- psid, plays fine ;)
    length = loadsidfromfile("../../PayDay-Ingame_tune.sid");
    //length = loadsidfromfile("../../Euro_Trash.sid");

    //length = loadsidfromfile("../../rsid_Chimera.sid"); // <-- RSID - doesnt play :(
    //length = loadsidfromfile("../../rsid_Robox.sid"); // <-- RSID - Actually plays :O
    //length = loadsidfromfile("../../rsid_rooter.sid"); // <-- RSID - doesnt play :(
    //length = loadsidfromfile("../../rsid_rorrol.sid"); // <-- RSID - plays, but does something else
    */

    //sprintf(sidfilename, "../../Auf_Wiedersehen_Monty.sid");
    //sprintf(sidfilename, "../../Sonic_the_Hedgehog.sid");
    //sprintf(sidfilename, "../../PayDay-Ingame_tune.sid");
    sprintf(sidfilename, "../../Euro_Trash.sid");

    if(!PlaySID_Init(sidfilename, -1)){
        printf("Failed to init SID: %s\n", sidfilename);
        snd_pcm_close(pcm_handle);
        return 2;
    }

    /* Prepare buffer and generate PWM (SID-style) audio */
    int16_t buffer[4096];                         /* stereo interleaved frames */

    while(1){   // this will keep looing only because later i'll add stuff to control this later
        // will play the routine here
        // example

        // inside the doPlaySidStep() this does the steps you'll find in the playsid.c and return how many samples, enough to fill the 4096 buffer here
        // change this if you need  but
        //length = doPlaySidStep(buffer);// <-- do what you need here to make this work interleaved buffer output for now

        uint32_t frames = 2;
        doPlaySidStep(buffer, frames);

        snd_pcm_sframes_t written = snd_pcm_writei(pcm_handle, buffer, frames);
        if(written == -EPIPE){
            snd_pcm_prepare(pcm_handle);
        } else if(written < 0){
            fprintf(stderr, "Write error: %s\n", snd_strerror((int)written));
            break;
        }




    }













    snd_pcm_drain(pcm_handle);
    snd_pcm_close(pcm_handle);
    printf("done\n");


    return(42);

}


#if(0)
int main() {
    snd_pcm_t *pcm_handle;
    snd_pcm_hw_params_t *params;
    unsigned int rate = 44100;
    int err;


    /* Open PCM device for playback */
    if ((err = snd_pcm_open(&pcm_handle, PCM_DEVICE, SND_PCM_STREAM_PLAYBACK, 0)) < 0) {
        fprintf(stderr, "Error opening PCM device: %s\n", snd_strerror(err));
        return 1;
    }
    setvbuf(stdout, NULL, _IONBF, 0);



    /* Set hardware parameters */
    snd_pcm_hw_params_malloc(&params);
    snd_pcm_hw_params_any(pcm_handle, params);
    snd_pcm_hw_params_set_access(pcm_handle, params, SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(pcm_handle, params, SND_PCM_FORMAT_S16_LE);
    snd_pcm_hw_params_set_channels(pcm_handle, params, 2);
    snd_pcm_hw_params_set_rate_near(pcm_handle, params, &rate, 0);
    snd_pcm_hw_params(pcm_handle, params);
    snd_pcm_hw_params_free(params);

    /* Prepare buffer and generate PWM (SID-style) audio */
    int16_t buffer[4096];                         /* stereo interleaved frames */
    int frames_per_write = sizeof(buffer) / 4;    /* 4 bytes per frame: L+R */


    //// OUR SID PLAY engine hoist ////////////////////////

                                // WILL need a SID chip instance (i call this 8579 since its not a good sound yet but it DOES make sound)
    cpu6502_t c;                // create the CPU instance
    cpu6502_bus_t bus = {0};    // create the BUS instance

    bus.user = NULL;            // no user code,
    bus.read8 = bus_read8;      // the bus.read8 funciton pointer
    bus.write8 = bus_write8;    // the bus.write8 function pointer


    cpu6502_init(&c, bus);      // init the CPU and it will use THIS BUS

    clear_ram();    /// oh we so need to clear memory






    uint32_t length;
    //length = loadsidfromfile("../../Bionic_Commando(+).sid");
    //length = loadsidfromfile("../../Sonic_the_Hedgehog.sid");
    //length = loadsidfromfile("../../Auf_Wiedersehen_Monty.sid");  // <-- psid, plays fine ;)
    length = loadsidfromfile("../../PayDay-Ingame_tune.sid");
    //length = loadsidfromfile("../../Euro_Trash.sid");

    //length = loadsidfromfile("../../rsid_Chimera.sid"); // <-- RSID - doesnt play :(
    //length = loadsidfromfile("../../rsid_Robox.sid"); // <-- RSID - Actually plays :O
    //length = loadsidfromfile("../../rsid_rooter.sid"); // <-- RSID - doesnt play :(
    //length = loadsidfromfile("../../rsid_rorrol.sid"); // <-- RSID - plays, but does something else


    sid_program_t prg;
    int rc = sid_load_from_bytes(loadfileram, length, ram, &prg);
    if (rc != 0) { /* error */ }

    //vic_set_video(&vic, C64_NTSC );
    int video_mode = sid_pick_video(&prg);     // whatever type sid_pick_video returns (enum/int)
    vic_set_video(&vic, video_mode);


    uint16_t song = prg.start_song ? prg.start_song : 1;

    int uses_cia = psid_song_uses_cia(&prg, song);

    sid_init(&sid, cpuHz, 44100);

#if(0)
    if (prg.fmt == SIDFMT_PSID) {
        // init song before play :)
        cpu6502_init(&c, bus);
        cpu6502_reset_to(&c, 0x0000);   // we will call INIT via jsr, PC doesn't matter
        c.x = 0;
        c.y = 0;
        prg.start_song = 1;
        int init_cycles = cpu6502_jsr(&c, prg.init_addr, (uint8_t)((prg.start_song > 0) ? (prg.start_song - 1) : 0));

        if (prg.fmt == SIDFMT_PSID && uses_cia) { // Put IRQ stub in RAM at $0200 (any free RAM address works)
            const uint16_t IRQ_STUB = 0x0200;
            uint8_t stub[] = {
                0x48,             // PHA
                0x8A, 0x48,       // TXA, PHA
                0x98, 0x48,       // TYA, PHA

                0x20, 0x00, 0x00, // JSR $???? (play)  <-- patch below

                0xAD, 0x0D, 0xDC, // LDA $DC0D  (ACK CIA1 IRQ)
                0xAD, 0x0D, 0xDD,   // LDA

                0x68, 0xA8,       // PLA, TAY
                0x68, 0xAA,       // PLA, TAX
                0x68,             // PLA
                0x40              // RTI
            };

            // Patch the JSR target to prg.play_addr
            stub[6] = (uint8_t)(prg.play_addr & 0xFF);
            stub[7] = (uint8_t)(prg.play_addr >> 8);

            // Copy stub into RAM
            for (unsigned i = 0; i < sizeof(stub); i++) {
                ram[IRQ_STUB + i] = stub[i];
            }

            // Point IRQ vector ($0314/$0315) to our stub
            ram[0x0314] = (uint8_t)(IRQ_STUB & 0xFF);
            ram[0x0315] = (uint8_t)(IRQ_STUB >> 8);

            // Optional: also set BRK vector ($0316/$0317) same place
            ram[0x0316] = (uint8_t)(IRQ_STUB & 0xFF);
            ram[0x0317] = (uint8_t)(IRQ_STUB >> 8);

            ram[0xFFFE] = (uint8_t)(IRQ_STUB & 0xFF);
            ram[0xFFFF] = (uint8_t)(IRQ_STUB >> 8);

            c.p &= (uint8_t)~0x04;   // clear I flag (0x04 is typical for 6502 I bit)

            uint32_t play_hz = 50; // or 60 if NTSC
            uint16_t latch = (uint16_t)(cpuHz / play_hz);
            cia_write(&cia1, 0x04, (uint8_t)(latch & 0xFF)); // TALO
            cia_write(&cia1, 0x05, (uint8_t)(latch >> 8));   // TAHI
            cia_write(&cia1, 0x0D, 0x81);                    // enable Timer A IRQ
            cia_write(&cia1, 0x0E, 0x11);                    // load + start Timer A
            printf("CIA Driven\n");
        }

        sid_step(&sid, (uint32_t)init_cycles);  // kick start the sid chip

        printf("PSID loaded: load=$%04X init=$%04X play=$%04X songs=%u start=%u\n", prg.load_addr, prg.init_addr, prg.play_addr, prg.songs, prg.start_song);

    } else {
        // RSID: do NOT call play from host loop.
        cpu6502_init(&c, bus);
        cpu6502_reset(&c);
    }
#endif



    int playing = 1;
    uint32_t writes = 0;

    uint32_t play_hz = 50;// HARD CODED FOR NOW (video_mode == C64_NTSC) ? 60u : 50u;
    uint32_t play_period_cycles = sid.sid_hz / play_hz;
    uint32_t play_countdown = play_period_cycles;


    while (playing) {

        // how many CPU cycles correspond to one audio buffer worth of time?
        uint32_t cycles_target = (uint32_t)(((uint64_t)sid.sid_hz * (uint64_t)frames_per_write) / (uint64_t)rate);
        uint32_t cycles_done = 0;

        writes++;
        static uint32_t irq_hits = 0;
        int cycles;

        int play_cycles;

        while (cycles_done < cycles_target){
            if(prg.fmt == SIDFMT_PSID){ /// PSID SECTION ONLY
                if (!uses_cia) {
                    uint32_t remaining = cycles_target - cycles_done;
                    uint32_t slice = remaining;
                    if (slice > play_countdown) slice = play_countdown;
                    cycles = cpu6502_run(&c, (int)slice);
                    if (cycles <= 0) { playing = 0; break; }
                    cycles_done += (uint32_t)cycles;
                    if (play_countdown <= (uint32_t)cycles) {
                        play_countdown = play_period_cycles;
                        int play_cycles = cpu6502_jsr(&c, prg.play_addr, 0);
                        if (play_cycles <= 0) { playing = 0; break; }
                        //sid_step(&sid, (uint32_t)play_cycles);
                        cycles_done += (uint32_t)play_cycles;
                    } else {
                        play_countdown -= (uint32_t)cycles;
                    }
                }
                if(uses_cia){   // PSID in CIA TIMER MODE
                    cycles = cpu6502_run(&c, 880);
                    if (cycles <= 0) { playing = 0; break; }
                    cia_tick(&cia1, (uint32_t)cycles);
                    cia_tick(&cia2, (uint32_t)cycles);
                    vic_tick(&vic, (uint32_t)cycles);

                    uint8_t irq_level = (cia1.irq_level || vic.irq_line) ? 1 : 0;
                    cpu6502_irq(&c, irq_level);
                    cpu6502_nmi(&c, cia2.irq_level ? 1 : 0);
                }


            } else {    /// RSID AREA
                cycles = cpu6502_step(&c);

                // for RSID use
                cia_tick(&cia1, (uint32_t)cycles);
                cia_tick(&cia2, (uint32_t)cycles);
                vic_tick(&vic,  (uint32_t)cycles);
                uint8_t irq_level = (cia1.irq_level || vic.irq_line) ? 1 : 0;
                cpu6502_irq(&c, irq_level);
                cpu6502_nmi(&c, cia2.irq_level ? 1 : 0);    // this internally latches
            }


            if (cycles <= 0) { playing = 0; break; }
            cycles_done += (uint32_t)cycles;
            sid_step(&sid, (uint32_t)cycles);
        }


        int frames = sid_render_interleaved(&sid, buffer, frames_per_write);
        snd_pcm_sframes_t written = snd_pcm_writei(pcm_handle, buffer, frames);


        if (written == -EPIPE) {
            snd_pcm_prepare(pcm_handle);
        } else if (written < 0) {
            fprintf(stderr, "Write error: %s\n", snd_strerror((int)written));
            break;
        }
    }

//*/

    snd_pcm_drain(pcm_handle);
    snd_pcm_close(pcm_handle);
    printf("done\n");

    return 0;
}
#endif
