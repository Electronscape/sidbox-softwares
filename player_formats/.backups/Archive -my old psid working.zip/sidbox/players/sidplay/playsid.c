#include "playsid.h"
#include "bus.h"
#include "cpu6502.h"
#include "sid8579.h"

#include <stdio.h>
#include <string.h>

static word load_addr, init_addr, play_addr;
static byte subsongs, startsong, speed;
static long ticks = 0;
static unsigned long nRefreshCIA = 20000;
static int mixing_frequency = 44100;

// crude "timekeeping"
static long timeplay = 0;

// PSID loader
static int LoadSIDFromFile(const char *filename){
    FILE *f = fopen(filename, "rb");
    if(!f) return 0;

    uint8_t hdr[124];
    if(fread(hdr, 1, 124, f) != 124){
        fclose(f);
        return 0;
    }

    // PSID header:
    // 0..3 "PSID"/"RSID"
    // 6..7 dataOffset (big endian)
    // 8..9 loadAddr
    // 10..11 initAddr
    // 12..13 playAddr
    // 14..15 songs
    // 16..17 startSong
    // 18..21 speed (v2 uses flags; we keep your 0x15 usage style loosely)
    uint16_t dataOffset = rd_u16be(&hdr[6]);
    load_addr  = rd_u16be(&hdr[8]);
    init_addr  = rd_u16be(&hdr[10]);
    play_addr  = rd_u16be(&hdr[12]);
    subsongs   = (byte)(rd_u16be(&hdr[14]) - 1);
    startsong  = (byte)(rd_u16be(&hdr[16]) - 1);

    // your old code used pData[0x15] (which is in first 128 bytes region)
    // Here we approximate speed using the first byte of the speed word.
    speed = hdr[0x15];

    // if load_addr==0 -> first two bytes of data are load address (little endian)
    // seek to dataOffset
    fseek(f, dataOffset, SEEK_SET);

    if(load_addr == 0){
        uint8_t lo = (uint8_t)fgetc(f);
        uint8_t hi = (uint8_t)fgetc(f);
        load_addr = (word)(lo | (hi << 8));
    }

    // load the rest into C64 RAM
    uint32_t addr = load_addr;
    int c;
    while((c = fgetc(f)) != EOF){
        SetMem((uint16_t)addr, (uint8_t)c);
        addr = (addr + 1) & 0xFFFF;
    }

    fclose(f);

    // if play_addr == 0, call init and read IRQ vector ($0314/5) like your original
    if(play_addr == 0){
        cpuJSR(init_addr, 0);
        play_addr = (word)((GetMem(0x0315) << 8) | GetMem(0x0314));
    }
    return 1;
}

static void c64Init(void){
    clear64KRam();
    restartSidChipModes();
    synth_init((uint32_t)mixing_frequency);
    cpuReset();

    // volume poke like your code (both chips)
    SetMem(0xD418, 15);
    SetMem(0xD438, 15);
}

int PlaySID_Init(const char *filename, int subsong){
    c64Init();

    if(!LoadSIDFromFile(filename)){
        fprintf(stderr, "PlaySID_Init: failed loading %s\n", filename);
        return 0;
    }

    if(subsong < 0) subsong = startsong;

    ticks = 0;
    timeplay = 0;

    cpuJSR(init_addr, (byte)subsong);
    synth_start(); // prime osc/filter based on regs after init

    return 1;
}

// Your STM32 version derived ticks from CIA timer ($DC04/$DC05) after play call.
// We'll do the same: after cpuJSR(play_addr,0), read those bytes from memory.
// If zero => default 20000us => ~50Hz.
static inline void refresh_ticks_from_cia(void){
    int gm1 = GetMem(0xDC04);
    int gm2 = GetMem(0xDC05);
    unsigned long cia = (unsigned long)(gm1 | (256L * gm2));
    nRefreshCIA = (unsigned long)(20000UL * cia / 0x4C00);

    if(nRefreshCIA == 0 || speed == 0) nRefreshCIA = 20000UL;
    ticks = (long)((mixing_frequency * nRefreshCIA) / 1000000UL);
    if(ticks <= 0) ticks = (mixing_frequency / 50);
}

// Fill ALSA interleaved buffer
uint32_t doPlaySidStep(int16_t *out_interleaved, uint32_t frames){
    if(!out_interleaved || frames == 0) return 0;

    for(uint32_t i=0; i<frames; i++){
        if(ticks <= 0){
            cpuJSR(play_addr, 0);
            refresh_ticks_from_cia();
            synth_start();
        }

        int16_t L, R;
        sid_render_sample(&L, &R);

        out_interleaved[i*2 + 0] = L;
        out_interleaved[i*2 + 1] = R;

        ticks--;
        timeplay++;
    }
    return frames;
}
