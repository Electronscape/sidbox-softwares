#ifndef SIDPLAYBUS_H
#define SIDPLAYBUS_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// --- Global C64 RAM (KEEP GLOBAL, per your request) ---
extern uint8_t C64RAM[65536];

#pragma once
#include <stdint.h>

uint8_t  bus_read8(uint16_t addr);
void     bus_write8(uint16_t addr, uint8_t v);

uint16_t bus_read16(uint16_t addr);          // normal little-endian
uint16_t bus_read16_wrap(uint16_t addr);     // 6502 JMP($xxFF) wrap bug

// Optional legacy aliases (keep your old code compiling)
static inline uint8_t  GetMem(uint16_t a)        { return bus_read8(a); }
static inline void     SetMem(uint16_t a,uint8_t v){ bus_write8(a,v); }
static inline uint16_t GetMem16(uint16_t a)      { return bus_read16(a); }
static inline void     SetMem16(uint16_t a,uint8_t v){ bus_write8(a,v); } // (your old SetMem16 was odd anyway)



void clear64KRam(void);

// SID I/O mapping
// (sid8579 hooks these)
uint8_t bus_read8(uint16_t addr);
void    bus_write8(uint16_t addr, uint8_t v);

// Optional: helpers for PSID loader
static inline uint16_t rd_u16be(const uint8_t *p){ return (uint16_t)(p[0] << 8) | p[1]; }

#ifdef __cplusplus
}
#endif
#endif
