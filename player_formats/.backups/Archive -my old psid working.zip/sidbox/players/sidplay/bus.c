#include "bus.h"
#include "sid8579.h"
#include <string.h>

uint8_t C64RAM[65536];

void clear64KRam(void){
    memset(C64RAM, 0, sizeof(C64RAM));
}

uint8_t bus_read8(uint16_t addr){
    // For now: pure RAM reads.
    // Later: intercept CIA/VIC reads here (RSID needs it).
    return C64RAM[addr];
}

void bus_write8(uint16_t addr, uint8_t v){
    // Always write underlying RAM (matches C64 "writes under ROM" philosophy)
    C64RAM[addr] = v;

    // SID regions:
    // $D400-$D41F (SID1)
    if ((addr >= 0xD400) && (addr <= 0xD41F)) {
        sid_write(0, (uint8_t)(addr & 0x1F), v);
        return;
    }

    // $D420-$D43F (SID2 / "second SID block")
    if ((addr >= 0xD420) && (addr <= 0xD43F)) {
        // Important: pass reg in the same 0..63 scheme your old code expects
        // (reg>=32 selects chip) — so we give 0x20..0x3F here.
        sid_write(1, (uint8_t)(0x20 + (addr & 0x1F)), v);
        return;
    }

    // Later: CIA/VIC writes here
}

uint16_t bus_read16(uint16_t addr){
    uint8_t lo = bus_read8(addr);
    uint8_t hi = bus_read8((uint16_t)(addr + 1));
    return (uint16_t)(lo | ((uint16_t)hi << 8));
}

// 6502 JMP (indirect) bug: wraps high-byte fetch within the same page
uint16_t bus_read16_wrap(uint16_t addr){
    uint8_t lo = bus_read8(addr);
    uint16_t addr2 = (uint16_t)((addr & 0xFF00) | ((addr + 1) & 0x00FF));
    uint8_t hi = bus_read8(addr2);
    return (uint16_t)(lo | ((uint16_t)hi << 8));
}
