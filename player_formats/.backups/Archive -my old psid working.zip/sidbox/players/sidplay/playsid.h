#ifndef PLAYSID_H
#define PLAYSID_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// Init + load PSID
int PlaySID_Init(const char *filename, int subsong /* -1 = default */);

// Fill interleaved stereo buffer (S16_LE)
// frames = number of stereo frames requested
// returns frames actually written
uint32_t doPlaySidStep(int16_t *out_interleaved, uint32_t frames);

#ifdef __cplusplus
}
#endif
#endif
