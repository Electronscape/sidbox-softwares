#include "cpu6502.h"
#include "bus.h"

// flags (match your sidplay.h style)
#define sFLAG_N 128
#define sFLAG_V 64
#define sFLAG_B 16
#define sFLAG_D 8
#define sFLAG_I 4
#define sFLAG_Z 2
#define sFLAG_C 1

// --- Opcode enum (yours) ---
__attribute__((const))
const enum {
    op_adc, op_and, op_asl, op_bcc, op_bcs, op_beq, op_bit, op_bmi, op_bne, op_bpl, op_brk, op_bvc, op_bvs, op_clc,
    op_cld, op_cli, op_clv, op_cmp, op_cpx, op_cpy, op_dec, op_dex, op_dey, op_eor, op_inc, op_inx, op_iny, op_jmp,
    op_jsr, op_lda, op_ldx, op_ldy, op_lsr, op_nop, op_ora, op_pha, op_php, op_pla, op_plp, op_rol, op_ror, op_rti,
    op_rts, op_sbc, op_sec, op_sed, op_sei, op_sta, op_stx, op_sty, op_tax, op_tay, op_tsx, op_txa, op_txs, op_tya,
    op_xxx
};

// addressing modes (yours)
#define op_imp  0
#define op_imm  1
#define op_abs  2
#define op_absx 3
#define op_absy 4
#define op_zp   6
#define op_zpx  7
#define op_zpy  8
#define op_ind  9
#define op_indx 10
#define op_indy 11
#define op_acc  12
#define op_rel  13

// opcode tables (your pasted ones)
static const byte opcodes[256] = {
    op_brk, op_ora, op_xxx, op_xxx, op_xxx, op_ora, op_asl, op_xxx, op_php, op_ora, op_asl, op_xxx, op_xxx, op_ora, op_asl, op_xxx,
    op_bpl, op_ora, op_xxx, op_xxx, op_xxx, op_ora, op_asl, op_xxx, op_clc, op_ora, op_xxx, op_xxx, op_xxx, op_ora, op_asl, op_xxx,
    op_jsr, op_and, op_xxx, op_xxx, op_bit, op_and, op_rol, op_xxx, op_plp, op_and, op_rol, op_xxx, op_bit, op_and, op_rol, op_xxx,
    op_bmi, op_and, op_xxx, op_xxx, op_xxx, op_and, op_rol, op_xxx, op_sec, op_and, op_xxx, op_xxx, op_xxx, op_and, op_rol, op_xxx,
    op_rti, op_eor, op_xxx, op_xxx, op_xxx, op_eor, op_lsr, op_xxx, op_pha, op_eor, op_lsr, op_xxx, op_jmp, op_eor, op_lsr, op_xxx,
    op_bvc, op_eor, op_xxx, op_xxx, op_xxx, op_eor, op_lsr, op_xxx, op_cli, op_eor, op_xxx, op_xxx, op_xxx, op_eor, op_lsr, op_xxx,
    op_rts, op_adc, op_xxx, op_xxx, op_xxx, op_adc, op_ror, op_xxx, op_pla, op_adc, op_ror, op_xxx, op_jmp, op_adc, op_ror, op_xxx,
    op_bvs, op_adc, op_xxx, op_xxx, op_xxx, op_adc, op_ror, op_xxx, op_sei, op_adc, op_xxx, op_xxx, op_xxx, op_adc, op_ror, op_xxx,
    op_xxx, op_sta, op_xxx, op_xxx, op_sty, op_sta, op_stx, op_xxx, op_dey, op_xxx, op_txa, op_xxx, op_sty, op_sta, op_stx, op_xxx,
    op_bcc, op_sta, op_xxx, op_xxx, op_sty, op_sta, op_stx, op_xxx, op_tya, op_sta, op_txs, op_xxx, op_xxx, op_sta, op_xxx, op_xxx,
    op_ldy, op_lda, op_ldx, op_xxx, op_ldy, op_lda, op_ldx, op_xxx, op_tay, op_lda, op_tax, op_xxx, op_ldy, op_lda, op_ldx, op_xxx,
    op_bcs, op_lda, op_xxx, op_xxx, op_ldy, op_lda, op_ldx, op_xxx, op_clv, op_lda, op_tsx, op_xxx, op_ldy, op_lda, op_ldx, op_xxx,
    op_cpy, op_cmp, op_xxx, op_xxx, op_cpy, op_cmp, op_dec, op_xxx, op_iny, op_cmp, op_dex, op_xxx, op_cpy, op_cmp, op_dec, op_xxx,
    op_bne, op_cmp, op_xxx, op_xxx, op_xxx, op_cmp, op_dec, op_xxx, op_cld, op_cmp, op_xxx, op_xxx, op_xxx, op_cmp, op_dec, op_xxx,
    op_cpx, op_sbc, op_xxx, op_xxx, op_cpx, op_sbc, op_inc, op_xxx, op_inx, op_sbc, op_nop, op_xxx, op_cpx, op_sbc, op_inc, op_xxx,
    op_beq, op_sbc, op_xxx, op_xxx, op_xxx, op_sbc, op_inc, op_xxx, op_sed, op_sbc, op_xxx, op_xxx, op_xxx, op_sbc, op_inc, op_xxx
};

static const byte modes[256] = {
    op_imp, op_indx, op_xxx, op_xxx, op_zp, op_zp, op_zp, op_xxx, op_imp, op_imm, op_acc, op_xxx, op_abs, op_abs, op_abs, op_xxx,
    op_rel, op_indy, op_xxx, op_xxx, op_xxx, op_zpx, op_zpx, op_xxx, op_imp, op_absy, op_xxx, op_xxx, op_xxx, op_absx, op_absx, op_xxx,
    op_abs, op_indx, op_xxx, op_xxx, op_zp, op_zp, op_zp, op_xxx, op_imp, op_imm, op_acc, op_xxx, op_abs, op_abs, op_abs, op_xxx,
    op_rel, op_indy, op_xxx, op_xxx, op_xxx, op_zpx, op_zpx, op_xxx, op_imp, op_absy, op_xxx, op_xxx, op_xxx, op_absx, op_absx, op_xxx,
    op_imp, op_indx, op_xxx, op_xxx, op_zp, op_zp, op_zp, op_xxx, op_imp, op_imm, op_acc, op_xxx, op_abs, op_abs, op_abs, op_xxx,
    op_rel, op_indy, op_xxx, op_xxx, op_xxx, op_zpx, op_zpx, op_xxx, op_imp, op_absy, op_xxx, op_xxx, op_xxx, op_absx, op_absx, op_xxx,
    op_imp, op_indx, op_xxx, op_xxx, op_zp, op_zp, op_zp, op_xxx, op_imp, op_imm, op_acc, op_xxx, op_ind, op_abs, op_abs, op_xxx,
    op_rel, op_indy, op_xxx, op_xxx, op_xxx, op_zpx, op_zpx, op_xxx, op_imp, op_absy, op_xxx, op_xxx, op_xxx, op_absx, op_absx, op_xxx,
    op_imm, op_indx, op_xxx, op_xxx, op_zp, op_zp, op_zp, op_xxx, op_imp, op_imm, op_acc, op_xxx, op_abs, op_abs, op_abs, op_xxx,
    op_rel, op_indy, op_xxx, op_xxx, op_zpx, op_zpx, op_zpy, op_xxx, op_imp, op_absy, op_acc, op_xxx, op_xxx, op_absx, op_absx, op_xxx,
    op_imm, op_indx, op_imm, op_xxx, op_zp, op_zp, op_zp, op_xxx, op_imp, op_imm, op_acc, op_xxx, op_abs, op_abs, op_abs, op_xxx,
    op_rel, op_indy, op_xxx, op_xxx, op_zpx, op_zpx, op_zpy, op_xxx, op_imp, op_absy, op_acc, op_xxx, op_absx, op_absx, op_absy, op_xxx,
    op_imm, op_indx, op_xxx, op_xxx, op_zp, op_zp, op_zp, op_xxx, op_imp, op_imm, op_acc, op_xxx, op_abs, op_abs, op_abs, op_xxx,
    op_rel, op_indy, op_xxx, op_xxx, op_zpx, op_zpx, op_zpx, op_xxx, op_imp, op_absy, op_acc, op_xxx, op_xxx, op_absx, op_absx, op_xxx,
    op_imm, op_indx, op_xxx, op_xxx, op_zp, op_zp, op_zp, op_xxx, op_imp, op_imm, op_acc, op_xxx, op_abs, op_abs, op_abs, op_xxx,
    op_rel, op_indy, op_xxx, op_xxx, op_zpx, op_zpx, op_zpx, op_xxx, op_imp, op_absy, op_acc, op_xxx, op_xxx, op_absx, op_absx, op_xxx
};

// CPU state
static int cycles;
static byte bval;
static word wval;

static byte a, x, y, s, p;
static word pc;

static inline byte mem_read(word addr){
    return bus_read8((uint16_t)addr);
}
static inline void mem_write(word addr, byte v){
    bus_write8((uint16_t)addr, v);
}

static byte getmem(word addr){ return mem_read(addr); }
static void setmem(word addr, byte v){ mem_write(addr, v); }

// addressing helpers
static byte getaddr(int mode){
    word ad, ad2;
    switch(mode){
    case op_imp:  cycles += 2; return 0;
    case op_imm:  cycles += 2; return getmem(pc++);
    case op_abs:  cycles += 4; ad = getmem(pc++); ad |= (word)(getmem(pc++) << 8); return getmem(ad);
    case op_absx: cycles += 4; ad = getmem(pc++); ad |= (word)(getmem(pc++) << 8); ad2 = (word)(ad + x); if((ad2 & 0xff00) != (ad & 0xff00)) cycles++; return getmem(ad2);
    case op_absy: cycles += 4; ad = getmem(pc++); ad |= (word)(getmem(pc++) << 8); ad2 = (word)(ad + y); if((ad2 & 0xff00) != (ad & 0xff00)) cycles++; return getmem(ad2);
    case op_zp:   cycles += 3; ad = getmem(pc++); return getmem(ad);
    case op_zpx:  cycles += 4; ad = (word)(getmem(pc++) + x); return getmem(ad & 0xff);
    case op_zpy:  cycles += 4; ad = (word)(getmem(pc++) + y); return getmem(ad & 0xff);
    case op_indx: cycles += 6; ad = (word)(getmem(pc++) + x); ad2 = getmem(ad & 0xff); ad++; ad2 |= (word)(getmem(ad & 0xff) << 8); return getmem(ad2);
    case op_indy: cycles += 5; ad = getmem(pc++); ad2 = getmem(ad); ad2 |= (word)(getmem((ad + 1) & 0xff) << 8); ad = (word)(ad2 + y); if((ad2 & 0xff00) != (ad & 0xff00)) cycles++; return getmem(ad);
    case op_acc:  cycles += 2; return a;
    }
    return 0;
}

static void setaddr(int mode, byte val){
    word ad, ad2;
    switch(mode){
    case op_abs:
        cycles += 2;
        ad = getmem(pc - 2); ad |= (word)(getmem(pc - 1) << 8);
        setmem(ad, val); return;
    case op_absx:
        cycles += 3;
        ad = getmem(pc - 2); ad |= (word)(getmem(pc - 1) << 8);
        ad2 = (word)(ad + x);
        if((ad2 & 0xff00) != (ad & 0xff00)) cycles--;
        setmem(ad2, val); return;
    case op_zp:
        cycles += 2; ad = getmem(pc - 1); setmem(ad, val); return;
    case op_zpx:
        cycles += 2; ad = (word)(getmem(pc - 1) + x); setmem(ad & 0xff, val); return;
    case op_acc:
        a = val; return;
    }
}

static void putaddr(int mode, byte val){
    word ad, ad2;
    switch(mode){
    case op_abs:  cycles += 4; ad = getmem(pc++); ad |= (word)(getmem(pc++) << 8); setmem(ad, val); return;
    case op_absx: cycles += 4; ad = getmem(pc++); ad |= (word)(getmem(pc++) << 8); ad2 = (word)(ad + x); setmem(ad2, val); return;
    case op_absy: cycles += 4; ad = getmem(pc++); ad |= (word)(getmem(pc++) << 8); ad2 = (word)(ad + y); if((ad2 & 0xff00) != (ad & 0xff00)) cycles++; setmem(ad2, val); return;
    case op_zp:   cycles += 3; ad = getmem(pc++); setmem(ad, val); return;
    case op_zpx:  cycles += 4; ad = (word)(getmem(pc++) + x); setmem(ad & 0xff, val); return;
    case op_zpy:  cycles += 4; ad = (word)(getmem(pc++) + y); setmem(ad & 0xff, val); return;
    case op_indx: cycles += 6; ad = (word)(getmem(pc++) + x); ad2 = getmem(ad & 0xff); ad++; ad2 |= (word)(getmem(ad & 0xff) << 8); setmem(ad2, val); return;
    case op_indy: cycles += 5; ad = getmem(pc++); ad2 = getmem(ad); ad2 |= (word)(getmem((ad + 1) & 0xff) << 8); ad = (word)(ad2 + y); setmem(ad, val); return;
    case op_acc:  cycles += 2; a = val; return;
    }
}

static inline void setflags(int flag, int cond){
    if(cond) p |= (byte)flag;
    else     p &= (byte)~flag;
}
static inline void push(byte val){
    setmem((word)(0x100 + s), val);
    if(s) s--;
}
static inline byte pop(void){
    if(s < 0xff) s++;
    return getmem((word)(0x100 + s));
}
static void branch(int flag){
    signed char dist = (signed char)getaddr(op_imm);
    wval = (word)(pc + dist);
    if(flag){
        cycles += ((pc & 0x100) != (wval & 0x100)) ? 2 : 1;
        pc = wval;
    }
}

void cpuReset(void){
    a = x = y = 0;
    p = 0;
    s = 255;
    pc = bus_read16(0xfffc);
}
void cpuResetTo(word npc){
    a = x = y = 0;
    p = 0;
    s = 255;
    pc = npc;
}

// Execute ONE opcode, return cycles consumed by that opcode.
// Returns 0 if CPU is halted (pc==0).
int cpuStep(void){
    if (!pc) return 0;

    int cycles_before = cycles;

    byte opc = getmem(pc++);
    int cmd  = opcodes[opc];
    int addr = modes[opc];
    int c;

    switch(cmd){
    case op_adc:
        wval = (word)((unsigned short)a + getaddr(addr) + ((p & sFLAG_C) ? 1 : 0));
        setflags(sFLAG_C, wval & 0x100);
        a = (byte)wval;
        setflags(sFLAG_Z, !a);
        setflags(sFLAG_N, a & 0x80);
        setflags(sFLAG_V, (!!(p & sFLAG_C)) ^ (!!(p & sFLAG_N)));
        break;

    case op_and:
        bval = getaddr(addr); a &= bval;
        setflags(sFLAG_Z, !a); setflags(sFLAG_N, a & 0x80);
        break;

    case op_asl:
        wval = getaddr(addr); wval <<= 1;
        setaddr(addr, (byte)wval);
        setflags(sFLAG_Z, !wval); setflags(sFLAG_N, wval & 0x80); setflags(sFLAG_C, wval & 0x100);
        break;

    case op_bcc: branch(!(p & sFLAG_C)); break;
    case op_bcs: branch( (p & sFLAG_C)); break;
    case op_bne: branch(!(p & sFLAG_Z)); break;
    case op_beq: branch( (p & sFLAG_Z)); break;
    case op_bpl: branch(!(p & sFLAG_N)); break;
    case op_bmi: branch( (p & sFLAG_N)); break;
    case op_bvc: branch(!(p & sFLAG_V)); break;
    case op_bvs: branch( (p & sFLAG_V)); break;

    case op_bit:
        bval = getaddr(addr);
        setflags(sFLAG_Z, !(a & bval));
        setflags(sFLAG_N, bval & 0x80);
        setflags(sFLAG_V, bval & 0x40);
        break;

    case op_brk:
        pc = 0; // exit emulation loop
        break;

    case op_clc: setflags(sFLAG_C, 0); break;
    case op_cld: setflags(sFLAG_D, 0); break;
    case op_cli: setflags(sFLAG_I, 0); break;
    case op_clv: setflags(sFLAG_V, 0); break;

    case op_cmp:
        bval = getaddr(addr);
        wval = (word)((unsigned short)a - bval);
        setflags(sFLAG_Z, !wval);
        setflags(sFLAG_N, wval & 0x80);
        setflags(sFLAG_C, a >= bval);
        break;

    case op_cpx:
        bval = getaddr(addr);
        wval = (word)((unsigned short)x - bval);
        setflags(sFLAG_Z, !wval);
        setflags(sFLAG_N, wval & 0x80);
        setflags(sFLAG_C, x >= bval);
        break;

    case op_cpy:
        bval = getaddr(addr);
        wval = (word)((unsigned short)y - bval);
        setflags(sFLAG_Z, !wval);
        setflags(sFLAG_N, wval & 0x80);
        setflags(sFLAG_C, y >= bval);
        break;

    case op_dec:
        bval = getaddr(addr); bval--;
        setaddr(addr, bval);
        setflags(sFLAG_Z, !bval); setflags(sFLAG_N, bval & 0x80);
        break;

    case op_dex:
        x--; setflags(sFLAG_Z, !x); setflags(sFLAG_N, x & 0x80);
        break;

    case op_dey:
        y--; setflags(sFLAG_Z, !y); setflags(sFLAG_N, y & 0x80);
        break;

    case op_eor:
        bval = getaddr(addr); a ^= bval;
        setflags(sFLAG_Z, !a); setflags(sFLAG_N, a & 0x80);
        break;

    case op_inc:
        bval = getaddr(addr); bval++;
        setaddr(addr, bval);
        setflags(sFLAG_Z, !bval); setflags(sFLAG_N, bval & 0x80);
        break;

    case op_inx:
        x++; setflags(sFLAG_Z, !x); setflags(sFLAG_N, x & 0x80);
        break;

    case op_iny:
        y++; setflags(sFLAG_Z, !y); setflags(sFLAG_N, y & 0x80);
        break;

    case op_jmp:
        wval = getmem(pc++);
        wval |= (word)(getmem(pc++) << 8);
        if(addr == op_abs)
            pc = wval;
        else {
            word ptr = wval;
            byte lo = getmem(ptr);
            word ptr_hi = (word)((ptr & 0xFF00) | ((ptr + 1) & 0x00FF));  // wrap within page
            byte hi = getmem(ptr_hi);
            pc = (word)(lo | ((word)hi << 8));

        }
        break;

    case op_jsr:
        push((byte)((pc + 1) >> 8));
        push((byte)(pc + 1));
        wval = getmem(pc++); wval |= (word)(getmem(pc++) << 8);
        pc = wval;
        break;

    case op_lda:
        a = getaddr(addr);
        setflags(sFLAG_Z, !a); setflags(sFLAG_N, a & 0x80);
        break;

    case op_ldx:
        x = getaddr(addr);
        setflags(sFLAG_Z, !x); setflags(sFLAG_N, x & 0x80);
        break;

    case op_ldy:
        y = getaddr(addr);
        setflags(sFLAG_Z, !y); setflags(sFLAG_N, y & 0x80);
        break;

    case op_lsr:
        bval = getaddr(addr);
        wval = bval; wval >>= 1;
        setaddr(addr, (byte)wval);
        setflags(sFLAG_Z, !wval);
        setflags(sFLAG_N, wval & 0x80);
        setflags(sFLAG_C, bval & 1);
        break;

    case op_nop:
        // IMPORTANT: NOP still costs cycles via addressing mode (implied = 2)
        // Your tables mark NOP as implied, so getaddr isn't called.
        // So we must add the 2 cycles here.
        cycles += 2;
        break;

    case op_ora:
        bval = getaddr(addr); a |= bval;
        setflags(sFLAG_Z, !a); setflags(sFLAG_N, a & 0x80);
        break;

    case op_pha: cycles += 3; push(a); break;  // stack ops have fixed timing (see note below)
    case op_php: cycles += 3; push(p); break;

    case op_pla:
        cycles += 4;
        a = pop();
        setflags(sFLAG_Z, !a); setflags(sFLAG_N, a & 0x80);
        break;

    case op_plp: cycles += 4; p = pop(); break;

    case op_rol:
        bval = getaddr(addr);
        c = !!(p & sFLAG_C);
        setflags(sFLAG_C, bval & 0x80);
        bval <<= 1; bval |= (byte)c;
        setaddr(addr, bval);
        setflags(sFLAG_N, bval & 0x80);
        setflags(sFLAG_Z, !bval);
        break;

    case op_ror:
        bval = getaddr(addr);
        c = !!(p & sFLAG_C);
        setflags(sFLAG_C, bval & 1);
        bval >>= 1; bval |= (byte)(128 * c);
        setaddr(addr, bval);
        setflags(sFLAG_N, bval & 0x80);
        setflags(sFLAG_Z, !bval);
        break;

    case op_rti:
        // Treat RTI like RTS (your original simplification)
    case op_rts:
        cycles += 6;
        wval = pop();
        wval |= (word)(pop() << 8);
        pc = (word)(wval + 1);
        break;

    case op_sbc:
        bval = (byte)(getaddr(addr) ^ 0xff);
        wval = (word)((unsigned short)a + bval + ((p & sFLAG_C) ? 1 : 0));
        setflags(sFLAG_C, wval & 0x100);
        a = (byte)wval;
        setflags(sFLAG_Z, !a);
        setflags(sFLAG_N, a > 127);
        setflags(sFLAG_V, (!!(p & sFLAG_C)) ^ (!!(p & sFLAG_N)));
        break;

    case op_sec: cycles += 2; setflags(sFLAG_C, 1); break;
    case op_sed: cycles += 2; setflags(sFLAG_D, 1); break;
    case op_sei: cycles += 2; setflags(sFLAG_I, 1); break;

    case op_sta: putaddr(addr, a); break;
    case op_stx: putaddr(addr, x); break;
    case op_sty: putaddr(addr, y); break;

    case op_tax: cycles += 2; x = a; setflags(sFLAG_Z, !x); setflags(sFLAG_N, x & 0x80); break;
    case op_tay: cycles += 2; y = a; setflags(sFLAG_Z, !y); setflags(sFLAG_N, y & 0x80); break;
    case op_tsx: cycles += 2; x = s; setflags(sFLAG_Z, !x); setflags(sFLAG_N, x & 0x80); break;
    case op_txa: cycles += 2; a = x; setflags(sFLAG_Z, !a); setflags(sFLAG_N, a & 0x80); break;
    case op_txs: cycles += 2; s = x; break;
    case op_tya: cycles += 2; a = y; setflags(sFLAG_Z, !a); setflags(sFLAG_N, a & 0x80); break;

    default:
        // Unsupported opcode: treat as NOP-ish (2 cycles) to avoid freezing.
        cycles += 2;
        break;
    }

    return cycles - cycles_before;
}

int cpuGetPC(void) { return pc; }

void cpuSetPC(word npc) { pc = npc; }


int cpuJSR(word npc, byte na){
    int total = 0;

    a = na; x = 0; y = 0; p = 0; s = 255;
    pc = npc;

    push(0); push(0); // fake return

    while(pc){
        total += cpuStep();
    }
    return total;
}
