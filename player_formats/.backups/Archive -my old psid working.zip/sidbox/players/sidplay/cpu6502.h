#ifndef CPU6502_H
#define CPU6502_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef uint8_t  byte;
typedef uint16_t word;
typedef uint32_t dword;

void cpuReset(void);
void cpuResetTo(word npc);
int  cpuJSR(word npc, byte na);
int cpuStep(void);
int cpuJSR(word npc, byte na);


#ifdef __cplusplus
}
#endif
#endif
