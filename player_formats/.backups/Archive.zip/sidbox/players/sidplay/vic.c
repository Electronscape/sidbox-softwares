#include <stdio.h>
#include <stdint.h>
#include <string.h> // For memset

#include "vic.h"

// --- Constants (PAL C64 Standard) ---
#define VIC_PAL_CYCLES  63
#define VIC_PAL_LINES   312

// --- Globals ---
uint8_t  VICREG[0x40];
uint16_t VICRASTER;
uint32_t VIC_CYC_ACC;
uint8_t  VIC_IRQ_LINE;

// --- Internal State ---
static uint8_t  VIC_RASTER_CMP_LO;   // Latch from $D012
static uint8_t  VIC_RASTER_CMP_HI;   // Latch from $D011 bit 7
static uint8_t  raster_hit_latched;  // 1 = IRQ already fired for this specific match

// Helper macro to mask address to 6 bits (0x00 - 0x3F)
#define VIC_R(a) ((uint8_t)((a) & 0x3F))

// Calculate the full 9-bit Raster Compare value
static inline uint16_t vic_get_raster_cmp(void) {
    return (uint16_t)((VIC_RASTER_CMP_HI ? 0x100 : 0x000) | VIC_RASTER_CMP_LO);
}

// Update the physical IRQ line and the Status Register Bit 7
static inline void vic_update_irq(void) {
    // Bits 0-3 are the interrupt flags
    uint8_t pending = (uint8_t)(VICREG[0x19] & 0x0F);
    // Bits 0-3 are the interrupt masks
    uint8_t mask    = (uint8_t)(VICREG[0x1A] & 0x0F);

    // If any pending event is unmasked, pull IRQ line low (active)
    if (pending & mask) {
        VIC_IRQ_LINE = 1;
        VICREG[0x19] |= 0x80; // Set Bit 7 to indicate active IRQ
    } else {
        VIC_IRQ_LINE = 0;
        VICREG[0x19] &= (uint8_t)~0x80; // Clear Bit 7
    }
}

void vic_reset(void) {
    memset(VICREG, 0, 0x40);

    VICRASTER       = 0;
    VIC_CYC_ACC     = 0;
    VIC_IRQ_LINE    = 0;

    VIC_RASTER_CMP_LO = 0;
    VIC_RASTER_CMP_HI = 0;
    raster_hit_latched = 0;

    // Standard Defaults
    VICREG[0x11] = 0x1B; // Screen on, Text mode, 25 rows
    // $D012, $D019, $D01A default to 0
}

uint8_t vic_read(uint16_t addr) {
    uint8_t r = VIC_R(addr);

    switch (r) {
    case 0x11: { // $D011: Bits 0-6 from Reg, Bit 7 from Current Raster
        uint8_t v = (uint8_t)(VICREG[0x11] & 0x7F);
        if (VICRASTER & 0x100) v |= 0x80;
        return v;
    }

    case 0x12: // $D012: Current Raster Low Byte
        return (uint8_t)(VICRASTER & 0xFF);

    case 0x19: // $D019: Interrupt Status
        // Bit 7 is updated dynamically in vic_update_irq, so just return reg
        return VICREG[0x19];

    default:
        return VICREG[r];
    }
}

void vic_write(uint16_t addr, uint8_t val) {
    uint8_t r = VIC_R(addr);

    switch (r) {
    case 0x11: // $D011: Bit 7 is Raster Compare High Latch
        VIC_RASTER_CMP_HI = (val & 0x80) ? 1 : 0;
        VICREG[0x11] = (uint8_t)(val & 0x7F); // Store bits 0-6

        // Writing to control registers often resets the latch to allow
        // "stable raster" tricks (re-firing on the same line).
        raster_hit_latched = 0;
        vic_update_irq();
        break;

    case 0x12: // $D012: Raster Compare Low Latch
        VIC_RASTER_CMP_LO = val;
        VICREG[0x12] = val; // Store for read-back (though read logic overrides it usually)

        raster_hit_latched = 0;
        vic_update_irq();
        break;

    case 0x19: // $D019: Acknowledge Interrupts
    {
        // Writing 1s to bits 0-3 clears those interrupts
        uint8_t ack_bits = (uint8_t)(val & 0x0F);
        VICREG[0x19] &= (uint8_t)~ack_bits;
        vic_update_irq(); // Re-eval IRQ line after clearing
        break;
    }

    case 0x1A: // $D01A: Interrupt Mask
        VICREG[0x1A] = (uint8_t)(val & 0x0F); // Only bottom 4 bits matter
        vic_update_irq();
        break;

    default:
        VICREG[r] = val;
        break;
    }
}

void vic_step(int cpu_cycles) {
    VIC_CYC_ACC += (uint32_t)cpu_cycles;

    // --- CHECK 1: Mid-Line Logic ---
    // If CPU wrote to $D012 mid-line, we must check for match immediately
    // before advancing the raster counter.
    uint16_t cmp = vic_get_raster_cmp();

    if (VICRASTER == cmp) {
        if (!raster_hit_latched) {
            raster_hit_latched = 1;
            VICREG[0x19] |= 0x01; // Trigger Raster IRQ
            vic_update_irq();
        }
    } else {
        // If we are on a line that doesn't match, ensure latch is clear
        raster_hit_latched = 0;
    }

    // --- CHECK 2: Line Advancement ---
    while (VIC_CYC_ACC >= VIC_PAL_CYCLES) {
        VIC_CYC_ACC -= VIC_PAL_CYCLES;

        // Advance Raster
        VICRASTER++;
        if (VICRASTER >= VIC_PAL_LINES) {
            VICRASTER = 0;
        }

        // We moved to a new line. Check for match immediately at start of line.
        cmp = vic_get_raster_cmp();

        if (VICRASTER == cmp) {
            if (!raster_hit_latched) {
                raster_hit_latched = 1;
                VICREG[0x19] |= 0x01; // Trigger Raster IRQ
                vic_update_irq();
            }
        } else {
            raster_hit_latched = 0;
        }
    }
}
