#include "cia.h"
#include <string.h>

// ===== Internal Constants =====
#define CIA_R(a)       ((uint8_t)((a) & 0x0F))

// Registers
#define CIA_PRA        0x00
#define CIA_PRB        0x01
#define CIA_DDRA       0x02
#define CIA_DDRB       0x03
#define CIA_TALO       0x04
#define CIA_TAHI       0x05
#define CIA_TBLO       0x06
#define CIA_TBHI       0x07
#define CIA_TOD10      0x08
#define CIA_TODSEC     0x09
#define CIA_TODMIN     0x0A
#define CIA_TODHR      0x0B
#define CIA_SDR        0x0C
#define CIA_ICR        0x0D
#define CIA_CRA        0x0E
#define CIA_CRB        0x0F

// Control Register Bits
#define CR_START       0x01
#define CR_PBON        0x02  // Port B Output Mode
#define CR_OUTMODE     0x04  // 0=Pulse, 1=Toggle
#define CR_RUNMODE     0x08  // 1=One-shot
#define CR_LOAD        0x10  // Force Load
#define CR_INMODE      0x20  // Input Mode (Timer A: CNT, Timer B: A/CNT)
#define CR_SPMODE      0x40  // Serial Port Mode
#define CR_TODIN       0x80  // TOD Frequency

// Interrupt Control Bits
#define ICR_TA         0x01
#define ICR_TB         0x02
#define ICR_TOD        0x04
#define ICR_SP         0x08
#define ICR_FLAG       0x10
#define ICR_IRQLATCH   0x80  // Master Interrupt Bit

typedef struct {
    uint8_t  reg[0x10];

    // Internal 16-bit counters and latches
    int32_t  ta, tb; // int32 to handle underflow math easily
    int32_t  ta_latch, tb_latch;

    uint8_t  icr_pending;   // Active interrupt flags
    uint8_t  icr_mask;      // Interrupt masks
    uint8_t  irq_line;      // Physical line state (0=high/inactive, 1=low/active)
} CIAState;

static CIAState cia[2];

//
// This diagram would illustrate how Timer B can be fed by Timer A (cascade) vs System Clock (Phi2).

// Globals for external access (VIC-style)
uint8_t  CIA1REG[0x10];
uint16_t CIA1_TA, CIA1_TB;
uint8_t  CIA1_IRQ_LINE;

uint8_t  CIA2REG[0x10];
uint16_t CIA2_TA, CIA2_TB;
uint8_t  CIA2_IRQ_LINE;

// --- Helper Functions ---

static inline void cia_sync_out(cia_chip_t chip) {
    CIAState *c = &cia[chip];

    // Update the globals so the rest of the emulator sees current state
    if (chip == CIA_CHIP_1) {
        memcpy(CIA1REG, c->reg, 0x10);
        CIA1_TA = (uint16_t)c->ta;
        CIA1_TB = (uint16_t)c->tb;
        CIA1_IRQ_LINE = c->irq_line;
    } else {
        memcpy(CIA2REG, c->reg, 0x10);
        CIA2_TA = (uint16_t)c->ta;
        CIA2_TB = (uint16_t)c->tb;
        CIA2_IRQ_LINE = c->irq_line;
    }
}

static inline void cia_update_irq(CIAState *c) {
    // If any pending event is also unmasked
    if (c->icr_pending & c->icr_mask) {
        c->irq_line = 1; // Active
        c->icr_pending |= ICR_IRQLATCH; // Set the Read-Only Master Bit
    } else {
        c->irq_line = 0; // Inactive
        c->icr_pending &= ~ICR_IRQLATCH;
    }
}

void cia_reset(cia_chip_t chip) {
    CIAState *c = &cia[chip];
    memset(c, 0, sizeof(*c));

    // Defaults: Timers stopped, latches 0xFFFF usually, but 0 is fine for emu start
    c->ta_latch = 0xFFFF;
    c->tb_latch = 0xFFFF;
    c->ta = 0xFFFF;
    c->tb = 0xFFFF;

    cia_sync_out(chip);
}

void cia_reset_all(void) {
    cia_reset(CIA_CHIP_1);
    cia_reset(CIA_CHIP_2);
}

// --- Read/Write Logic ---

uint8_t cia_read(cia_chip_t chip, uint16_t addr) {
    CIAState *c = &cia[chip];
    uint8_t r = CIA_R(addr);

    switch (r) {
    // Timers: Return the live counting value, not the latch
    case CIA_TALO: return (uint8_t)(c->ta & 0xFF);
    case CIA_TAHI: return (uint8_t)(c->ta >> 8);
    case CIA_TBLO: return (uint8_t)(c->tb & 0xFF);
    case CIA_TBHI: return (uint8_t)(c->tb >> 8);

    case CIA_ICR: {
        // Reading ICR returns pending interrupts and CLEARS them
        uint8_t v = c->icr_pending;

        c->icr_pending = 0; // Clear all flags
        cia_update_irq(c);  // Release IRQ line
        cia_sync_out(chip);

        return v;
    }

    default:
        return c->reg[r];
    }
}

void cia_write(cia_chip_t chip, uint16_t addr, uint8_t val) {
    CIAState *c = &cia[chip];
    uint8_t r = CIA_R(addr);

    switch (r) {
    case CIA_TALO:
        c->ta_latch = (c->ta_latch & 0xFF00) | val;
        c->reg[CIA_TALO] = val; // mirroring for debug
        break;

    case CIA_TAHI:
        c->ta_latch = (c->ta_latch & 0x00FF) | (val << 8);
        c->reg[CIA_TAHI] = val;

        // If Timer A is stopped, load counters immediately
        if (!(c->reg[CIA_CRA] & CR_START)) {
            c->ta = c->ta_latch;
        }
        break;

    case CIA_TBLO:
        c->tb_latch = (c->tb_latch & 0xFF00) | val;
        c->reg[CIA_TBLO] = val;
        break;

    case CIA_TBHI:
        c->tb_latch = (c->tb_latch & 0x00FF) | (val << 8);
        c->reg[CIA_TBHI] = val;

        // If Timer B is stopped, load counters immediately
        if (!(c->reg[CIA_CRB] & CR_START)) {
            c->tb = c->tb_latch;
        }
        break;

    case CIA_ICR: {
        // Mask handling
        uint8_t mask = val & 0x7F; // Ignore top bit for the mask value itself
        if (val & 0x80) {
            c->icr_mask |= mask; // Set bits
        } else {
            c->icr_mask &= ~mask; // Clear bits
        }
        cia_update_irq(c);
        break;
    }

    case CIA_CRA:
        c->reg[CIA_CRA] = val;
        if (val & CR_LOAD) {
            c->ta = c->ta_latch;
            c->reg[CIA_CRA] &= ~CR_LOAD; // Auto-clear load bit
        }
        break;

    case CIA_CRB:
        c->reg[CIA_CRB] = val;
        if (val & CR_LOAD) {
            c->tb = c->tb_latch;
            c->reg[CIA_CRB] &= ~CR_LOAD; // Auto-clear load bit
        }
        break;

    default:
        c->reg[r] = val;
        break;
    }

    cia_sync_out(chip);
}

// --- Step Logic (The Core) ---

void cia_step(cia_chip_t chip, int cpu_cycles) {
    CIAState *c = &cia[chip];

    // We use a loop to handle cases where cycles > timer (multiple underflows)
    // or simply to process complex linking.
    // For performance, you could optimize this, but for accuracy, step carefully.

    // Determine Timer B Input Mode:
    // CRB Bit 6,5:
    // 0x: System Clock (cycles)
    // 10: Timer A Underflow
    // 11: Timer A Underflow + CNT (ignored for now)
    int tb_counts_cycles = !((c->reg[CIA_CRB] & 0x60) == 0x40);

    // --- Process Timer A ---
    int ta_underflows = 0;

    if (c->reg[CIA_CRA] & CR_START) {
        c->ta -= cpu_cycles;

        while (c->ta <= 0) {
            // Underflow occurred
            ta_underflows++;

            // Reload
            c->ta += c->ta_latch; // Preserve the "remainder" for accuracy

            // If we perfectly hit 0, we treat it as underflow for next cycle usually,
            // but strictly: N -> N-1 ... -> 1 -> 0 -> RELOAD
            // This logic simplifies: if we drop below 1 (<=0), we reload.

            // Interrupt
            c->icr_pending |= ICR_TA;

            // One-Shot Check
            if (c->reg[CIA_CRA] & CR_RUNMODE) {
                c->reg[CIA_CRA] &= ~CR_START;
                c->ta = c->ta_latch; // Reset to full latch
                break; // Stop counting immediately
            }
        }
    }

    // --- Process Timer B ---
    if (c->reg[CIA_CRB] & CR_START) {
        // Timer B decrements by Cycles OR by Timer A Underflows
        int decrement = tb_counts_cycles ? cpu_cycles : ta_underflows;

        if (decrement > 0) {
            c->tb -= decrement;

            while (c->tb <= 0) {
                // Reload
                c->tb += c->tb_latch;

                // Interrupt
                c->icr_pending |= ICR_TB;

                // One-Shot Check
                if (c->reg[CIA_CRB] & CR_RUNMODE) {
                    c->reg[CIA_CRB] &= ~CR_START;
                    c->tb = c->tb_latch;
                    break;
                }
            }
        }
    }

    // Only update IRQ line at end of step to save overhead
    cia_update_irq(c);

    // NOTE: cia_sync_out is NOT called here for performance.
    // It is only called on Read/Write or manually.
    // However, if you rely on globals for IRQ state in your main loop, update ONLY the IRQ line:
    if (chip == CIA_CHIP_1) CIA1_IRQ_LINE = c->irq_line;
    else                    CIA2_IRQ_LINE = c->irq_line;
}

void cia_step_all(int cpu_cycles) {
    cia_step(CIA_CHIP_1, cpu_cycles);
    cia_step(CIA_CHIP_2, cpu_cycles);
}
