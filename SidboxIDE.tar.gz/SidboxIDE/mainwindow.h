#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class CodeEditor;
class QListWidget;
class QListWidgetItem;
class QPlainTextEdit;
class QProcess;
class QTabWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private:
    void setupInterface();
    void createNewSourceFile();
    void openProject();
    void saveProject();
    void compileActiveFile();
    void openProjectFile(QListWidgetItem *item);
    void handleCompilerFinished(int exitCode);

    CodeEditor *activeEditor() const;
    CodeEditor *createEditor(const QString &filePath = QString());
    bool openFile(const QString &filePath);
    bool saveEditor(CodeEditor *editor);
    void refreshProjectFiles();
    void updateTabTitle(CodeEditor *editor);
    QString tabTitleForEditor(CodeEditor *editor) const;
    QString displayPath(const QString &filePath) const;
    QStringList projectSourceFiles() const;

    Ui::MainWindow *ui;
    QListWidget *m_projectFiles;
    QTabWidget *m_editorTabs;
    QPlainTextEdit *m_outputPane;
    QProcess *m_compilerProcess;
    QString m_projectPath;
};
#endif // MAINWINDOW_H
