#ifndef CODEEDITOR_H
#define CODEEDITOR_H

#include <QPlainTextEdit>
#include <QString>

class CSyntaxHighlighter;

class CodeEditor : public QPlainTextEdit
{
    Q_OBJECT

public:
    explicit CodeEditor(QWidget *parent = nullptr);
    ~CodeEditor() override;

    QString filePath() const;
    void setFilePath(const QString &path);

    bool loadFromFile(const QString &path);
    bool save();
    bool saveAs(const QString &path);

private:
    QString m_filePath;
    CSyntaxHighlighter *m_highlighter;
};

#endif // CODEEDITOR_H
