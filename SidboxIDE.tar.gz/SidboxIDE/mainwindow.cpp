#include "mainwindow.h"

#include "codeeditor.h"
#include "ui_mainwindow.h"

#include <QAction>
#include <QDir>
#include <QDirIterator>
#include <QFileDialog>
#include <QFileInfo>
#include <QLabel>
#include <QListWidget>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QProcess>
#include <QSplitter>
#include <QStatusBar>
#include <QTabWidget>
#include <QTextDocument>
#include <QToolBar>
#include <QVBoxLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_projectFiles(nullptr)
    , m_editorTabs(nullptr)
    , m_outputPane(nullptr)
    , m_compilerProcess(new QProcess(this))
{
    ui->setupUi(this);
    setupInterface();

    connect(m_compilerProcess, &QProcess::readyReadStandardOutput, this, [this]() {
        m_outputPane->appendPlainText(QString::fromLocal8Bit(m_compilerProcess->readAllStandardOutput()));
    });
    connect(m_compilerProcess, &QProcess::readyReadStandardError, this, [this]() {
        m_outputPane->appendPlainText(QString::fromLocal8Bit(m_compilerProcess->readAllStandardError()));
    });
    connect(m_compilerProcess, &QProcess::errorOccurred, this, [this](QProcess::ProcessError) {
        m_outputPane->appendPlainText(tr("Could not start compiler. Make sure gcc is installed and on PATH."));
        statusBar()->showMessage(tr("Compile failed"));
    });
    connect(m_compilerProcess, &QProcess::finished, this, &MainWindow::handleCompilerFinished);

    createNewSourceFile();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupInterface()
{
    setWindowTitle(tr("Sidbox IDE"));
    resize(1100, 720);

    auto *toolBar = addToolBar(tr("Project"));
    toolBar->setMovable(false);

    QAction *newAction = toolBar->addAction(tr("New"));
    QAction *openProjectAction = toolBar->addAction(tr("Open Project"));
    QAction *saveProjectAction = toolBar->addAction(tr("Save Project"));
    toolBar->addSeparator();
    QAction *compileAction = toolBar->addAction(tr("Compile"));

    connect(newAction, &QAction::triggered, this, &MainWindow::createNewSourceFile);
    connect(openProjectAction, &QAction::triggered, this, &MainWindow::openProject);
    connect(saveProjectAction, &QAction::triggered, this, &MainWindow::saveProject);
    connect(compileAction, &QAction::triggered, this, &MainWindow::compileActiveFile);

    auto *mainSplitter = new QSplitter(Qt::Horizontal, this);

    auto *projectPane = new QWidget(mainSplitter);
    auto *projectLayout = new QVBoxLayout(projectPane);
    projectLayout->setContentsMargins(8, 8, 8, 8);
    projectLayout->setSpacing(6);

    auto *projectLabel = new QLabel(tr("Files in Project"), projectPane);
    m_projectFiles = new QListWidget(projectPane);
    m_projectFiles->setAlternatingRowColors(true);
    projectLayout->addWidget(projectLabel);
    projectLayout->addWidget(m_projectFiles, 1);

    connect(m_projectFiles, &QListWidget::itemDoubleClicked, this, &MainWindow::openProjectFile);

    auto *workAreaSplitter = new QSplitter(Qt::Vertical, mainSplitter);
    m_editorTabs = new QTabWidget(workAreaSplitter);
    m_editorTabs->setDocumentMode(true);
    m_editorTabs->setTabsClosable(true);
    m_editorTabs->setMovable(true);

    connect(m_editorTabs, &QTabWidget::tabCloseRequested, this, [this](int index) {
        QWidget *widget = m_editorTabs->widget(index);
        m_editorTabs->removeTab(index);
        widget->deleteLater();
        if (m_editorTabs->count() == 0) {
            createNewSourceFile();
        }
    });

    m_outputPane = new QPlainTextEdit(workAreaSplitter);
    m_outputPane->setReadOnly(true);
    m_outputPane->setPlaceholderText(tr("Compiler output"));
    m_outputPane->setMaximumBlockCount(1000);

    workAreaSplitter->addWidget(m_editorTabs);
    workAreaSplitter->addWidget(m_outputPane);
    workAreaSplitter->setStretchFactor(0, 4);
    workAreaSplitter->setStretchFactor(1, 1);

    mainSplitter->addWidget(projectPane);
    mainSplitter->addWidget(workAreaSplitter);
    mainSplitter->setStretchFactor(0, 1);
    mainSplitter->setStretchFactor(1, 5);
    mainSplitter->setSizes({220, 880});

    setCentralWidget(mainSplitter);
    statusBar()->showMessage(tr("Ready"));
}

void MainWindow::createNewSourceFile()
{
    CodeEditor *editor = createEditor();
    editor->setPlainText(QStringLiteral("#include <stdio.h>\n\nint main(void)\n{\n    printf(\"Hello, Sidbox!\\n\");\n    return 0;\n}\n"));
    editor->document()->setModified(false);

    const int index = m_editorTabs->addTab(editor, tabTitleForEditor(editor));
    m_editorTabs->setCurrentIndex(index);
    statusBar()->showMessage(tr("New C source file created"));
}

void MainWindow::openProject()
{
    const QString directory = QFileDialog::getExistingDirectory(this, tr("Open Project"));
    if (directory.isEmpty()) {
        return;
    }

    m_projectPath = directory;
    refreshProjectFiles();
    statusBar()->showMessage(tr("Project opened: %1").arg(QDir::toNativeSeparators(m_projectPath)));

    const QStringList sources = projectSourceFiles();
    if (!sources.isEmpty()) {
        openFile(sources.first());
    }
}

void MainWindow::saveProject()
{
    bool allSaved = true;

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor = qobject_cast<CodeEditor *>(m_editorTabs->widget(i));
        if (!editor) {
            continue;
        }

        allSaved = saveEditor(editor) && allSaved;
    }

    if (allSaved) {
        refreshProjectFiles();
        statusBar()->showMessage(tr("Project saved"));
    } else {
        statusBar()->showMessage(tr("Some files could not be saved"));
    }
}

void MainWindow::compileActiveFile()
{
    CodeEditor *editor = activeEditor();
    if (!editor) {
        return;
    }

    if (!saveEditor(editor)) {
        QMessageBox::warning(this, tr("Compile"), tr("Save the current source file before compiling."));
        return;
    }

    if (m_compilerProcess->state() != QProcess::NotRunning) {
        QMessageBox::information(this, tr("Compile"), tr("A compile is already running."));
        return;
    }

    const QString filePath = editor->filePath();
    const QFileInfo sourceInfo(filePath);
    const QString workingDirectory = m_projectPath.isEmpty() ? sourceInfo.absolutePath() : m_projectPath;
    const QString outputDirectory = QDir(workingDirectory).filePath(QStringLiteral(".sidbox-build"));

    QDir().mkpath(outputDirectory);

    const QString outputPath = QDir(outputDirectory).filePath(sourceInfo.completeBaseName());

    m_outputPane->clear();
    m_outputPane->appendPlainText(tr("Compiling %1").arg(displayPath(filePath)));
    m_outputPane->appendPlainText(tr("Output: %1").arg(QDir::toNativeSeparators(outputPath)));
    m_compilerProcess->setWorkingDirectory(workingDirectory);
    m_compilerProcess->start(QStringLiteral("gcc"), {QStringLiteral("-Wall"), QStringLiteral("-Wextra"), filePath, QStringLiteral("-o"), outputPath});

    statusBar()->showMessage(tr("Compile started"));
}

void MainWindow::openProjectFile(QListWidgetItem *item)
{
    if (!item) {
        return;
    }

    openFile(item->data(Qt::UserRole).toString());
}

void MainWindow::handleCompilerFinished(int exitCode)
{
    if (exitCode == 0) {
        m_outputPane->appendPlainText(tr("Compile finished successfully."));
        statusBar()->showMessage(tr("Compile successful"));
    } else {
        m_outputPane->appendPlainText(tr("Compile failed with exit code %1.").arg(exitCode));
        statusBar()->showMessage(tr("Compile failed"));
    }
}

CodeEditor *MainWindow::activeEditor() const
{
    return qobject_cast<CodeEditor *>(m_editorTabs->currentWidget());
}

CodeEditor *MainWindow::createEditor(const QString &filePath)
{
    auto *editor = new CodeEditor(m_editorTabs);
    editor->setFilePath(filePath);

    connect(editor->document(), &QTextDocument::modificationChanged, this, [this, editor]() {
        updateTabTitle(editor);
    });

    return editor;
}

bool MainWindow::openFile(const QString &filePath)
{
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor = qobject_cast<CodeEditor *>(m_editorTabs->widget(i));
        if (editor && editor->filePath() == filePath) {
            m_editorTabs->setCurrentIndex(i);
            return true;
        }
    }

    CodeEditor *editor = createEditor(filePath);
    if (!editor->loadFromFile(filePath)) {
        editor->deleteLater();
        QMessageBox::warning(this, tr("Open File"), tr("Could not open %1.").arg(QDir::toNativeSeparators(filePath)));
        return false;
    }

    const int index = m_editorTabs->addTab(editor, tabTitleForEditor(editor));
    m_editorTabs->setCurrentIndex(index);
    return true;
}

bool MainWindow::saveEditor(CodeEditor *editor)
{
    if (!editor) {
        return false;
    }

    if (editor->filePath().isEmpty()) {
        const QString baseDirectory = m_projectPath.isEmpty() ? QDir::homePath() : m_projectPath;
        const QString filePath = QFileDialog::getSaveFileName(
            this,
            tr("Save Source File"),
            QDir(baseDirectory).filePath(QStringLiteral("main.c")),
            tr("C source/header files (*.c *.h);;All files (*)"));

        if (filePath.isEmpty()) {
            return false;
        }

        if (!editor->saveAs(filePath)) {
            QMessageBox::warning(this, tr("Save File"), tr("Could not save %1.").arg(QDir::toNativeSeparators(filePath)));
            return false;
        }
    } else if (!editor->save()) {
        QMessageBox::warning(this, tr("Save File"), tr("Could not save %1.").arg(QDir::toNativeSeparators(editor->filePath())));
        return false;
    }

    updateTabTitle(editor);
    return true;
}

void MainWindow::refreshProjectFiles()
{
    m_projectFiles->clear();

    const QStringList sources = projectSourceFiles();
    for (const QString &filePath : sources) {
        auto *item = new QListWidgetItem(displayPath(filePath), m_projectFiles);
        item->setData(Qt::UserRole, filePath);
    }
}

void MainWindow::updateTabTitle(CodeEditor *editor)
{
    const int index = m_editorTabs->indexOf(editor);
    if (index >= 0) {
        m_editorTabs->setTabText(index, tabTitleForEditor(editor));
    }
}

QString MainWindow::tabTitleForEditor(CodeEditor *editor) const
{
    QString title = editor->filePath().isEmpty()
        ? tr("untitled.c")
        : QFileInfo(editor->filePath()).fileName();

    if (editor->document()->isModified()) {
        title.prepend(QLatin1Char('*'));
    }

    return title;
}

QString MainWindow::displayPath(const QString &filePath) const
{
    if (m_projectPath.isEmpty()) {
        return QFileInfo(filePath).fileName();
    }

    return QDir(m_projectPath).relativeFilePath(filePath);
}

QStringList MainWindow::projectSourceFiles() const
{
    if (m_projectPath.isEmpty()) {
        return {};
    }

    const QStringList filters = {
        QStringLiteral("*.c"),
        QStringLiteral("*.h")
    };

    QStringList files;
    QDirIterator iterator(m_projectPath, filters, QDir::Files, QDirIterator::Subdirectories);
    while (iterator.hasNext()) {
        iterator.next();
        files.append(iterator.fileInfo().absoluteFilePath());
    }

    files.sort(Qt::CaseInsensitive);
    return files;
}
