/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QPushButton *cmdClose;
    QPushButton *cmdZoom1x;
    QPushButton *cmdZoom2x;
    QGraphicsView *gfxPort;
    QPushButton *cmdZoomWx;
    QFrame *line;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName("Dialog");
        Dialog->resize(1172, 765);
        Dialog->setMinimumSize(QSize(502, 374));
        Dialog->setMaximumSize(QSize(16384, 16384));
        QPalette palette;
        QBrush brush(QColor(49, 53, 58, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        Dialog->setPalette(palette);
        QIcon icon(QIcon::fromTheme(QIcon::ThemeIcon::ImageLoading));
        Dialog->setWindowIcon(icon);
        cmdClose = new QPushButton(Dialog);
        cmdClose->setObjectName("cmdClose");
        cmdClose->setGeometry(QRect(410, 6, 80, 24));
        QPalette palette1;
        QBrush brush1(QColor(117, 0, 0, 255));
        brush1.setStyle(Qt::BrushStyle::SolidPattern);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Button, brush1);
        QBrush brush2(QColor(215, 235, 255, 255));
        brush2.setStyle(Qt::BrushStyle::SolidPattern);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Light, brush2);
        QBrush brush3(QColor(236, 56, 56, 255));
        brush3.setStyle(Qt::BrushStyle::SolidPattern);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Midlight, brush3);
        QBrush brush4(QColor(255, 0, 4, 255));
        brush4.setStyle(Qt::BrushStyle::SolidPattern);
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Highlight, brush4);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette1.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Accent, brush4);
#endif
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Button, brush1);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Light, brush2);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Midlight, brush3);
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Highlight, brush4);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette1.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Accent, brush4);
#endif
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Button, brush1);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Light, brush2);
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Midlight, brush3);
#if QT_VERSION >= QT_VERSION_CHECK(6, 6, 0)
        palette1.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Accent, brush4);
#endif
        cmdClose->setPalette(palette1);
        cmdZoom1x = new QPushButton(Dialog);
        cmdZoom1x->setObjectName("cmdZoom1x");
        cmdZoom1x->setGeometry(QRect(10, 6, 80, 24));
        cmdZoom2x = new QPushButton(Dialog);
        cmdZoom2x->setObjectName("cmdZoom2x");
        cmdZoom2x->setGeometry(QRect(90, 6, 80, 24));
        gfxPort = new QGraphicsView(Dialog);
        gfxPort->setObjectName("gfxPort");
        gfxPort->setGeometry(QRect(10, 40, 480, 320));
        QFont font;
        font.setStyleStrategy(QFont::PreferAntialias);
        gfxPort->setFont(font);
        gfxPort->viewport()->setProperty("cursor", QVariant(QCursor(Qt::CursorShape::ArrowCursor)));
        gfxPort->setAcceptDrops(false);
        gfxPort->setVerticalScrollBarPolicy(Qt::ScrollBarPolicy::ScrollBarAlwaysOff);
        gfxPort->setHorizontalScrollBarPolicy(Qt::ScrollBarPolicy::ScrollBarAlwaysOff);
        gfxPort->setInteractive(false);
        cmdZoomWx = new QPushButton(Dialog);
        cmdZoomWx->setObjectName("cmdZoomWx");
        cmdZoomWx->setGeometry(QRect(170, 6, 91, 24));
        line = new QFrame(Dialog);
        line->setObjectName("line");
        line->setGeometry(QRect(-490, 34, 2510, 3));
        line->setFrameShape(QFrame::Shape::HLine);
        line->setFrameShadow(QFrame::Shadow::Sunken);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "SIDBOX Graphics Labs", nullptr));
        cmdClose->setText(QCoreApplication::translate("Dialog", "close", nullptr));
        cmdZoom1x->setText(QCoreApplication::translate("Dialog", "Zoom x 1", nullptr));
        cmdZoom2x->setText(QCoreApplication::translate("Dialog", "Zoom x 2", nullptr));
        cmdZoomWx->setText(QCoreApplication::translate("Dialog", "To Scale Win", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
