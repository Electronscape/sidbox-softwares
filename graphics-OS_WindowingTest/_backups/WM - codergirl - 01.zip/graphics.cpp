#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "codergirl/sys_font.h"
#include "sbapi_graphics.h"


uint8_t current_fr_colour = 1;
uint8_t current_bk_colour = 0;

uint8_t PROJ_VRAM[SCR_RAMSIZE];

uint32_t PROJ_CRAM[256] = {
    0x00000000, 0x00AFAFAF, 0x00FFFFFF, 0x003B67A2, 0x00AA907C, 0x00959595, 0x007B7B7B, 0x00FFA997,
    0x0037A91D, 0x007CA9FF, 0x00BF8112, 0x00EBBF66, 0x0078C178, 0x003D9318, 0x00B33418, 0x00D9311C,
    0x00000000, 0x0000001C, 0x00000039, 0x00000055, 0x00000071, 0x0000018E, 0x000001AA, 0x000001C6,
    0x000001E3, 0x000001FF, 0x00CECECE, 0x0000FF00, 0x00B2FF00, 0x00FFE700, 0x00FF9600, 0x00FF1100,
    0x00491200, 0x00491355, 0x004914AA, 0x004916FF, 0x005B1700, 0x005B1855, 0x005B19AA, 0x005B1AFF,
    0x006D1B00, 0x006D1C55, 0x0000E300, 0x0085FF54, 0x00C4FF00, 0x00FFD900, 0x00FFA41F, 0x00E05400,
    0x00FF0000, 0x00922655, 0x009227AA, 0x009228FF, 0x00A42900, 0x00A42A55, 0x00A42BAA, 0x00A42CFF,
    0x00B62D00, 0x00B62F55, 0x00B630AA, 0x00B631FF, 0x00C93200, 0x00C93355, 0x00C934AA, 0x00C935FF,
    0x00DB3700, 0x00DB3855, 0x00DB39AA, 0x00DB3AFF, 0x00ED3B00, 0x00ED3C55, 0x00ED3DAA, 0x00ED3FFF,
    0x00FF4000, 0x00FF4155, 0x00FF42AA, 0x00FF43FF, 0x00004400, 0x00004555, 0x000046AA, 0x000048FF,
    0x00FFFF00, 0x0012FF55, 0x0012EE55, 0x0012B6FF, 0x00001FFF, 0x009D0EC7, 0x00F10000, 0x00FF7700,
    0x00375200, 0x00375355, 0x003754AA, 0x003755FF, 0x00495600, 0x00495855, 0x004959AA, 0x00495AFF,
    0x005B5B00, 0x005B5C55, 0x005B5DAA, 0x005B5EFF, 0x006D6000, 0x006D6155, 0x006D62AA, 0x006D63FF,
    0x006D6400, 0x00806555, 0x008066AA, 0x008067FF, 0x00926900, 0x00926A55, 0x00926BAA, 0x00926CFF,
    0x00A46D00, 0x00A46E55, 0x00A46FAA, 0x00A471FF, 0x00B67200, 0x00B67355, 0x00B674AA, 0x00B675FF,
    0x00C97600, 0x00C97755, 0x00C979AA, 0x00C97AFF, 0x00DB7B00, 0x00DB7C55, 0x00DB7DAA, 0x00DB7EFF,
    0x00ED7F00, 0x00ED8055, 0x00ED82AA, 0x00ED83FF, 0x00FF8400, 0x00FF8555, 0x00FF86AA, 0x00FF87FF,
    0x00008800, 0x00008A55, 0x00008BAA, 0x00008CFF, 0x00128D00, 0x00128E55, 0x00128FAA, 0x001290FF,
    0x00249200, 0x00249355, 0x002494AA, 0x002495FF, 0x00379600, 0x00379755, 0x003798AA, 0x003799FF,
    0x00499B00, 0x00499C55, 0x00499DAA, 0x00499EFF, 0x005B9F00, 0x005BA055, 0x005BA1AA, 0x005BA3FF,
    0x00A4B5D5, 0x00A0B0F8, 0x0094A3E6, 0x007C89C1, 0x006281C0, 0x001C62A1, 0x004254EA, 0x0062A1BD,
    0x007093C0, 0x004977A1, 0x00003FAA, 0x001554FF, 0x001C50B9, 0x0000B3FF, 0x000088AA, 0x0000B5FF,
    0x000E62FF, 0x005EB7E3, 0x00BDC0B9, 0x0085B9FF, 0x00006CAF, 0x001F81B9, 0x003F5BAA, 0x00C9BEFF,
    0x005BAFCB, 0x00DBC055, 0x00DBC1AA, 0x00BDC0C0, 0x00EDC400, 0x00EDC555, 0x00EDC6AA, 0x00EDC7FF,
    0x00FFC800, 0x00FFC955, 0x00FFCAAA, 0x00FFCCFF, 0x0000CD00, 0x0000CE55, 0x0000CFAA, 0x0000D0FF,
    0x0012D100, 0x0012D255, 0x0012D3AA, 0x0012D5FF, 0x0024D600, 0x0024D755, 0x0024D8AA, 0x0024D9FF,
    0x00100020, 0x001B0029, 0x00250032, 0x0030003A, 0x003B0043, 0x0045004C, 0x00500055, 0x0049E2FF,
    0x005BE300, 0x005BE555, 0x005BE6AA, 0x005BE7FF, 0x006DE800, 0x006DE955, 0x006DEAAA, 0x006DEBFF,
    0x006DEC00, 0x0080EE55, 0x0080EFAA, 0x0080F0FF, 0x0093CEA2, 0x0092F255, 0x0092F3AA, 0x0092F4FF,
    0x00A4F600, 0x00A4F755, 0x00A4F8AA, 0x00A4F9FF, 0x00B6FA00, 0x00B6FB55, 0x00B6FCAA, 0x00B6FEFF,
    0x00C9FF00, 0x00C9FF55, 0x00C9FFAA, 0x00C9FFFF, 0x00DBFF00, 0x00DBFF55, 0x00DBFFAA, 0x00DBFFFF,
    0x00EDFF00, 0x00EDFF55, 0x00EDFFAA, 0x00EDFFFF, 0x00FFFF00, 0x00FFFF55, 0x00FFFFAA, 0x00FFFFFF,
};


uint32_t dxf[480];
uint32_t dyf[320];

void prepXYs(){
    long i;
    for(i=0; i<480; i++){
        dxf[i] = i*320;
    }

    for(i=0; i<320; i++){
        dyf[i] = i*480;
    }
}


unsigned char cyclefrom = 16, cycleto = 25;
char bCycleDirection = 0;

unsigned char clut_cycle_index[256] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
    0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
    0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x8D, 0x8E, 0x8F,
    0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0x9B, 0x9C, 0x9D, 0x9E, 0x9F,
    0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
    0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7, 0xB8, 0xB9, 0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF,
    0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF,
    0xD0, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
    0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED, 0xEE, 0xEF,
    0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF,
};

unsigned char cyclespeed = 5; // special cycle pallet

void sbgfx_pset(int16_t x, int16_t y, uint8_t cindex){
    if ((unsigned)x >= SCR_WIDTH || (unsigned)y >= SCR_HEIGHT)
        return;

    uint8_t *vmem = PROJ_VRAM + (y * SCR_WIDTH + x);
    *vmem = cindex;
}


void sbgfx_ppixel(int16_t x, int16_t y){
    if(x < 0 || y < 0) return;
    if (x >= SCR_WIDTH || y >= SCR_HEIGHT) return;


    uint8_t* dp = PROJ_VRAM + x * SCR_HEIGHT + y;
    //uint8_t *vmem = PROJ_VRAM + (y * SCR_WIDTH + x);
    *dp = current_fr_colour;
}


void sbgfx_pixel(int16_t x, int16_t y, uint8_t col){
    // shouldnt need this stuff below since this routine SHOULD be handled view the clip system
    //if(x < 0 || y < 0) return;
    //if (x >= SCR_WIDTH || y >= SCR_HEIGHT) return;


    uint8_t* dp = PROJ_VRAM + x * SCR_HEIGHT + y;
    //uint8_t *vmem = PROJ_VRAM + (y * SCR_WIDTH + x);
    *dp = col;
}


void sbgfx_glyph(int16_t x, int16_t y, uint8_t *src){
    int bw, bh;
    bw = x + 16;
    bh = y + 16;

    for( int16_t px = x; px < bw; px ++){
        for( int16_t py = y; py < bh; py ++){
            uint8_t* dp = PROJ_VRAM + px * SCR_HEIGHT + py;
            uint8_t pix = *(src++);
            if(py < 0 || py >= SCR_HEIGHT) continue;
            if(px < 0 || px >= SCR_WIDTH) continue;
            if(pix) *dp = pix;
        }
    }
}

void sbgfx_fill(uint8_t colour){
    for (int i = 0; i < SCR_RAMSIZE; i++)
        PROJ_VRAM[i] = colour;
}

void sbgfx_drawbox(int x, int y, int w, int h, uint8_t col){
    // Clip to screen bounds
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > SCR_WIDTH) w = SCR_WIDTH - x;
    if (y + h > SCR_HEIGHT) h = SCR_HEIGHT - y;
    if (w <= 0 || h <= 0) return;

    /*
    for (int fy = 0; fy < h; fy++) {
        uint8_t *row = VRAM + (y + fy) * SCR_WIDTH + x;
        for (int fx = 0; fx < w; fx++) {
            row[fx] = col;
        }
    }
    */
    for (int fx = 0; fx < w; fx++) {
        uint8_t *row = PROJ_VRAM + ((x + fx) * SCR_HEIGHT) + y;
        for (int fy = 0; fy < h; fy++) {
            row[fy] = col;
        }
    }
}


void sbx_drawbox(int x, int y, int w, int h, uint8_t col){

}

void sbgfx_drawhline(int x, int y, int w){
    if (x < 0) { w += x; x = 0; }
    if (y < 0 || y > SCR_HEIGHT) { return; }  // horizontal not even on screen exit
    if (x + w > SCR_WIDTH) w = SCR_WIDTH - x;

    for (int fx = x; fx < x + w; fx++) {
        sbgfx_ppixel(fx, y);
    }
}


void sbgfx_drawvline(int x, int y, int h){
    if (y < 0) { y = 0; }
    if (x < 0 || x > SCR_WIDTH) { return; }  // horizontal not even on screen exit
    if (y + h > SCR_HEIGHT) h = SCR_HEIGHT;

    for (int fy = y; fy < y + h; ++fy) {
        sbgfx_ppixel(x, fy);
    }
}

void gfx_setcolour(unsigned char col){
    current_fr_colour = col;
}



void dopalletecycle() {
    static char cbd;
    static unsigned char i;
    static unsigned long tmp;
    static unsigned char tmpold;

    static unsigned short SpeedStep;

    /*  // this is STM32 specific
    if(cbd) {
        cbd=0;
        HAL_DMA2D_CLUTLoad_IT(&hdma2d, clut1, 1);
    } else {
        cbd=1;
        HAL_DMA2D_CLUTLoad_IT(&hdma2d, clut1, 0);
    }
    */

    if(cyclespeed==255) return;


    SpeedStep++;
    if (SpeedStep > cyclespeed) {
        SpeedStep = 0;
        if (bCycleDirection == 0) {
            tmp = PROJ_CRAM[cyclefrom];
            tmpold = clut_cycle_index[cyclefrom];
            for (i = cyclefrom; i < cycleto; i++) {
                PROJ_CRAM[i] = PROJ_CRAM[i + 1];
                clut_cycle_index[i] = clut_cycle_index[i + 1];
            }
            PROJ_CRAM[i] = tmp;
            clut_cycle_index[i] = tmpold;

        } else {
            tmp = PROJ_CRAM[cycleto];
            tmpold = clut_cycle_index[cycleto];
            for (i = cycleto; i > cyclefrom; i--) {
                PROJ_CRAM[i] = PROJ_CRAM[i - 1];
                clut_cycle_index[i] = clut_cycle_index[i - 1];
            }
            PROJ_CRAM[i] = tmp;
            clut_cycle_index[i] = tmpold;
        }
    }
}


void draw_text816(int x, int y, const unsigned char* textptr)
{
    int32_t start_x = x;
    uint8_t colf = current_fr_colour;

    for (int32_t i = 0; textptr[i] != '\0'; ++i) {

        unsigned char ch = textptr[i];

        if (ch == '\n') {
            x = start_x;
            y += 16;
            continue;
        }

        const uint8_t* pixeldata = DEFAULT_SYSFONT[ch];

        // Draw 8 columns per glyph
        for (int j = 0; j < 8; ++j) {

            int xc = x + j;
            if ((unsigned)xc >= SCR_WIDTH) continue; // column offscreen L/R

            uint8_t pixdat = pixeldata[j];

            // Base pointer for this column at the glyph's top Y
            // We'll add row offsets as needed, but only when in-range.
            // NOTE: VRAM is column-major: x * SCR_HEIGHT + y
            int base = xc * SCR_HEIGHT;

            // Each bit = 2 vertical pixels (16px tall total)
            // For each bit set, write dp[row] and dp[row+1]
            // with proper Y clipping
            if (pixdat & 0x01) {
                int yy = y + 0;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
                yy = y + 1;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
            }
            if (pixdat & 0x02) {
                int yy = y + 2;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
                yy = y + 3;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
            }
            if (pixdat & 0x04) {
                int yy = y + 4;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
                yy = y + 5;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
            }
            if (pixdat & 0x08) {
                int yy = y + 6;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
                yy = y + 7;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
            }
            if (pixdat & 0x10) {
                int yy = y + 8;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
                yy = y + 9;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
            }
            if (pixdat & 0x20) {
                int yy = y + 10;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
                yy = y + 11;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
            }
            if (pixdat & 0x40) {
                int yy = y + 12;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
                yy = y + 13;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
            }
            if (pixdat & 0x80) {
                int yy = y + 14;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
                yy = y + 15;
                if ((unsigned)yy < SCR_HEIGHT) PROJ_VRAM[base + yy] = colf;
            }
        }

        // Advance to next character (same as your original behavior)
        x += 8;
    }
}

